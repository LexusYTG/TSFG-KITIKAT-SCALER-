package com.TuringSoftware.FrameGenerator;

/**
 * Constantes globales compartidas entre Activity y Service.
 * Centralizar aquí evita la duplicación y los errores de sincronía.
 */
public final class AppConstants {

    private AppConstants() {}

    // ── Modos de procesamiento ────────────────────────────────────────────────
    public static final int MODE_PERFORMANCE = 0;
    public static final int MODE_SIFG1       = 1;
    public static final int MODE_ASIFG       = 2;
    public static final int MODE_GPU         = 3;  // GPU via RenderScript (SIFg v1.1 GPU)
    public static final int MODE_ASIFG_GPU   = 4;  // ASIFg con aceleración GPU (RenderScript)

    /**
     * Devuelve true si el modo soporta conmutación CPU/GPU en la UI.
     * SIFg v1.0 es puramente predictivo (no tiene variante GPU relevante).
     * SIFg v1.1 → GPU=MODE_GPU.  ASIFg → GPU=MODE_ASIFG_GPU.
     */
    public static boolean modeSupportsGpuToggle(int mode) {
        return mode == MODE_SIFG1 || mode == MODE_ASIFG
            || mode == MODE_GPU   || mode == MODE_ASIFG_GPU;
    }

    /** Dado un modo, devuelve su equivalente GPU (o el mismo si ya es GPU). */
    public static int toGpuMode(int mode) {
        if (mode == MODE_SIFG1)     return MODE_GPU;
        if (mode == MODE_ASIFG)     return MODE_ASIFG_GPU;
        return mode; // ya es GPU o no tiene variante
    }

    /** Dado un modo GPU, devuelve su equivalente CPU. */
    public static int toCpuMode(int mode) {
        if (mode == MODE_GPU)       return MODE_SIFG1;
        if (mode == MODE_ASIFG_GPU) return MODE_ASIFG;
        return mode;
    }

    /** Devuelve true si el modo dado es una variante GPU. */
    public static boolean isGpuMode(int mode) {
        return mode == MODE_GPU || mode == MODE_ASIFG_GPU;
    }

    // ── SharedPreferences ────────────────────────────────────────────────────
    public static final String PREFS_NAME              = "ScreenScalerStats";
    public static final String PREF_RESOLUTION_SCALE   = "resolution_scale";
    public static final String PREF_FRAMES_TO_GENERATE = "frames_to_generate";
    public static final String PREF_COLOR_QUALITY      = "color_quality";
    public static final String PREF_FISHEYE_CORRECTION = "fisheye_correction";
    public static final String PREF_SIFG_VERSION       = "sifg_version";
    public static final String PREF_TOUCH_FORWARD      = "touch_forward_enabled";
    /** FPS objetivo para el pacing del capturador (controla TARGET_FRAME_NANOS). */
    public static final String PREF_TARGET_FPS          = "target_fps";
    public static final String PREF_AVG_FPS_PERFORMANCE = "avg_fps_performance";
    public static final String PREF_AVG_FPS_SIFG1      = "avg_fps_sifg1";
    public static final String PREF_AVG_FPS_ASIFG      = "avg_fps_asifg";

    // Cache de resoluciones precalculadas (evita recalcular en cada giro / inicio)
    // Formato: "tW_tH_sW_sH" para cada combinación orientación × escala.
    // Las 6 entradas cubren: portrait/landscape × 25%/50%/75%
    public static final String PREF_RES_CACHE_P25  = "res_cache_p_25";   // portrait  25%
    public static final String PREF_RES_CACHE_P50  = "res_cache_p_50";   // portrait  50%
    public static final String PREF_RES_CACHE_P75  = "res_cache_p_75";   // portrait  75%
    public static final String PREF_RES_CACHE_L25  = "res_cache_l_25";   // landscape 25%
    public static final String PREF_RES_CACHE_L50  = "res_cache_l_50";   // landscape 50%
    public static final String PREF_RES_CACHE_L75  = "res_cache_l_75";   // landscape 75%

    // Insets de sistema (status bar + nav bar) — detectados automáticamente
    public static final String PREF_INSET_STATUS_BAR = "inset_status_bar";  // px
    public static final String PREF_INSET_NAV_BAR    = "inset_nav_bar";     // px

    // Modo de captura: 0=pantalla completa, 1=app específica (API 34+)
    public static final String PREF_CAPTURE_MODE     = "capture_mode";
    public static final int    CAPTURE_MODE_FULLSCREEN  = 0;
    public static final int    CAPTURE_MODE_SINGLE_APP  = 1;

    // ── Valores por defecto ───────────────────────────────────────────────────
    public static final float DEFAULT_RESOLUTION_SCALE  = 0.5f;
    public static final int   DEFAULT_FRAMES_TO_GENERATE = 1;
    public static final int   DEFAULT_COLOR_QUALITY      = 0;
    public static final int   DEFAULT_FISHEYE_CORRECTION = 0;
    public static final int   DEFAULT_SIFG_VERSION       = 0;
    /** FPS objetivo por defecto — 60 FPS = 16.67 ms/frame. */
    public static final int   DEFAULT_TARGET_FPS         = 60;
    /** Opciones de FPS disponibles en la UI (compatible con paneles de 60 Hz, 90 Hz y 120 Hz). */
    public static final int[] FPS_OPTIONS = {30, 45, 60, 90, 120};
    /** El reenvío de toques por accesibilidad está desactivado por defecto. */
    public static final boolean DEFAULT_TOUCH_FORWARD    = false;

    // ── Request codes ────────────────────────────────────────────────────────
    public static final int REQUEST_CODE_CAPTURE      = 1001;
    public static final int REQUEST_CODE_ACCESSIBILITY = 1002;
    public static final int REQUEST_CODE_OVERLAY       = 1003;

    // ── Tag de log ───────────────────────────────────────────────────────────
    public static final String TAG = "ScreenScaler";
}





