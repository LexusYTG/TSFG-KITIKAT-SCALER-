package com.TuringSoftware.FrameGenerator;

import android.accessibilityservice.AccessibilityService;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.ComponentName;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.ServiceConnection;
import android.content.SharedPreferences;
import android.content.res.Configuration;
import android.graphics.Color;
import android.media.projection.MediaProjectionManager;
import android.os.BatteryManager;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.IBinder;
import android.provider.Settings;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.Gravity;
import android.view.View;
import android.view.WindowInsets;
import android.view.WindowManager;
import android.view.accessibility.AccessibilityEvent;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.Space;
import android.widget.TextView;
import android.widget.Toast;

import java.util.concurrent.atomic.AtomicInteger;

import static com.TuringSoftware.FrameGenerator.AppConstants.*;

/**
 * Activity principal de ScreenScaler.
 *
 * <p>Responsabilidades:
 * <ul>
 *   <li>Construir la UI programáticamente (sin XML).</li>
 *   <li>Gestionar permisos (accesibilidad, overlay, MediaProjection).</li>
 *   <li>Vincular y desvincular {@link ScreenCaptureService}.</li>
 *   <li>Persistir y restaurar preferencias del usuario.</li>
 * </ul>
 *
 * <p><b>Java 7</b>: no se usan lambdas ni referencias a métodos. Todas las
 * clases anónimas están escritas de forma explícita.
 */
public class ScreenScaler extends Activity {

    // ── Paleta ───────────────────────────────────────────────────────────────
    private static final int C_BG       = 0xFF080C18;
    private static final int C_SURF     = 0xFF0D1221;
    private static final int C_BORDER   = 0xFF1C2A42;
    private static final int C_TXT_PRI  = 0xFFDDE6FF;
    private static final int C_TXT_SEC  = 0xFF4E6A8A;
    private static final int C_TXT_MUT  = 0xFF223048;
    private static final int C_PERF     = 0xFF3B8EFF;
    private static final int C_PERF_DIM = 0xFF1A3A6A;
    private static final int C_SIFG     = 0xFF00D08A;
    private static final int C_SIFG_DIM = 0xFF0A3A28;
    private static final int C_ASIFG    = 0xFF9B4EFF;
    private static final int C_ASIFG_DIM= 0xFF28104A;
    private static final int C_STOP     = 0xFFFF3E5A;
    private static final int C_STOP_DIM = 0xFF4A0A14;
    private static final int C_GPU      = 0xFFFFB020;  // GPU — naranja
    private static final int C_GPU_DIM  = 0xFF3A2800;

    // ── UI principal ─────────────────────────────────────────────────────────
    private LinearLayout controlPanel;
    private Button       btnStartStop;

    // Textos de estado/modo
    private TextView statusText;
    private TextView sifgInfoText;
    private TextView generationInfoText;
    private TextView statsText;

    // Tarjeta de resolución — tres TextViews de valor
    private TextView tvSrcRes;
    private TextView tvDstRes;
    private TextView tvScale;
    /** Alias para updateResolutionText() — apunta a tvScale. */
    private TextView resolutionText;

    // Métricas en vivo
    private TextView tvFpsVal;
    private TextView tvFramesVal;
    private TextView tvDroppedVal;
    private TextView tvEfficiencyVal;
    private TextView tvSessionVal;
    private TextView tvCatMood;   // el gato cambia de cara según la eficiencia
    private int  catClickCount  = 0;
    private long catClickFirst  = 0L;
    private int  catPhraseIndex = 0;
    /** Alias para compatibilidad con código que usa fpsCounter.setText(). */
    private TextView fpsCounter;

    // Pills de modo (TextViews)
    private TextView pillPerf;
    private TextView pillGpu;
    private TextView pillSifg;
    private TextView pillAsifg;
    /** GradientDrawable del borde del status card, cambia color por modo. */
    private GradientDrawable statusCardBg;
    /** Pill CPU del toggle aceleración. */
    private TextView pillCpu;
    /** Fila contenedora del toggle CPU/GPU (se muestra/oculta según el modo). */
    private LinearLayout gpuToggleRow;

    // Tiles de configuración — TextViews de valor
    private TextView tvGenVal;
    private TextView tvColorVal;
    private TextView tvResVal;
    private TextView tvFishVal;
    private TextView tvTouchVal;
    private TextView tvCapModeVal;

    // Tiles completos (LinearLayout) — para setEnabled / setAlpha
    private LinearLayout tileGen;
    private LinearLayout tileColor;
    private LinearLayout tileRes;
    private LinearLayout tileFish;
    private LinearLayout tileTouchFwd;
    private LinearLayout tileCapMode;
    private LinearLayout tileFps;
    private TextView     tvFpsTargetVal;

    // ── Aliases de backcompat usados en diálogos ─────────────────────────────
    // En lugar de Button.setText() usamos los tvXxxVal directamente.
    // Estos aliases se mantienen SOLO para que el compilador no falle en
    // referencias residuales que se actualizan más abajo.
    private LinearLayout btnFrameGenerationConfig;
    private LinearLayout btnColorQualityConfig;
    private LinearLayout btnResolutionConfig;
    private LinearLayout btnFisheyeCorrection;
    private LinearLayout btnTouchForward;
    private LinearLayout btnCaptureMode;

    // ── Estado ──────────────────────────────────────────────────────────────
    private MediaProjectionManager mpManager;
    private volatile boolean       isCapturing      = false;
    private int                    targetWidth, targetHeight;
    private int                    sourceWidth, sourceHeight;
    private int                    screenDensityDpi;
    private int                    topInset, bottomInset;

    // Configuración del usuario (sincronizada con SharedPreferences)
    private float resolutionScale   = DEFAULT_RESOLUTION_SCALE;
    private int   framesToGenerate  = DEFAULT_FRAMES_TO_GENERATE;
    private int   colorQuality      = DEFAULT_COLOR_QUALITY;
    private int   fisheyeCorrection = DEFAULT_FISHEYE_CORRECTION;
    private int   sifgVersion       = DEFAULT_SIFG_VERSION;
    private AtomicInteger currentMode = new AtomicInteger(MODE_PERFORMANCE);
    /**
     * Reenvío de toques al sistema de accesibilidad.
     * Desactivado por defecto: el overlay es NOT_TOUCHABLE y no lo necesita.
     * El usuario puede activarlo manualmente si su caso de uso lo requiere.
     */
    private boolean touchForwardEnabled = DEFAULT_TOUCH_FORWARD;
    private int     targetFps           = DEFAULT_TARGET_FPS;
    /** 0=pantalla completa, 1=app específica (API 34+). */
    private int captureMode = CAPTURE_MODE_FULLSCREEN;

    // ── Servicio ──────────────────────────────────────────────────────────────
    private ScreenCaptureService captureService;
    private boolean              serviceBound = false;
    private Intent               resultData;
    private int                  resultCode;
    private SharedPreferences    prefs;
    private BatteryReceiver      batteryReceiver;

    // ── FPS monitor ───────────────────────────────────────────────────────────
    private final Handler  fpsHandler  = new Handler();
    private final Runnable fpsRunnable = new Runnable() {
        @Override
        public void run() {
            if (captureService != null && isCapturing) {
                int  fps    = captureService.getFps();
                int  frames = captureService.getTotalFrames();
                int  dropped= captureService.getDroppedFrames();
                int  effPct = captureService.getEfficiencyPct();
                long sess   = captureService.getSessionFrames();

                if (tvFpsVal        != null) tvFpsVal.setText(String.valueOf(fps));
                if (tvFramesVal     != null) tvFramesVal.setText(String.valueOf(frames));
                if (tvDroppedVal    != null) tvDroppedVal.setText(String.valueOf(dropped));
                if (tvEfficiencyVal != null) tvEfficiencyVal.setText(effPct + "%");
                if (tvSessionVal    != null) tvSessionVal.setText(String.valueOf(sess));

                // Cara del gato según eficiencia
                if (tvCatMood != null) {
                    String face;
                    if      (effPct >= 95) face = "( ●ω● )";   // perfecto
                    else if (effPct >= 80) face = "( ´ω` )";   // bien
                    else if (effPct >= 60) face = "( •ω• )";   // regular
                    else if (effPct >= 40) face = "( ≥ω≤ )";   // mal
                    else                   face = "( ×ω× )";   // desastre
                    tvCatMood.setText(face);
                }
            }
            fpsHandler.postDelayed(this, 1000);
        }
    };

    // ── Conexión al servicio ──────────────────────────────────────────────────
    private final ServiceConnection serviceConnection = new ServiceConnection() {
        @Override
        public void onServiceConnected(ComponentName name, IBinder service) {
            captureService = ((ScreenCaptureService.LocalBinder) service).getService();
            syncServiceSettings();
            serviceBound = true;
            if (resultData != null && resultCode == RESULT_OK) {
                startCaptureInternal();
            }
        }

        @Override
        public void onServiceDisconnected(ComponentName name) {
            serviceBound   = false;
            captureService = null;
        }
    };

    // ════════════════════════════════════════════════════════════════════════
    //  Ciclo de vida
    // ════════════════════════════════════════════════════════════════════════

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);

        prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);

        DisplayMetrics metrics = getDisplayMetrics();
        screenDensityDpi = metrics.densityDpi;

        detectNotchInsets();
        restorePreferences();
        adjustResolutions(metrics);
        createUI();
        loadStats();

        mpManager = (MediaProjectionManager) getSystemService(Context.MEDIA_PROJECTION_SERVICE);
        startAndBindService();

        batteryReceiver = new BatteryReceiver();
        registerReceiver(batteryReceiver, new IntentFilter(Intent.ACTION_BATTERY_CHANGED));
    }

    @Override
    protected void onDestroy() {
        safeUnregisterBatteryReceiver();
        fpsHandler.removeCallbacks(fpsRunnable);
        if (serviceBound) {
            unbindService(serviceConnection);
            serviceBound = false;
        }
        super.onDestroy();
    }

    @Override
    public void onBackPressed() {
        if (isCapturing) {
            Toast.makeText(this, "Deteniendo captura...", Toast.LENGTH_SHORT).show();
            stopCapture();
        } else {
            super.onBackPressed();
        }
    }

    @Override
    public void onConfigurationChanged(Configuration newConfig) {
        super.onConfigurationChanged(newConfig);
        DisplayMetrics metrics = getDisplayMetrics();
        adjustResolutions(metrics);
        if (resolutionText != null) updateResolutionText();

        if (captureService != null && isCapturing) {
            // Notificar al servicio — él redimensiona overlay + buffers + VirtualDisplay
            captureService.onOrientationChanged(
				sourceWidth, sourceHeight, targetWidth, targetHeight,
				metrics.densityDpi, topInset, bottomInset);
        }
    }

    // ════════════════════════════════════════════════════════════════════════
    //  Inicialización
    // ════════════════════════════════════════════════════════════════════════

    private DisplayMetrics getDisplayMetrics() {
        DisplayMetrics metrics = new DisplayMetrics();
        getWindowManager().getDefaultDisplay().getRealMetrics(metrics);
        return metrics;
    }

    /**
     * Detecta los insets del sistema (notch, barra de estado, barra de navegación)
     * y los persiste en prefs para uso del Service al recortar la imagen.
     *
     * <p>En API 28+ se usa {@code DisplayCutout}. En versiones anteriores se usa
     * el recurso {@code status_bar_height} del sistema como fallback.
     */
    private void detectNotchInsets() {
        // Fallback: leer el alto de la barra de estado de los recursos del sistema
        int statusBarFallback = 0;
        int navBarFallback    = 0;
        try {
            int resId = getResources().getIdentifier("status_bar_height", "dimen", "android");
            if (resId > 0) statusBarFallback = getResources().getDimensionPixelSize(resId);
            int navId = getResources().getIdentifier("navigation_bar_height", "dimen", "android");
            if (navId > 0) navBarFallback = getResources().getDimensionPixelSize(navId);
        } catch (Exception ignored) {}

        // Usar valores del cache si ya los detectamos antes
        topInset    = prefs.getInt(PREF_INSET_STATUS_BAR, statusBarFallback);
        bottomInset = prefs.getInt(PREF_INSET_NAV_BAR,    navBarFallback);

        if (Build.VERSION.SDK_INT >= 28) {
            getWindow().getDecorView().setOnApplyWindowInsetsListener(
				new View.OnApplyWindowInsetsListener() {
					@Override
					public WindowInsets onApplyWindowInsets(View v, WindowInsets insets) {
						android.view.DisplayCutout cutout = insets.getDisplayCutout();
						int statusTop = insets.getSystemWindowInsetTop();
						int navBottom = insets.getSystemWindowInsetBottom();

						// DisplayCutout puede añadir espacio extra al top
						if (cutout != null) {
							statusTop = Math.max(statusTop, cutout.getSafeInsetTop());
						}

						// Solo actualizar si los valores son más precisos que el fallback
						if (statusTop > 0 || navBottom > 0) {
							topInset    = statusTop;
							bottomInset = navBottom;
							prefs.edit()
								.putInt(PREF_INSET_STATUS_BAR, topInset)
								.putInt(PREF_INSET_NAV_BAR,    bottomInset)
								.apply();
						}
						return insets;
					}
				});
        } else {
            // Pre-API 28: persistir el fallback si no hay nada guardado
            prefs.edit()
                .putInt(PREF_INSET_STATUS_BAR, topInset)
                .putInt(PREF_INSET_NAV_BAR,    bottomInset)
                .apply();
        }
    }

    private void restorePreferences() {
        resolutionScale      = prefs.getFloat  (PREF_RESOLUTION_SCALE,    DEFAULT_RESOLUTION_SCALE);
        framesToGenerate     = prefs.getInt    (PREF_FRAMES_TO_GENERATE,  DEFAULT_FRAMES_TO_GENERATE);
        colorQuality         = prefs.getInt    (PREF_COLOR_QUALITY,       DEFAULT_COLOR_QUALITY);
        fisheyeCorrection    = prefs.getInt    (PREF_FISHEYE_CORRECTION,  DEFAULT_FISHEYE_CORRECTION);
        sifgVersion          = prefs.getInt    (PREF_SIFG_VERSION,        DEFAULT_SIFG_VERSION);
        touchForwardEnabled  = prefs.getBoolean(PREF_TOUCH_FORWARD,       DEFAULT_TOUCH_FORWARD);
        targetFps            = prefs.getInt    (PREF_TARGET_FPS,           DEFAULT_TARGET_FPS);
        captureMode          = prefs.getInt    (PREF_CAPTURE_MODE,        CAPTURE_MODE_FULLSCREEN);
    }

    private void startAndBindService() {
        Intent serviceIntent = new Intent(this, ScreenCaptureService.class);
        if (Build.VERSION.SDK_INT >= 26) startForegroundService(serviceIntent);
        else                             startService(serviceIntent);
        bindService(serviceIntent, serviceConnection, Context.BIND_AUTO_CREATE);
    }

    private void safeUnregisterBatteryReceiver() {
        if (batteryReceiver != null) {
            try {
                unregisterReceiver(batteryReceiver);
            } catch (IllegalArgumentException e) {
                Log.e(TAG, "BatteryReceiver ya desregistrado", e);
            }
        }
    }

    // ════════════════════════════════════════════════════════════════════════
    //  Resolución — cache precalculado
    // ════════════════════════════════════════════════════════════════════════

    /**
     * Lee las resoluciones del cache de prefs para la orientación y escala actuales.
     * Si el cache no existe aún (primer inicio o pantalla nueva), lo calcula y persiste.
     */
    private void adjustResolutions(DisplayMetrics metrics) {
        boolean isLandscape = metrics.widthPixels > metrics.heightPixels;
        String cacheKey = getResCacheKey(isLandscape, resolutionScale);

        String cached = prefs.getString(cacheKey, null);
        if (cached != null) {
            // Formato: "tW:tH:sW:sH"
            try {
                String[] parts = cached.split(":");
                targetWidth  = Integer.parseInt(parts[0]);
                targetHeight = Integer.parseInt(parts[1]);
                sourceWidth  = Integer.parseInt(parts[2]);
                sourceHeight = Integer.parseInt(parts[3]);
                Log.d(TAG, "Resoluciones (cache): " + cached
					  + "  orient=" + (isLandscape ? "L" : "P"));
                return;
            } catch (Exception e) {
                Log.w(TAG, "Cache de resolución corrupto, recalculando", e);
            }
        }
        // Cache vacío o corrupto → calcular y guardar las 6 combinaciones
        computeAndCacheAllResolutions(metrics);
    }

    /**
     * Calcula y persiste las 6 combinaciones portrait/landscape × 25/50/75%
     * usando las métricas actuales de la pantalla.
     * Solo se ejecuta en el primer inicio o si el cache se invalida.
     */
    private void computeAndCacheAllResolutions(DisplayMetrics metrics) {
        // Determinar el lado corto y el lado largo de la pantalla física
        int shortSide = Math.min(metrics.widthPixels, metrics.heightPixels);
        int longSide  = Math.max(metrics.widthPixels, metrics.heightPixels);

        float[] scales = {0.25f, 0.5f, 0.75f};
        String[] portraitKeys   = {PREF_RES_CACHE_P25, PREF_RES_CACHE_P50, PREF_RES_CACHE_P75};
        String[] landscapeKeys  = {PREF_RES_CACHE_L25, PREF_RES_CACHE_L50, PREF_RES_CACHE_L75};

        SharedPreferences.Editor ed = prefs.edit();
        for (int i = 0; i < 3; i++) {
            // Portrait: ancho=shortSide, alto=longSide
            int tWp = (shortSide / 8) * 8;
            int tHp = (longSide  / 8) * 8;
            int sWp = Math.max(8, ((int)(tWp * scales[i])) / 8 * 8);
            int sHp = Math.max(8, ((int)(tHp * scales[i])) / 8 * 8);
            ed.putString(portraitKeys[i],  tWp+":"+tHp+":"+sWp+":"+sHp);

            // Landscape: ancho=longSide, alto=shortSide
            int tWl = (longSide  / 8) * 8;
            int tHl = (shortSide / 8) * 8;
            int sWl = Math.max(8, ((int)(tWl * scales[i])) / 8 * 8);
            int sHl = Math.max(8, ((int)(tHl * scales[i])) / 8 * 8);
            ed.putString(landscapeKeys[i], tWl+":"+tHl+":"+sWl+":"+sHl);
        }
        ed.apply();

        // Ahora leer el valor correcto para la orientación actual
        boolean isLandscape = metrics.widthPixels > metrics.heightPixels;
        int tW = isLandscape ? (longSide/8)*8  : (shortSide/8)*8;
        int tH = isLandscape ? (shortSide/8)*8 : (longSide/8)*8;
        targetWidth  = tW;
        targetHeight = tH;
        sourceWidth  = Math.max(8, ((int)(tW * resolutionScale)) / 8 * 8);
        sourceHeight = Math.max(8, ((int)(tH * resolutionScale)) / 8 * 8);

        Log.d(TAG, "Resoluciones (calculadas y en cache): "
			  + sourceWidth + "x" + sourceHeight
			  + " → " + targetWidth + "x" + targetHeight);
    }

    /** Clave de cache para la combinación orientación + escala. */
    private static String getResCacheKey(boolean landscape, float scale) {
        String orient = landscape ? "L" : "P";
        if (scale <= 0.26f)      return landscape ? PREF_RES_CACHE_L25 : PREF_RES_CACHE_P25;
        else if (scale <= 0.51f) return landscape ? PREF_RES_CACHE_L50 : PREF_RES_CACHE_P50;
        else                     return landscape ? PREF_RES_CACHE_L75 : PREF_RES_CACHE_P75;
    }

    /**
     * Invalida el cache de resoluciones (p.ej. si el usuario conecta/desconecta
     * una pantalla externa o cambia la densidad del sistema).
     * Al próximo {@code adjustResolutions} se recalculará automáticamente.
     */
    private void invalidateResolutionCache() {
        prefs.edit()
            .remove(PREF_RES_CACHE_P25).remove(PREF_RES_CACHE_P50).remove(PREF_RES_CACHE_P75)
            .remove(PREF_RES_CACHE_L25).remove(PREF_RES_CACHE_L50).remove(PREF_RES_CACHE_L75)
            .apply();
    }

    private void updateResolutionText() {
        if (tvSrcRes != null) tvSrcRes.setText(sourceWidth + "×" + sourceHeight);
        if (tvDstRes != null) tvDstRes.setText(targetWidth + "×" + targetHeight);
        if (tvScale  != null) tvScale.setText((int)(resolutionScale * 100) + "%");
        if (tvResVal != null) tvResVal.setText((int)(resolutionScale * 100) + "%");
    }

    // ════════════════════════════════════════════════════════════════════════
    //  UI — construcción programática
    // ════════════════════════════════════════════════════════════════════════

    /** dp → px. Densidad cacheada — evita getDisplayMetrics() en cada llamada durante buildUI. */
    private float cachedDensity = 0f;
    private int dp(int v) {
        if (cachedDensity == 0f) cachedDensity = getResources().getDisplayMetrics().density;
        return Math.round(v * cachedDensity);
    }

    /** GradientDrawable de esquinas redondeadas con borde opcional. */
    private GradientDrawable gd(int fill, int rDp, int borderColor, int borderDp) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(fill);
        g.setCornerRadius(dp(rDp));
        if (borderDp > 0) g.setStroke(dp(borderDp), borderColor);
        return g;
    }

    /** LinearLayout vertical estilo card. */
    private LinearLayout makeCard(int pDp, int borderColor) {
        LinearLayout c = new LinearLayout(this);
        c.setOrientation(LinearLayout.VERTICAL);
        c.setLayoutParams(new LinearLayout.LayoutParams(
							  LinearLayout.LayoutParams.MATCH_PARENT,
							  LinearLayout.LayoutParams.WRAP_CONTENT));
        c.setBackground(gd(C_SURF, 16, borderColor, 1));
        int p = dp(pDp);
        c.setPadding(p, p, p, p);
        return c;
    }

    /** Separador horizontal 1dp. */
    private View hDiv() {
        View v = new View(this);
        v.setLayoutParams(new LinearLayout.LayoutParams(
							  LinearLayout.LayoutParams.MATCH_PARENT, dp(1)));
        v.setBackgroundColor(C_BORDER);
        return v;
    }

    /** Separador vertical 1dp. */
    private View vDiv() {
        View v = new View(this);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(dp(1),
																	 LinearLayout.LayoutParams.MATCH_PARENT);
        v.setLayoutParams(lp);
        v.setBackgroundColor(C_BORDER);
        return v;
    }

    /** Label de sección (uppercase, monospace, muted). */
    private TextView sectionLabel(String text) {
        TextView tv = new TextView(this);
        tv.setText(text);
        tv.setTextSize(9);
        tv.setTextColor(C_TXT_MUT);
        tv.setTypeface(Typeface.MONOSPACE);
        tv.setLetterSpacing(0.18f);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
			LinearLayout.LayoutParams.MATCH_PARENT,
			LinearLayout.LayoutParams.WRAP_CONTENT);
        lp.setMargins(dp(2), dp(22), 0, dp(8));
        tv.setLayoutParams(lp);
        return tv;
    }

    // ════════════════════════════════════════════════════════════════════════
    //  Construcción del layout principal
    // ════════════════════════════════════════════════════════════════════════

    private void createUI() {
        ScrollView scroll = new ScrollView(this);
        scroll.setBackgroundColor(C_BG);
        scroll.setLayoutParams(new LinearLayout.LayoutParams(
								   LinearLayout.LayoutParams.MATCH_PARENT,
								   LinearLayout.LayoutParams.MATCH_PARENT));
        scroll.setFillViewport(true);

        controlPanel = new LinearLayout(this);
        controlPanel.setOrientation(LinearLayout.VERTICAL);
        controlPanel.setLayoutParams(new LinearLayout.LayoutParams(
										 LinearLayout.LayoutParams.MATCH_PARENT,
										 LinearLayout.LayoutParams.WRAP_CONTENT));
        int pH = dp(20), pV = dp(28);
        controlPanel.setPadding(pH, pV, pH, dp(40));

        buildHeader();
        buildResCard();
        buildModeRow();
        buildStatusCard();
        buildConfigGrid();
        buildMetricsCard();
        buildStartStop();

        scroll.addView(controlPanel);
        setContentView(scroll);
        setMode(MODE_PERFORMANCE);
    }

    // ── Header ────────────────────────────────────────────────────────────────

    private void buildHeader() {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(android.view.Gravity.CENTER_VERTICAL);
        row.setLayoutParams(new LinearLayout.LayoutParams(
								LinearLayout.LayoutParams.MATCH_PARENT,
								LinearLayout.LayoutParams.WRAP_CONTENT));

        // Bloque título
        LinearLayout titleCol = new LinearLayout(this);
        titleCol.setOrientation(LinearLayout.VERTICAL);
        titleCol.setLayoutParams(new LinearLayout.LayoutParams(
									 0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f));

        TextView tvTitle = new TextView(this);
        tvTitle.setText("KITIKAT");
        tvTitle.setTextSize(22);
        tvTitle.setTextColor(C_TXT_PRI);
        tvTitle.setTypeface(Typeface.create("sans-serif-condensed", Typeface.BOLD));
        tvTitle.setLetterSpacing(0.04f);
        titleCol.addView(tvTitle);

        TextView tvSub = new TextView(this);
        tvSub.setText("SCALER  ·  v1.0  ·  TURING SOFTWARE");
        tvSub.setTextSize(9);
        tvSub.setTextColor(C_TXT_SEC);
        tvSub.setTypeface(Typeface.MONOSPACE);
        tvSub.setLetterSpacing(0.10f);
        LinearLayout.LayoutParams subLp = new LinearLayout.LayoutParams(
			LinearLayout.LayoutParams.WRAP_CONTENT,
			LinearLayout.LayoutParams.WRAP_CONTENT);
        subLp.setMargins(0, dp(4), 0, 0);
        tvSub.setLayoutParams(subLp);
        titleCol.addView(tvSub);

        row.addView(titleCol);
        controlPanel.addView(row);
    }

    // ── Resolution card ───────────────────────────────────────────────────────

    private void buildResCard() {
        controlPanel.addView(sectionLabel("RESOLUCIÓN  ·  PANTALLA"));

        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.HORIZONTAL);
        card.setLayoutParams(new LinearLayout.LayoutParams(
								 LinearLayout.LayoutParams.MATCH_PARENT,
								 LinearLayout.LayoutParams.WRAP_CONTENT));
        card.setBackground(gd(C_SURF, 16, C_BORDER, 1));

        // Columna CAPTURA
        tvSrcRes = new TextView(this);
        tvSrcRes.setText(sourceWidth + "×" + sourceHeight);
        card.addView(makeResCol("CAPTURA", tvSrcRes));
        card.addView(vDiv());

        // Columna SALIDA
        tvDstRes = new TextView(this);
        tvDstRes.setText(targetWidth + "×" + targetHeight);
        card.addView(makeResCol("SALIDA", tvDstRes));
        card.addView(vDiv());

        // Columna ESCALA
        tvScale = new TextView(this);
        tvScale.setText((int)(resolutionScale * 100) + "%");
        resolutionText = tvScale;  // alias para updateResolutionText()
        card.addView(makeResCol("ESCALA", tvScale));

        controlPanel.addView(card);
    }

    private LinearLayout makeResCol(String label, TextView tvVal) {
        LinearLayout col = new LinearLayout(this);
        col.setOrientation(LinearLayout.VERTICAL);
        col.setLayoutParams(new LinearLayout.LayoutParams(
								0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f));
        col.setGravity(android.view.Gravity.CENTER);
        col.setPadding(dp(8), dp(14), dp(8), dp(14));

        TextView tvLbl = new TextView(this);
        tvLbl.setText(label);
        tvLbl.setTextSize(8.5f);
        tvLbl.setTextColor(C_TXT_SEC);
        tvLbl.setTypeface(Typeface.MONOSPACE);
        tvLbl.setLetterSpacing(0.14f);
        tvLbl.setGravity(android.view.Gravity.CENTER);
        col.addView(tvLbl);

        tvVal.setTextSize(13);
        tvVal.setTextColor(C_TXT_PRI);
        tvVal.setTypeface(Typeface.MONOSPACE);
        tvVal.setGravity(android.view.Gravity.CENTER);
        LinearLayout.LayoutParams vlp = new LinearLayout.LayoutParams(
			LinearLayout.LayoutParams.MATCH_PARENT,
			LinearLayout.LayoutParams.WRAP_CONTENT);
        vlp.setMargins(0, dp(4), 0, 0);
        tvVal.setLayoutParams(vlp);
        col.addView(tvVal);

        return col;
    }

    // ── Mode pills ────────────────────────────────────────────────────────────

    private void buildModeRow() {
        controlPanel.addView(sectionLabel("MODO  DE  PROCESAMIENTO"));

        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setLayoutParams(new LinearLayout.LayoutParams(
                                 LinearLayout.LayoutParams.MATCH_PARENT,
                                 LinearLayout.LayoutParams.WRAP_CONTENT));
        card.setBackground(gd(C_SURF, 16, C_BORDER, 1));
        card.setPadding(dp(4), dp(4), dp(4), dp(4));

        // Fila de pills de modo
        LinearLayout pillRow = new LinearLayout(this);
        pillRow.setOrientation(LinearLayout.HORIZONTAL);
        pillRow.setLayoutParams(new LinearLayout.LayoutParams(
                                    LinearLayout.LayoutParams.MATCH_PARENT,
                                    LinearLayout.LayoutParams.WRAP_CONTENT));

        pillPerf  = buildPill("RENDIMIENTO", MODE_PERFORMANCE);
        pillSifg  = buildPill("SIFg",        MODE_SIFG1);
        pillAsifg = buildPill("ASIFg  ★",  MODE_ASIFG);

        pillRow.addView(pillPerf);
        pillRow.addView(pillSifg);
        pillRow.addView(pillAsifg);
        card.addView(pillRow);

        // Divisor entre pills y toggle CPU/GPU
        View gpuDiv = new View(this);
        gpuDiv.setLayoutParams(new LinearLayout.LayoutParams(
								   LinearLayout.LayoutParams.MATCH_PARENT, dp(1)));
        gpuDiv.setBackgroundColor(C_BORDER);
        card.addView(gpuDiv);

        // Fila CPU/GPU toggle
        gpuToggleRow = new LinearLayout(this);
        gpuToggleRow.setOrientation(LinearLayout.HORIZONTAL);
        gpuToggleRow.setGravity(android.view.Gravity.CENTER_VERTICAL);
        LinearLayout.LayoutParams gpuRowLp = new LinearLayout.LayoutParams(
			LinearLayout.LayoutParams.MATCH_PARENT,
			LinearLayout.LayoutParams.WRAP_CONTENT);
        gpuRowLp.setMargins(dp(10), dp(6), dp(10), dp(6));
        gpuToggleRow.setLayoutParams(gpuRowLp);

        TextView tvGpuLbl = new TextView(this);
        tvGpuLbl.setText("ACELERACIÓN");
        tvGpuLbl.setTextSize(9f);
        tvGpuLbl.setTextColor(C_TXT_MUT);
        tvGpuLbl.setTypeface(Typeface.MONOSPACE);
        tvGpuLbl.setLetterSpacing(0.14f);
        tvGpuLbl.setLayoutParams(new LinearLayout.LayoutParams(
									 0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f));
        gpuToggleRow.addView(tvGpuLbl);

        // Pill CPU
        pillCpu = new TextView(this);
        pillCpu.setText("CPU");
        pillCpu.setTextSize(11);
        pillCpu.setTypeface(Typeface.create("sans-serif-medium", Typeface.NORMAL));
        pillCpu.setGravity(android.view.Gravity.CENTER);
        LinearLayout.LayoutParams cpuLp = new LinearLayout.LayoutParams(dp(64), dp(32));
        cpuLp.setMargins(dp(3), 0, dp(3), 0);
        pillCpu.setLayoutParams(cpuLp);
        pillCpu.setBackground(gd(C_PERF_DIM, 10, C_PERF, 1));
        pillCpu.setTextColor(C_TXT_PRI);
        pillCpu.setClickable(true);
        pillCpu.setFocusable(true);
        pillCpu.setOnClickListener(new View.OnClickListener() {
                @Override public void onClick(View v) {
                    int m = currentMode.get();
                    if (AppConstants.isGpuMode(m)) setMode(AppConstants.toCpuMode(m));
                }
            });
        gpuToggleRow.addView(pillCpu);

        // Pill GPU
        pillGpu = new TextView(this);
        pillGpu.setText("GPU");
        pillGpu.setTextSize(11);
        pillGpu.setTypeface(Typeface.create("sans-serif-medium", Typeface.NORMAL));
        pillGpu.setGravity(android.view.Gravity.CENTER);
        LinearLayout.LayoutParams gpuLp = new LinearLayout.LayoutParams(dp(64), dp(32));
        gpuLp.setMargins(dp(3), 0, dp(3), 0);
        pillGpu.setLayoutParams(gpuLp);
        pillGpu.setBackground(gd(0x00000000, 10, C_BORDER, 1));
        pillGpu.setTextColor(C_TXT_SEC);
        pillGpu.setClickable(true);
        pillGpu.setFocusable(true);
        pillGpu.setOnClickListener(new View.OnClickListener() {
                @Override public void onClick(View v) {
                    int m = currentMode.get();
                    if (!AppConstants.isGpuMode(m)) setMode(AppConstants.toGpuMode(m));
                }
            });
        gpuToggleRow.addView(pillGpu);

        card.addView(gpuToggleRow);
        controlPanel.addView(card);
        updateGpuToggleVisibility();
    }

    private TextView buildPill(final String label, final int mode) {
        final TextView tv = new TextView(this);
        tv.setText(label);
        tv.setTextSize(11);
        tv.setTextColor(C_TXT_SEC);
        tv.setTypeface(Typeface.create("sans-serif-medium", Typeface.NORMAL));
        tv.setLetterSpacing(0.04f);
        tv.setGravity(android.view.Gravity.CENTER);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, dp(44), 1f);
        lp.setMargins(dp(3), dp(3), dp(3), dp(3));
        tv.setLayoutParams(lp);
        tv.setBackground(gd(0x00000000, 12, C_BORDER, 1));
        tv.setClickable(true);
        tv.setFocusable(true);
        tv.setOnClickListener(new View.OnClickListener() {
				@Override public void onClick(View v) {
					if (mode == MODE_SIFG1) showSIFgVersionDialog();
					else                    setMode(mode);
				}
			});
        return tv;
    }

    // ── Status card ───────────────────────────────────────────────────────────

    private void buildStatusCard() {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
			LinearLayout.LayoutParams.MATCH_PARENT,
			LinearLayout.LayoutParams.WRAP_CONTENT);
        lp.setMargins(0, dp(10), 0, 0);

        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.HORIZONTAL);
        card.setGravity(android.view.Gravity.CENTER_VERTICAL);
        card.setLayoutParams(lp);
        card.setPadding(dp(16), dp(14), dp(16), dp(14));
        statusCardBg = gd(C_SURF, 16, C_PERF, 1);
        card.setBackground(statusCardBg);

        // Barra de acento izquierda
        View accent = new View(this);
        LinearLayout.LayoutParams aLp = new LinearLayout.LayoutParams(dp(3),
																	  LinearLayout.LayoutParams.MATCH_PARENT);
        aLp.setMargins(0, 0, dp(12), 0);
        accent.setLayoutParams(aLp);
        accent.setBackground(gd(C_PERF, 2, 0, 0));
        card.addView(accent);

        // Texto
        LinearLayout textCol = new LinearLayout(this);
        textCol.setOrientation(LinearLayout.VERTICAL);
        textCol.setLayoutParams(new LinearLayout.LayoutParams(
									0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f));

        statusText = new TextView(this);
        statusText.setTextSize(14);
        statusText.setTextColor(C_TXT_PRI);
        statusText.setTypeface(Typeface.create("sans-serif-medium", Typeface.NORMAL));
        textCol.addView(statusText);

        sifgInfoText = new TextView(this);
        sifgInfoText.setTextSize(11);
        sifgInfoText.setTextColor(C_TXT_SEC);
        LinearLayout.LayoutParams ilp = new LinearLayout.LayoutParams(
			LinearLayout.LayoutParams.MATCH_PARENT,
			LinearLayout.LayoutParams.WRAP_CONTENT);
        ilp.setMargins(0, dp(3), 0, 0);
        sifgInfoText.setLayoutParams(ilp);
        textCol.addView(sifgInfoText);

        card.addView(textCol);
        controlPanel.addView(card);
    }

    // ── Config grid ───────────────────────────────────────────────────────────

    private void buildConfigGrid() {
        controlPanel.addView(sectionLabel("CONFIGURACIÓN"));

        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setLayoutParams(new LinearLayout.LayoutParams(
								 LinearLayout.LayoutParams.MATCH_PARENT,
								 LinearLayout.LayoutParams.WRAP_CONTENT));
        card.setBackground(gd(C_SURF, 16, C_BORDER, 1));

        // Fila 1: Frames | Color
        LinearLayout r1 = makeGridRow();
        String genLabel = framesToGenerate > 0
			? framesToGenerate + "× (×" + (framesToGenerate+1) + " FPS)"
			: "—";
        tileGen = makeTile("FRAMES GEN", genLabel,
			new View.OnClickListener() {
				@Override public void onClick(View v) { showFrameGenerationDialog(); }
			});
        tvGenVal = (TextView) tileGen.getTag();
        btnFrameGenerationConfig = tileGen;

        tileColor = makeTile("COLOR", getColorQualityLabel(),
			new View.OnClickListener() {
				@Override public void onClick(View v) { showColorQualityDialog(); }
			});
        tvColorVal = (TextView) tileColor.getTag();
        btnColorQualityConfig = tileColor;

        r1.addView(tileGen);
        r1.addView(vDiv());
        r1.addView(tileColor);
        card.addView(r1);
        card.addView(hDiv());

        // Fila 2: Resolución | Fisheye
        LinearLayout r2 = makeGridRow();
        tileRes = makeTile("RESOLUCIÓN", (int)(resolutionScale * 100) + "%",
			new View.OnClickListener() {
				@Override public void onClick(View v) { showResolutionDialog(); }
			});
        tvResVal = (TextView) tileRes.getTag();
        btnResolutionConfig = tileRes;

        String fishLabel = fisheyeCorrection == 0 ? "OFF"
			: (fisheyeCorrection > 0 ? "+" : "") + fisheyeCorrection;
        tileFish = makeTile("FISHEYE", fishLabel,
			new View.OnClickListener() {
				@Override public void onClick(View v) { showFisheyeDialog(); }
			});
        tvFishVal = (TextView) tileFish.getTag();
        btnFisheyeCorrection = tileFish;

        r2.addView(tileRes);
        r2.addView(vDiv());
        r2.addView(tileFish);
        card.addView(r2);
        card.addView(hDiv());

        // Fila 3: Toque | Captura
        LinearLayout r3 = makeGridRow();
        tileTouchFwd = makeTile("TOQUE FWD",
			touchForwardEnabled ? "ON" : "OFF",
			new View.OnClickListener() {
				@Override public void onClick(View v) { showTouchForwardDialog(); }
			});
        tvTouchVal = (TextView) tileTouchFwd.getTag();
        btnTouchForward = tileTouchFwd;

        tileCapMode = makeTile("CAPTURA",
			captureMode == CAPTURE_MODE_SINGLE_APP ? "APP" : "FULL",
			new View.OnClickListener() {
				@Override public void onClick(View v) { showCaptureModeDialog(); }
			});
        tvCapModeVal = (TextView) tileCapMode.getTag();
        btnCaptureMode = tileCapMode;

        r3.addView(tileTouchFwd);
        r3.addView(vDiv());
        r3.addView(tileCapMode);
        card.addView(r3);
        card.addView(hDiv());

        // Fila 4: FPS objetivo (ocupa todo el ancho)
        LinearLayout r4 = makeGridRow();
        tileFps = makeTile("FPS TARGET", targetFps + " fps",
			new View.OnClickListener() {
				@Override public void onClick(View v) { showTargetFpsDialog(); }
			});
        tvFpsTargetVal = (TextView) tileFps.getTag();
        // Extender el tile para ocupar el ancho completo
        tileFps.setLayoutParams(new LinearLayout.LayoutParams(
									LinearLayout.LayoutParams.MATCH_PARENT,
									LinearLayout.LayoutParams.MATCH_PARENT));
        r4.addView(tileFps);
        card.addView(r4);

        controlPanel.addView(card);
    }

    /** Fila horizontal de tiles, altura fija. */
    private LinearLayout makeGridRow() {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setLayoutParams(new LinearLayout.LayoutParams(
								LinearLayout.LayoutParams.MATCH_PARENT, dp(72)));
        return row;
    }

    /**
     * Tile de configuración: label arriba, valor grande abajo. Clickable.
     * Guarda el TextView de valor en setTag() para recuperarlo.
     */
    private LinearLayout makeTile(String label, String value,
								  final View.OnClickListener listener) {
        final LinearLayout tile = new LinearLayout(this);
        tile.setOrientation(LinearLayout.VERTICAL);
        tile.setLayoutParams(new LinearLayout.LayoutParams(
								 0, LinearLayout.LayoutParams.MATCH_PARENT, 1f));
        tile.setGravity(android.view.Gravity.CENTER);
        tile.setPadding(dp(10), dp(10), dp(10), dp(10));
        tile.setClickable(true);
        tile.setFocusable(true);
        tile.setOnClickListener(listener);

        TextView tvLbl = new TextView(this);
        tvLbl.setText(label);
        tvLbl.setTextSize(8.5f);
        tvLbl.setTextColor(C_TXT_SEC);
        tvLbl.setTypeface(Typeface.MONOSPACE);
        tvLbl.setLetterSpacing(0.14f);
        tvLbl.setGravity(android.view.Gravity.CENTER);
        tvLbl.setLayoutParams(new LinearLayout.LayoutParams(
								  LinearLayout.LayoutParams.MATCH_PARENT,
								  LinearLayout.LayoutParams.WRAP_CONTENT));

        TextView tvVal = new TextView(this);
        tvVal.setText(value);
        tvVal.setTextSize(16);
        tvVal.setTextColor(C_TXT_PRI);
        tvVal.setTypeface(Typeface.create("sans-serif-medium", Typeface.NORMAL));
        tvVal.setGravity(android.view.Gravity.CENTER);
        LinearLayout.LayoutParams vlp = new LinearLayout.LayoutParams(
			LinearLayout.LayoutParams.MATCH_PARENT,
			LinearLayout.LayoutParams.WRAP_CONTENT);
        vlp.setMargins(0, dp(4), 0, 0);
        tvVal.setLayoutParams(vlp);

        tile.addView(tvLbl);
        tile.addView(tvVal);
        tile.setTag(tvVal);  // ← para recuperar tvVal externamente
        return tile;
    }

    // ── Metrics card ──────────────────────────────────────────────────────────

    // ── Colores de acento para métricas ──────────────────────────────────────
    private static final int C_FPS     = 0xFF3B8EFF;  // azul — FPS
    private static final int C_GEN     = 0xFF00D08A;  // verde — generados/sesión
    private static final int C_DROP    = 0xFFFF4455;  // rojo  — perdidos
    private static final int C_EFF     = 0xFFFFB020;  // naranja — eficiencia

    private void buildMetricsCard() {
        controlPanel.addView(sectionLabel("MÉTRICAS  EN  VIVO"));

        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setLayoutParams(new LinearLayout.LayoutParams(
								 LinearLayout.LayoutParams.MATCH_PARENT,
								 LinearLayout.LayoutParams.WRAP_CONTENT));
        card.setBackground(gd(C_SURF, 16, C_BORDER, 1));
        card.setPadding(0, dp(14), 0, dp(14));

        // ── Fila del gato + stats ────────────────────────────────────────────
        LinearLayout catRow = new LinearLayout(this);
        catRow.setOrientation(LinearLayout.HORIZONTAL);
        catRow.setLayoutParams(new LinearLayout.LayoutParams(
								   LinearLayout.LayoutParams.MATCH_PARENT,
								   LinearLayout.LayoutParams.WRAP_CONTENT));
        catRow.setGravity(android.view.Gravity.CENTER_VERTICAL);

        // ── Columna izquierda: gato ASCII ────────────────────────────────────
        LinearLayout catCol = new LinearLayout(this);
        catCol.setOrientation(LinearLayout.VERTICAL);
        catCol.setGravity(android.view.Gravity.CENTER);
        LinearLayout.LayoutParams catColLp = new LinearLayout.LayoutParams(dp(100), LinearLayout.LayoutParams.WRAP_CONTENT);
        catColLp.setMargins(dp(8), 0, 0, 0);
        catCol.setLayoutParams(catColLp);

        // Orejas
        TextView tvEars = new TextView(this);
        tvEars.setText("  /\\_____/\\");
        tvEars.setTypeface(Typeface.MONOSPACE);
        tvEars.setTextSize(9f);
        tvEars.setTextColor(C_TXT_SEC);
        tvEars.setGravity(android.view.Gravity.CENTER);
        catCol.addView(tvEars);

        // Cara (cambia con eficiencia)
        tvCatMood = new TextView(this);
        tvCatMood.setText("( ●ω● )");
        tvCatMood.setTypeface(Typeface.MONOSPACE);
        tvCatMood.setTextSize(11f);
        tvCatMood.setTextColor(C_TXT_PRI);
        tvCatMood.setGravity(android.view.Gravity.CENTER);
        catCol.addView(tvCatMood);

        // Cuerpo
        TextView tvBody = new TextView(this);
        tvBody.setText("  )   (  ");
        tvBody.setTypeface(Typeface.MONOSPACE);
        tvBody.setTextSize(9f);
        tvBody.setTextColor(C_TXT_SEC);
        tvBody.setGravity(android.view.Gravity.CENTER);
        catCol.addView(tvBody);

        // Patas — señalan hacia la derecha
        TextView tvPaws = new TextView(this);
        tvPaws.setText(" (_)━━(►)");
        tvPaws.setTypeface(Typeface.MONOSPACE);
        tvPaws.setTextSize(9f);
        tvPaws.setTextColor(C_SIFG);
        tvPaws.setGravity(android.view.Gravity.CENTER);
        catCol.addView(tvPaws);

        // Etiqueta del gato
        TextView tvCatLabel = new TextView(this);
        tvCatLabel.setText("SENSEI CAT");
        tvCatLabel.setTypeface(Typeface.MONOSPACE);
        tvCatLabel.setTextSize(7f);
        tvCatLabel.setTextColor(C_TXT_MUT);
        tvCatLabel.setLetterSpacing(0.12f);
        tvCatLabel.setGravity(android.view.Gravity.CENTER);
        LinearLayout.LayoutParams lblLp = new LinearLayout.LayoutParams(
			LinearLayout.LayoutParams.WRAP_CONTENT,
			LinearLayout.LayoutParams.WRAP_CONTENT);
        lblLp.setMargins(0, dp(4), 0, 0);
        tvCatLabel.setLayoutParams(lblLp);
        catCol.addView(tvCatLabel);

        // ── Click listener: frases + easter egg 7 clics ────────────────────
        catCol.setOnClickListener(new View.OnClickListener() {
				@Override public void onClick(View v) {
					long now = System.currentTimeMillis();
					if (now - catClickFirst > 2000L) {
						catClickCount = 0;
						catClickFirst = now;
					}
					catClickCount++;
					if (catClickCount >= 7) {
						catClickCount = 0;
						showAboutDialog();
					} else {
						showCatPhrase();
					}
				}
			});

        catRow.addView(catCol);

        // ── Divisor vertical delgado ─────────────────────────────────────────
        View div = new View(this);
        LinearLayout.LayoutParams divLp = new LinearLayout.LayoutParams(dp(1), LinearLayout.LayoutParams.MATCH_PARENT);
        divLp.setMargins(dp(6), dp(8), dp(6), dp(8));
        div.setLayoutParams(divLp);
        div.setBackgroundColor(C_BORDER);
        catRow.addView(div);

        // ── Columna derecha: grid 2×2 de métricas ────────────────────────────
        LinearLayout statsCol = new LinearLayout(this);
        statsCol.setOrientation(LinearLayout.VERTICAL);
        statsCol.setLayoutParams(new LinearLayout.LayoutParams(
									 0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f));

        // Fila superior: FPS | SESIÓN
        LinearLayout row1 = new LinearLayout(this);
        row1.setOrientation(LinearLayout.HORIZONTAL);
        row1.setLayoutParams(new LinearLayout.LayoutParams(
								 LinearLayout.LayoutParams.MATCH_PARENT,
								 LinearLayout.LayoutParams.WRAP_CONTENT));
        tvFpsVal    = buildStatBlock(row1, "FPS",   "—", C_FPS);
        row1.addView(vDiv());
        tvSessionVal = buildStatBlock(row1, "SESIÓN", "—", C_GEN);
        statsCol.addView(row1);
        statsCol.addView(hDiv());

        // Fila inferior: PERDIDOS | EFICIENCIA
        LinearLayout row2 = new LinearLayout(this);
        row2.setOrientation(LinearLayout.HORIZONTAL);
        row2.setLayoutParams(new LinearLayout.LayoutParams(
								 LinearLayout.LayoutParams.MATCH_PARENT,
								 LinearLayout.LayoutParams.WRAP_CONTENT));
        tvDroppedVal    = buildStatBlock(row2, "PERDIDOS", "—", C_DROP);
        row2.addView(vDiv());
        tvEfficiencyVal = buildStatBlock(row2, "EFICIENCIA", "—", C_EFF);
        fpsCounter   = tvFpsVal;
        tvFramesVal  = tvSessionVal;   // alias de backcompat
        statsCol.addView(row2);

        catRow.addView(statsCol);
        card.addView(catRow);

        // ── Separador + línea de info de generación ──────────────────────────
        card.addView(hDiv());
        generationInfoText = new TextView(this);
        generationInfoText.setTextSize(9.5f);
        generationInfoText.setTextColor(C_TXT_SEC);
        generationInfoText.setTypeface(Typeface.MONOSPACE);
        generationInfoText.setLetterSpacing(0.04f);
        LinearLayout.LayoutParams glp = new LinearLayout.LayoutParams(
			LinearLayout.LayoutParams.MATCH_PARENT,
			LinearLayout.LayoutParams.WRAP_CONTENT);
        glp.setMargins(dp(14), dp(8), dp(14), dp(4));
        generationInfoText.setLayoutParams(glp);
        card.addView(generationInfoText);

        // ── Histórico de sesiones ─────────────────────────────────────────────
        statsText = new TextView(this);
        statsText.setTextSize(8.5f);
        statsText.setTextColor(C_TXT_MUT);
        statsText.setTypeface(Typeface.MONOSPACE);
        LinearLayout.LayoutParams slp = new LinearLayout.LayoutParams(
			LinearLayout.LayoutParams.MATCH_PARENT,
			LinearLayout.LayoutParams.WRAP_CONTENT);
        slp.setMargins(dp(14), dp(2), dp(14), dp(6));
        statsText.setLayoutParams(slp);
        card.addView(statsText);

        controlPanel.addView(card);
    }

    /** Bloque de stat con color de acento personalizado. */
    private TextView buildStatBlock(LinearLayout parent, String label, String init, int accentColor) {
        LinearLayout block = new LinearLayout(this);
        block.setOrientation(LinearLayout.VERTICAL);
        block.setLayoutParams(new LinearLayout.LayoutParams(
								  0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f));
        block.setGravity(android.view.Gravity.CENTER);
        block.setPadding(dp(6), dp(12), dp(6), dp(10));

        TextView tvNum = new TextView(this);
        tvNum.setText(init);
        tvNum.setTextSize(24);
        tvNum.setTextColor(accentColor);
        tvNum.setTypeface(Typeface.MONOSPACE);
        tvNum.setGravity(android.view.Gravity.CENTER);
        block.addView(tvNum);

        TextView tvLbl = new TextView(this);
        tvLbl.setText(label);
        tvLbl.setTextSize(7.5f);
        tvLbl.setTextColor(C_TXT_SEC);
        tvLbl.setTypeface(Typeface.MONOSPACE);
        tvLbl.setLetterSpacing(0.14f);
        tvLbl.setGravity(android.view.Gravity.CENTER);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
			LinearLayout.LayoutParams.MATCH_PARENT,
			LinearLayout.LayoutParams.WRAP_CONTENT);
        lp.setMargins(0, dp(3), 0, 0);
        tvLbl.setLayoutParams(lp);
        block.addView(tvLbl);

        parent.addView(block);
        return tvNum;
    }

    /** Sobrecarga sin color para backcompat. */
    private TextView buildStatBlock(LinearLayout parent, String label, String init) {
        return buildStatBlock(parent, label, init, C_TXT_PRI);
    }

    // ── Start / Stop ──────────────────────────────────────────────────────────

    private void buildStartStop() {
        btnStartStop = new Button(this);
        btnStartStop.setText("▶  INICIAR CAPTURA");
        btnStartStop.setTextSize(15);
        btnStartStop.setTextColor(Color.BLACK);
        btnStartStop.setTypeface(Typeface.create("sans-serif-medium", Typeface.NORMAL));
        btnStartStop.setLetterSpacing(0.06f);
        btnStartStop.setAllCaps(false);
        btnStartStop.setBackground(gd(C_SIFG, 16, 0, 0));

        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
			LinearLayout.LayoutParams.MATCH_PARENT, dp(58));
        lp.setMargins(0, dp(24), 0, 0);
        btnStartStop.setLayoutParams(lp);

        btnStartStop.setOnClickListener(new View.OnClickListener() {
				@Override public void onClick(View v) {
					if (!isCapturing) startCapture();
					else              stopCapture();
				}
			});
        controlPanel.addView(btnStartStop);
    }

    // ── Alias helpers (backcompat con diálogos) ───────────────────────────────

    /** @deprecated Backcompat — la nueva UI no usa buttons para labels. */
    private TextView makeTextView(int sp, int color) {
        TextView tv = new TextView(this);
        tv.setTextSize(sp);
        tv.setTextColor(color);
        tv.setLayoutParams(new LinearLayout.LayoutParams(
							   LinearLayout.LayoutParams.MATCH_PARENT,
							   LinearLayout.LayoutParams.WRAP_CONTENT));
        return tv;
    }
    // ════════════════════════════════════════════════════════════════════════
    //  Diálogos de configuración
    // ════════════════════════════════════════════════════════════════════════

    private void showSIFgVersionDialog() {
        new AlertDialog.Builder(this)
			.setTitle("Selecciona versión SIFg")
			.setItems(new String[]{"v1.0 (Directo)", "v1.1 (Interpolado rápido)"},
			new DialogInterface.OnClickListener() {
				@Override public void onClick(DialogInterface d, int which) {
					sifgVersion = which;
					prefs.edit().putInt(PREF_SIFG_VERSION, sifgVersion).apply();
					setMode(MODE_SIFG1);
				}
			})
			.show();
    }

    private void showFisheyeDialog() {
        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);
        layout.setPadding(32, 16, 32, 16);

        final SeekBar   seekBar    = new SeekBar(this);
        final TextView  valueLabel = new TextView(this);
        seekBar.setMax(200);
        seekBar.setProgress(fisheyeCorrection + 100);
        valueLabel.setText(formatFisheyeLabel(fisheyeCorrection));
        valueLabel.setGravity(Gravity.CENTER);
        valueLabel.setPadding(0, 16, 0, 0);

        seekBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
				@Override public void onProgressChanged(SeekBar sb, int progress, boolean fromUser) {
					valueLabel.setText(formatFisheyeLabel(progress - 100));
				}
				@Override public void onStartTrackingTouch(SeekBar sb) {}
				@Override public void onStopTrackingTouch(SeekBar sb)  {}
			});

        layout.addView(seekBar);
        layout.addView(valueLabel);

        new AlertDialog.Builder(this)
			.setTitle("Corrección Efecto Ojo de Pez")
			.setView(layout)
			.setPositiveButton("Aplicar", new DialogInterface.OnClickListener() {
				@Override public void onClick(DialogInterface d, int which) {
					fisheyeCorrection = seekBar.getProgress() - 100;
					prefs.edit().putInt(PREF_FISHEYE_CORRECTION, fisheyeCorrection).apply();
					if (tvFishVal != null) tvFishVal.setText(fisheyeCorrection == 0 ? "OFF" : (fisheyeCorrection > 0 ? "+" : "") + fisheyeCorrection);
					if (captureService != null && isCapturing) {
						captureService.setFisheyeCorrection(fisheyeCorrection);
					}
				}
			})
			.setNegativeButton("Cancelar", null)
			.show();
    }

    private void showResolutionDialog() {
        new AlertDialog.Builder(this)
			.setTitle("Selecciona resolución de captura")
			.setItems(
			new String[]{"25% (Máx velocidad)", "50% (Balance)", "75% (Más calidad)"},
			new DialogInterface.OnClickListener() {
				@Override public void onClick(DialogInterface d, int which) {
					float[] scales = {0.25f, 0.5f, 0.75f};
					resolutionScale = scales[which];
					prefs.edit().putFloat(PREF_RESOLUTION_SCALE, resolutionScale).apply();
					if (tvResVal != null) tvResVal.setText((int)(resolutionScale * 100) + "%");
					// El cache ya existe para esta escala — solo leerlo
					DisplayMetrics metrics = getDisplayMetrics();
					adjustResolutions(metrics);
					updateResolutionText();
					if (captureService != null && isCapturing) {
						captureService.updateResolution(
							sourceWidth, sourceHeight, targetWidth, targetHeight);
						captureService.setResolutionScale(resolutionScale);
					}
				}
			})
			.show();
    }

    private void showFrameGenerationDialog() {
        new AlertDialog.Builder(this)
			.setTitle("Frames a generar entre frames reales")
			.setItems(
			new String[]{"1 (2x FPS)", "2 (3x FPS)", "3 (4x FPS)", "4 (5x FPS)"},
			new DialogInterface.OnClickListener() {
				@Override public void onClick(DialogInterface d, int which) {
					int[] values = {1, 2, 3, 4};
					framesToGenerate = values[which];
					prefs.edit().putInt(PREF_FRAMES_TO_GENERATE, framesToGenerate).apply();
					if (tvGenVal != null) tvGenVal.setText(framesToGenerate + "\u00d7 (\u00d7" + (framesToGenerate+1) + " FPS)");
					updateGenerationInfoText();
					if (captureService != null && isCapturing) {
						captureService.setFramesToGenerate(framesToGenerate);
					}
				}
			})
			.show();
    }

    private void showColorQualityDialog() {
        new AlertDialog.Builder(this)
			.setTitle("Calidad de color")
			.setItems(
			new String[]{"Completa (24-bit)", "8-bit (Retro)", "256 colores (Paletizado)"},
			new DialogInterface.OnClickListener() {
				@Override public void onClick(DialogInterface d, int which) {
					colorQuality = which;
					prefs.edit().putInt(PREF_COLOR_QUALITY, colorQuality).apply();
					if (tvColorVal != null) tvColorVal.setText(getColorQualityLabel());
					updateGenerationInfoText();
					if (captureService != null && isCapturing) {
						captureService.setColorQuality(colorQuality);
					}
				}
			})
			.show();
    }

    // ════════════════════════════════════════════════════════════════════════
    //  Helpers de texto y modo
    // ════════════════════════════════════════════════════════════════════════

    private String getColorQualityLabel() {
        switch (colorQuality) {
            case 1:  return "8-bit";
            case 2:  return "256c";
            default: return "Full";
        }
    }

    private static String formatFisheyeLabel(int value) {
        return "Factor: " + (value > 0 ? "+" : "") + value;
    }

    private void updateGenerationInfoText() {
        if (generationInfoText != null) {
            generationInfoText.setText("Gen: " + framesToGenerate
                                       + "  ·  Color: " + getColorQualityLabel());
        }
    }


    /** Devuelve el color de acento del modo activo (para el botón INICIAR). */
    private int getModeColor() {
        switch (currentMode.get()) {
            case MODE_SIFG1:     return C_SIFG;
            case MODE_ASIFG:     return C_ASIFG;
            case MODE_GPU:       return C_GPU;
            case MODE_ASIFG_GPU: return C_GPU;
            default:             return C_PERF;
        }
    }


    /**
     * Muestra u oculta la fila de toggle CPU/GPU según si el modo activo
     * tiene variante GPU. Actualiza también el estilo de los pills CPU/GPU.
     */
    private void updateGpuToggleVisibility() {
        if (gpuToggleRow == null) return;
        int mode = currentMode.get();
        boolean supportGpu = AppConstants.modeSupportsGpuToggle(mode);
        gpuToggleRow.setVisibility(supportGpu ? View.VISIBLE : View.GONE);

        if (!supportGpu) return;

        boolean isGpu = AppConstants.isGpuMode(mode);
        if (pillCpu != null) {
            pillCpu.setBackground(isGpu
								  ? gd(0x00000000, 10, C_BORDER, 1)
								  : gd(C_PERF_DIM, 10, C_PERF, 1));
            pillCpu.setTextColor(isGpu ? C_TXT_SEC : C_TXT_PRI);
        }
        if (pillGpu != null) {
            pillGpu.setBackground(isGpu
								  ? gd(C_GPU_DIM, 10, C_GPU, 1)
								  : gd(0x00000000, 10, C_BORDER, 1));
            pillGpu.setTextColor(isGpu ? C_GPU : C_TXT_SEC);
        }
    }

    private void setMode(int mode) {
        currentMode.set(mode);

        // ── Reset pills al estado inactivo ───────────────────────────────────
        if (pillPerf  != null) { pillPerf.setBackground(gd(0x00000000, 12, C_BORDER, 1));  pillPerf.setTextColor(C_TXT_SEC);  }
        if (pillSifg  != null) { pillSifg.setBackground(gd(0x00000000, 12, C_BORDER, 1));  pillSifg.setTextColor(C_TXT_SEC);  }
        if (pillAsifg != null) { pillAsifg.setBackground(gd(0x00000000, 12, C_BORDER, 1)); pillAsifg.setTextColor(C_TXT_SEC); }
        if (pillGpu   != null) { pillGpu.setBackground(gd(0x00000000, 12, C_BORDER, 1));   pillGpu.setTextColor(C_TXT_SEC);   }

        String modeText;
        String sifgInfo;
        int    modeColor;

        switch (mode) {
            case MODE_SIFG1:
                if (sifgVersion == 0) {
                    modeText = "SIFg v1.0  \u2014  Predicci\u00f3n";
                    sifgInfo = "Predicci\u00f3n de movimiento ultr\u00e1rpida \u00b7 un frame adelante";
                } else {
                    modeText = "SIFg v1.1  \u2014  Interpolaci\u00f3n";
                    sifgInfo = "Interpolaci\u00f3n pura A\u2192B \u00b7 sin descarte de frames";
                }
                modeColor = C_SIFG;
                if (pillSifg  != null) { pillSifg.setBackground(gd(C_SIFG_DIM, 12, C_SIFG, 1));   pillSifg.setTextColor(C_SIFG); }
                if (tileGen   != null) { tileGen.setEnabled(true);  tileGen.setAlpha(1f); }
                if (framesToGenerate <= 0) {
                    framesToGenerate = prefs.getInt(PREF_FRAMES_TO_GENERATE, DEFAULT_FRAMES_TO_GENERATE);
                    if (framesToGenerate <= 0) framesToGenerate = 1;
                }
                if (tvGenVal  != null) tvGenVal.setText(framesToGenerate + "\u00d7 (\u00d7" + (framesToGenerate + 1) + " FPS)");
                break;

            case MODE_ASIFG:
                modeText  = "ASIFg  \u2014  Red Neuronal";
                sifgInfo  = "IA liviana \u00b7 estimaci\u00f3n de movimiento + generaci\u00f3n 1:2";
                modeColor = C_ASIFG;
                if (pillAsifg != null) { pillAsifg.setBackground(gd(C_ASIFG_DIM, 12, C_ASIFG, 1)); pillAsifg.setTextColor(C_ASIFG); }
                if (tileGen   != null) { tileGen.setEnabled(true);  tileGen.setAlpha(1f); }
                if (framesToGenerate <= 0) {
                    framesToGenerate = prefs.getInt(PREF_FRAMES_TO_GENERATE, DEFAULT_FRAMES_TO_GENERATE);
                    if (framesToGenerate <= 0) framesToGenerate = 1;
                }
                if (tvGenVal  != null) tvGenVal.setText(framesToGenerate + "\u00d7 (\u00d7" + (framesToGenerate + 1) + " FPS)");
                break;

            case MODE_GPU:
                modeText  = "GPU  —  RenderScript";
                sifgInfo  = "Resize + blend vía GPU · sin bucles CPU por píxel";
                modeColor = C_GPU;
                if (pillGpu   != null) { pillGpu.setBackground(gd(C_GPU_DIM, 12, C_GPU, 1));   pillGpu.setTextColor(C_GPU); }
                if (tileGen   != null) { tileGen.setEnabled(true);  tileGen.setAlpha(1f); }
                if (framesToGenerate <= 0) {
                    framesToGenerate = prefs.getInt(PREF_FRAMES_TO_GENERATE, DEFAULT_FRAMES_TO_GENERATE);
                    if (framesToGenerate <= 0) framesToGenerate = 1;
                }
                if (tvGenVal  != null) tvGenVal.setText(framesToGenerate + "\u00d7 (\u00d7" + (framesToGenerate + 1) + " FPS)");
                break;

            case MODE_ASIFG_GPU:
                modeText  = "ASIFg GPU  —  Red Neuronal + RS";
                sifgInfo  = "IA liviana + blend GPU · síntesis acelerada por RenderScript";
                modeColor = C_GPU;
                if (pillAsifg != null) { pillAsifg.setBackground(gd(C_ASIFG_DIM, 12, C_ASIFG, 1)); pillAsifg.setTextColor(C_ASIFG); }
                if (tileGen   != null) { tileGen.setEnabled(true);  tileGen.setAlpha(1f); }
                if (framesToGenerate <= 0) {
                    framesToGenerate = prefs.getInt(PREF_FRAMES_TO_GENERATE, DEFAULT_FRAMES_TO_GENERATE);
                    if (framesToGenerate <= 0) framesToGenerate = 1;
                }
                if (tvGenVal  != null) tvGenVal.setText(framesToGenerate + "× (×" + (framesToGenerate + 1) + " FPS)");
                break;

            default: // MODE_PERFORMANCE
                modeText  = "Rendimiento directo";
                sifgInfo  = "Rescalado puro sin generaci\u00f3n de frames";
                modeColor = C_PERF;
                if (pillPerf  != null) { pillPerf.setBackground(gd(C_PERF_DIM, 12, C_PERF, 1));    pillPerf.setTextColor(C_PERF); }
                framesToGenerate = 0;
                prefs.edit().putInt(PREF_FRAMES_TO_GENERATE, 0).apply();
                if (tileGen   != null) { tileGen.setEnabled(false); tileGen.setAlpha(0.30f); }
                if (tvGenVal  != null) tvGenVal.setText("\u2014");
                break;
        }

        if (statusText   != null) statusText.setText(modeText);
        if (sifgInfoText != null) sifgInfoText.setText(sifgInfo);
        if (statusCardBg != null) statusCardBg.setStroke(dp(1), modeColor);
        if (btnStartStop != null && !isCapturing) {
            btnStartStop.setBackground(gd(modeColor, 16, 0, 0));
            btnStartStop.setTextColor(modeColor == C_ASIFG ? Color.WHITE : Color.BLACK);
        }

        updateGenerationInfoText();
        updateGpuToggleVisibility();

        if (captureService != null) {
            captureService.setMode(mode);
            captureService.setSifgVersion(sifgVersion);
        }
    }

    // ════════════════════════════════════════════════════════════════════════
    //  Captura
    // ════════════════════════════════════════════════════════════════════════

    private void startCapture() {
        if (Build.VERSION.SDK_INT >= 23 && !Settings.canDrawOverlays(this)) {
            Toast.makeText(this,
						   "Habilitando permisos de superposición...", Toast.LENGTH_LONG).show();
            startActivityForResult(
				new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION),
				REQUEST_CODE_OVERLAY);
            return;
        }
        if (mpManager == null) {
            Toast.makeText(this,
						   "Error: MediaProjectionManager no disponible", Toast.LENGTH_SHORT).show();
            return;
        }
        // Android 14+ (API 34): captura de app específica — evita bucle de auto-captura
        // y no incluye las barras del sistema en la imagen capturada
        if (captureMode == CAPTURE_MODE_SINGLE_APP) {

			startActivityForResult(
				mpManager.createScreenCaptureIntent(),
				REQUEST_CODE_CAPTURE
			);

		} else {

			startActivityForResult(
				mpManager.createScreenCaptureIntent(),
				REQUEST_CODE_CAPTURE
			);

		}
    }

    private void stopCapture() {
        if (captureService != null) captureService.stopCapture();
        isCapturing = false;
        fpsHandler.removeCallbacks(fpsRunnable);
        runOnUiThread(new Runnable() {
				@Override public void run() {
					controlPanel.setVisibility(View.VISIBLE);
					if (tvFpsVal != null) tvFpsVal.setText("\u2014");
					if (tvFramesVal != null) tvFramesVal.setText("\u2014");
					if (tvDroppedVal != null) tvDroppedVal.setText("\u2014");
				}
			});
    }

    private void startCaptureInternal() {
        if (!serviceBound || captureService == null || resultData == null
			|| isFinishing() || isDestroyed()) {
            Toast.makeText(this, "Servicio no disponible", Toast.LENGTH_SHORT).show();
            return;
        }
        // En modo SINGLE_APP la captura ya excluye las barras del sistema
        int top    = (captureMode == CAPTURE_MODE_SINGLE_APP) ? 0 : topInset;
        int bottom = (captureMode == CAPTURE_MODE_SINGLE_APP) ? 0 : bottomInset;

        captureService.startCapture(resultCode, resultData,
									sourceWidth, sourceHeight, targetWidth, targetHeight,
									screenDensityDpi, top, bottom, captureMode);
        isCapturing = true;
        hideControlsAndStartOverlay();
        startFpsMonitor();
    }

    private void hideControlsAndStartOverlay() {
        runOnUiThread(new Runnable() {
				@Override public void run() {
					if (!isFinishing() && !isDestroyed()) {
						controlPanel.setVisibility(View.GONE);
						moveTaskToBack(true);
						Toast.makeText(ScreenScaler.this,
									   "Captura iniciada - Overlay activo", Toast.LENGTH_SHORT).show();
					}
				}
			});
    }

    private void startFpsMonitor() {
        fpsHandler.removeCallbacks(fpsRunnable);
        fpsHandler.post(fpsRunnable);
    }

    private boolean isAccessibilityServiceEnabled() {
        try {
            int enabled = Settings.Secure.getInt(
				getContentResolver(), Settings.Secure.ACCESSIBILITY_ENABLED);
            if (enabled == 1) {
                String services = Settings.Secure.getString(
					getContentResolver(), Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES);
                if (services != null) {
                    String ourService = getPackageName() + "/"
						+ TouchForwardService.class.getName();
                    return services.contains(ourService);
                }
            }
        } catch (Settings.SettingNotFoundException e) {
            Log.e(TAG, "Error verificando servicio de accesibilidad", e);
        }
        return false;
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (requestCode == REQUEST_CODE_ACCESSIBILITY) {
            // Resultado informativo: el usuario volvió desde Ajustes de Accesibilidad.
            // Actualizamos el botón para reflejar el estado real del servicio.
            updateTouchForwardButton();

        } else if (requestCode == REQUEST_CODE_OVERLAY) {
            if (Build.VERSION.SDK_INT >= 23 && Settings.canDrawOverlays(this)) {
                Toast.makeText(this,
							   "Permisos de superposición concedidos. Ahora inicia la captura.",
							   Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(this,
							   "Debes habilitar los permisos de superposición para continuar.",
							   Toast.LENGTH_LONG).show();
            }

        } else if (requestCode == REQUEST_CODE_CAPTURE) {
            if (resultCode == RESULT_OK && data != null) {
                this.resultCode = resultCode;
                this.resultData = data;
                startCaptureInternal();
            } else {
                Toast.makeText(this, "Permiso de captura denegado", Toast.LENGTH_SHORT).show();
            }
        }
    }

    // ════════════════════════════════════════════════════════════════════════
    //  Estadísticas persistidas
    // ════════════════════════════════════════════════════════════════════════

    private void loadStats() {
        int avgPerf  = prefs.getInt(PREF_AVG_FPS_PERFORMANCE, 0);
        int avgSifg1 = prefs.getInt(PREF_AVG_FPS_SIFG1,       0);
        int avgAsifg = prefs.getInt(PREF_AVG_FPS_ASIFG,        0);

        if (avgPerf > 0 || avgSifg1 > 0 || avgAsifg > 0) {
            StringBuilder sb = new StringBuilder("Estadísticas del dispositivo:\n");
            if (avgPerf  > 0) sb.append("Rendimiento: ").append(avgPerf).append(" FPS | ");
            if (avgSifg1 > 0) sb.append("SIFg1: ").append(avgSifg1).append(" FPS | ");
            if (avgAsifg > 0) sb.append("ASIFg: ").append(avgAsifg).append(" FPS");
            statsText.setText(sb.toString());
        }
    }

    // ════════════════════════════════════════════════════════════════════════
    //  Sincronización con el servicio
    // ════════════════════════════════════════════════════════════════════════

    private void syncServiceSettings() {
        if (captureService == null) return;
        captureService.setMode(currentMode.get());
        captureService.setSifgVersion(sifgVersion);
        captureService.setResolutionScale(resolutionScale);
        captureService.setFramesToGenerate(framesToGenerate);
        captureService.setColorQuality(colorQuality);
        captureService.setFisheyeCorrection(fisheyeCorrection);
        captureService.setTouchForwardEnabled(touchForwardEnabled);
        captureService.setTargetFps(targetFps);
    }

    // ════════════════════════════════════════════════════════════════════════
    //  Modo de captura y configuración de insets
    // ════════════════════════════════════════════════════════════════════════

    private String getCaptureModeLabel() {
        if (Build.VERSION.SDK_INT < 34) return "Modo: Pantalla";
        return captureMode == CAPTURE_MODE_SINGLE_APP ? "Modo: App \u2713" : "Modo: Pantalla";
    }

    /**
     * Diálogo de modo de captura.
     *
     * <p><b>Pantalla completa:</b> captura todo — incluye las barras del sistema.
     * El Service recorta automáticamente los insets detectados para evitar el
     * bucle de auto-captura y el overlay cortado.
     *
     * <p><b>App específica (API 34+):</b> el sistema muestra un selector de app
     * antes de empezar. La captura es de esa app únicamente — sin barras, sin bucle.
     * Ideal para usar con YouTube, juegos, etc.
     */
    // ── Frases del gato ───────────────────────────────────────────────────────

    private static final String[] CAT_PHRASES = {
        // SIFg
        "SIFg v1.0 extrapola el siguiente frame\na partir del flujo entre los dos anteriores.\n¡Como adivinar el futuro con física!",
        "SIFg v1.1 usa interpolación pura (A+B)/2.\nMás suave que v1.0, menos artefactos\nen escenas con mucho movimiento.",
        "SIFg significa Simple Interpolated\nFrame Generator. Simple por nombre,\nnada simple por dentro ( •ᴗ• )\n\n...y esto se llama KITIKAT Scaler\nporque ^π^ ( ●ω● )",
        "En SIFg, si los dos frames reales llegan\ncon más de 50ms de diferencia,\nel generado se descarta. ¡Calidad ante todo!",

        // ASIFg
        "ASIFg usa una red neuronal MLP de\n3 capas para predecir el flujo óptico\nde cada bloque. ¡Aprende mientras captura!",
        "El grid ASIFg es de 4×4 bloques.\nMenos bloques = más velocidad,\nmás bloques = más precisión. ¡Tú eliges!",
        "ASIFg tiene memoria: el campo de\nflujo se suaviza con EMA (α=0.20).\nUn frame ruidoso no arruina todo.",
        "La red ASIFg entrena en cada frame:\n128 neuronas entrada → 16 → 8 → 2.\n¡Pesos actualizados en tiempo real!",
        "ASIFg en GPU combina RenderScript\npara el upscale con la red neuronal\nen CPU. Lo mejor de ambos mundos.",

        // Consejos técnicos
        "¿Muchos frames perdidos? Baja la\nresolución de captura o el multiplicador.\nMenos resolución = menos GC pressure.",
        "Modo GPU usa RenderScript para\nel upscale. Más rápido en dispositivos\ncon GPU potente. Pruébalo!",
        "Si ves artefactos en bordes,\nactiva la corrección fisheye.\nCompensa la distorsión del overlay.",
        "El FPS objetivo controla cada cuánto\nel ImageReader acepta un frame real.\nSúbelo si el juego va muy rápido.",
        "¿Ves lag entre el juego y el overlay?\nComprueba que 'EFICIENCIA' esté\npor encima del 80%. Si no, baja la res.",

        // Mensajes de apoyo
        "¡Oye, que esto es tecnología\nde verdad corriendo en tu móvil!\nNo todo el mundo puede decir eso ( ●ω● )",
        "Cada frame generado es matemáticas\naplicadas en tiempo real. Tú corres\ncomputación gráfica avanzada. Top.",
        "Si algo falla, respira.\nTodos los bugs tienen solución.\nIncluso ese que llevas 3 horas mirando.",
        "¿Cansado? Yo también proceso\nmillones de píxeles por segundo\ny no me quejo... mucho ( ≥ω≤ )",
        "El mejor ajuste es el que funciona\npara TU dispositivo. Experimenta.\nNo existe configuración universal.",
        "¡Recuerda que estás generando frames\nque el hardware no puede generar!\nEso mola bastante, ¿no? ( ´ω` )"
    };

    private void showCatPhrase() {
        String phrase = CAT_PHRASES[catPhraseIndex % CAT_PHRASES.length];
        catPhraseIndex++;

        android.app.AlertDialog.Builder builder = new android.app.AlertDialog.Builder(this);

        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);
        layout.setPadding(dp(20), dp(16), dp(20), dp(8));
        layout.setBackgroundColor(C_SURF);

        // Gato ASCII en el diálogo
        TextView tvCat = new TextView(this);
        tvCat.setTypeface(Typeface.MONOSPACE);
        tvCat.setTextSize(10f);
        tvCat.setTextColor(C_TXT_SEC);
        tvCat.setGravity(android.view.Gravity.CENTER);
        tvCat.setText("  /\\_____/\\\n" + "( ●ω● )\n" + "  )   (  \n" + " (_)━━(►)");
        layout.addView(tvCat);

        // Separador
        View sep = new View(this);
        LinearLayout.LayoutParams sepLp = new LinearLayout.LayoutParams(
			LinearLayout.LayoutParams.MATCH_PARENT, dp(1));
        sepLp.setMargins(0, dp(10), 0, dp(10));
        sep.setLayoutParams(sepLp);
        sep.setBackgroundColor(C_BORDER);
        layout.addView(sep);

        // Frase
        TextView tvMsg = new TextView(this);
        tvMsg.setTypeface(Typeface.MONOSPACE);
        tvMsg.setTextSize(12f);
        tvMsg.setTextColor(C_TXT_PRI);
        tvMsg.setGravity(android.view.Gravity.CENTER);
        tvMsg.setText(phrase);
        layout.addView(tvMsg);

        // Contador discreto
        TextView tvHint = new TextView(this);
        tvHint.setTypeface(Typeface.MONOSPACE);
        tvHint.setTextSize(7.5f);
        tvHint.setTextColor(C_TXT_MUT);
        tvHint.setGravity(android.view.Gravity.CENTER);
        tvHint.setText("( " + catPhraseIndex + "/" + CAT_PHRASES.length + " )");
        LinearLayout.LayoutParams hintLp = new LinearLayout.LayoutParams(
			LinearLayout.LayoutParams.MATCH_PARENT,
			LinearLayout.LayoutParams.WRAP_CONTENT);
        hintLp.setMargins(0, dp(10), 0, 0);
        tvHint.setLayoutParams(hintLp);
        layout.addView(tvHint);

        builder.setView(layout);
        builder.setPositiveButton("( •ω• ) OK", null);
        android.app.AlertDialog dlg = builder.create();
        if (dlg.getWindow() != null) {
            dlg.getWindow().setBackgroundDrawable(
				new android.graphics.drawable.ColorDrawable(C_SURF));
        }
        dlg.show();
    }

    // ── About / Easter egg ────────────────────────────────────────────────────

    private void showAboutDialog() {
        android.app.AlertDialog.Builder builder = new android.app.AlertDialog.Builder(this);

        android.widget.ScrollView scroll = new android.widget.ScrollView(this);
        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);
        layout.setPadding(dp(20), dp(20), dp(20), dp(16));
        layout.setBackgroundColor(C_SURF);

        // Logo ASCII grande
        TextView tvLogo = new TextView(this);
        tvLogo.setTypeface(Typeface.MONOSPACE);
        tvLogo.setTextSize(8.5f);
        tvLogo.setTextColor(C_PERF);
        tvLogo.setGravity(android.view.Gravity.CENTER);
        tvLogo.setText(
            " _____ _____ ____  ___ _____ \n" +
            "| ____|  ___|  _ \\|_ _|_   _|\n" +
            "| _|  | |   | | | || |  | |  \n" +
            "| |___|  |_  | |_/ || |  | |  \n" +
            "|_____|____|____/|___| |_|  \n" +
            "  KITIKAT Scaler  v1.0"
        );
        layout.addView(tvLogo);

        addAboutDivider(layout);

        // Gato sensei
        TextView tvCat = new TextView(this);
        tvCat.setTypeface(Typeface.MONOSPACE);
        tvCat.setTextSize(10f);
        tvCat.setTextColor(C_TXT_SEC);
        tvCat.setGravity(android.view.Gravity.CENTER);
        tvCat.setText("  /\\_____/\\\n( ×ω× )  ← 7 clics después...\n  )   (  \n (_)━━(►) sigue explorando");
        layout.addView(tvCat);

        addAboutDivider(layout);

        // Sección: Sobre la app
        addAboutHeader(layout, "◈  SOBRE LA APP");
        addAboutText(layout,
					 "KITIKAT Scaler es un overlay de generación\n" +
					 "de frames intermedios en tiempo real para\n" +
					 "Android. Captura la pantalla del sistema,\n" +
					 "genera frames sintéticos con interpolación\n" +
					 "o redes neuronales (ASIFg), y los muestra\n" +
					 "como overlay sobre cualquier app o juego.\n\n" +
					 "Modos disponibles:\n" +
					 "  · PERFORMANCE  — sin generación, solo overlay\n" +
					 "  · SIFg v1.0    — extrapolación simple\n" +
					 "  · SIFg v1.1    — interpolación (A+B)/2\n" +
					 "  · GPU          — upscale por RenderScript\n" +
					 "  · ASIFg        — red neuronal MLP + block-matching"
					 );

        addAboutDivider(layout);

        // Sección: TuringSoftware
        addAboutHeader(layout, "◈  TURING SOFTWARE");
        addAboutText(layout,
					 "Proyecto independiente de desarrollo Android.\n" +
					 "Especializado en procesamiento de imagen\n" +
					 "en tiempo real, overlays de sistema y\n" +
					 "aceleración por hardware en dispositivos\n" +
					 "móviles.\n\n" +
					 "Nombre inspirado en Alan Turing (1912-1954),\n" +
					 "padre de la computación teórica y pionero\n" +
					 "en inteligencia artificial."
					 );

        addAboutDivider(layout);

        // Sección: Licencia GPL v3
        addAboutHeader(layout, "◈  LICENCIA  —  GNU GPL v3");
        addAboutText(layout,
					 "Copyright © Turing Software\n\n" +
					 "Este programa es software libre: puedes\n" +
					 "redistribuirlo y/o modificarlo bajo los\n" +
					 "términos de la Licencia Pública General\n" +
					 "GNU v3 publicada por la Free Software\n" +
					 "Foundation.\n\n" +
					 "Tienes derecho a:\n" +
					 "  · Usar el programa con cualquier fin\n" +
					 "  · Estudiar y modificar el código fuente\n" +
					 "  · Redistribuir copias\n" +
					 "  · Distribuir versiones modificadas\n\n" +
					 "Condición principal: cualquier versión\n" +
					 "derivada debe distribuirse también bajo\n" +
					 "GPL v3 con el código fuente disponible.\n\n" +
					 "Este programa se distribuye SIN GARANTÍA.\n" +
					 "Ver gnu.org/licenses/gpl-3.0 para el\n" +
					 "texto completo de la licencia."
					 );

        addAboutDivider(layout);

        // Footer
        TextView tvFoot = new TextView(this);
        tvFoot.setTypeface(Typeface.MONOSPACE);
        tvFoot.setTextSize(8f);
        tvFoot.setTextColor(C_TXT_MUT);
        tvFoot.setGravity(android.view.Gravity.CENTER);
        tvFoot.setText("Construido con pasión y demasiadas horas\nde depuración ( ●ω● )");
        LinearLayout.LayoutParams footLp = new LinearLayout.LayoutParams(
			LinearLayout.LayoutParams.MATCH_PARENT,
			LinearLayout.LayoutParams.WRAP_CONTENT);
        footLp.setMargins(0, dp(4), 0, dp(4));
        tvFoot.setLayoutParams(footLp);
        layout.addView(tvFoot);

        scroll.addView(layout);
        builder.setView(scroll);
        builder.setTitle("KITIKAT Scaler");
        builder.setPositiveButton("( ●ω● )  Cerrar", null);
        android.app.AlertDialog dlg = builder.create();
        if (dlg.getWindow() != null) {
            dlg.getWindow().setBackgroundDrawable(
				new android.graphics.drawable.ColorDrawable(C_SURF));
        }
        dlg.show();
    }

    private void addAboutHeader(LinearLayout parent, String text) {
        TextView tv = new TextView(this);
        tv.setTypeface(Typeface.MONOSPACE);
        tv.setTextSize(10.5f);
        tv.setTextColor(C_SIFG);
        tv.setLetterSpacing(0.08f);
        tv.setText(text);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
			LinearLayout.LayoutParams.MATCH_PARENT,
			LinearLayout.LayoutParams.WRAP_CONTENT);
        lp.setMargins(0, dp(4), 0, dp(6));
        tv.setLayoutParams(lp);
        parent.addView(tv);
    }

    private void addAboutText(LinearLayout parent, String text) {
        TextView tv = new TextView(this);
        tv.setTypeface(Typeface.MONOSPACE);
        tv.setTextSize(10f);
        tv.setTextColor(C_TXT_PRI);
        tv.setText(text);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
			LinearLayout.LayoutParams.MATCH_PARENT,
			LinearLayout.LayoutParams.WRAP_CONTENT);
        lp.setMargins(dp(4), 0, 0, 0);
        tv.setLayoutParams(lp);
        parent.addView(tv);
    }

    private void addAboutDivider(LinearLayout parent) {
        View v = new View(this);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
			LinearLayout.LayoutParams.MATCH_PARENT, dp(1));
        lp.setMargins(0, dp(12), 0, dp(12));
        v.setLayoutParams(lp);
        v.setBackgroundColor(C_BORDER);
        parent.addView(v);
    }

    private void showTargetFpsDialog() {
        // Construir etiquetas dinámicamente desde FPS_OPTIONS
        final int[] opts = AppConstants.FPS_OPTIONS;
        String[] labels = new String[opts.length];
        int checkedIdx = 0;
        for (int i = 0; i < opts.length; i++) {
            labels[i] = opts[i] + " fps";
            if (opts[i] == targetFps) checkedIdx = i;
        }
        final int[] selectedHolder = {checkedIdx};
        new AlertDialog.Builder(this)
			.setTitle("FPS de salida objetivo")
			.setSingleChoiceItems(labels, checkedIdx,
			new DialogInterface.OnClickListener() {
				@Override public void onClick(DialogInterface d, int which) {
					selectedHolder[0] = which;
				}
			})
			.setPositiveButton("Aplicar", new DialogInterface.OnClickListener() {
				@Override public void onClick(DialogInterface d, int which) {
					targetFps = opts[selectedHolder[0]];
					prefs.edit().putInt(PREF_TARGET_FPS, targetFps).apply();
					if (tvFpsTargetVal != null)
						tvFpsTargetVal.setText(targetFps + " fps");
					if (captureService != null)
						captureService.setTargetFps(targetFps);
				}
			})
			.setNegativeButton("Cancelar", null)
			.show();
    }

    private void showCaptureModeDialog() {
        if (Build.VERSION.SDK_INT < 34) {
            // En < API 34 solo hay pantalla completa; mostrar info de insets
            showInsetConfigDialog();
            return;
        }

        String[] opciones = {
            "Pantalla completa\n(recorta barras automáticamente)",
            "App específica ✓\n(seleccionas la app, sin bucle)"
        };

        new AlertDialog.Builder(this)
			.setTitle("Modo de captura")
			.setSingleChoiceItems(opciones, captureMode,
			new DialogInterface.OnClickListener() {
				@Override public void onClick(DialogInterface d, int which) {
					captureMode = which;
					prefs.edit().putInt(PREF_CAPTURE_MODE, captureMode).apply();
					if (btnCaptureMode != null) {
						if (tvCapModeVal != null) tvCapModeVal.setText(captureMode == CAPTURE_MODE_SINGLE_APP ? "APP" : "FULL");
					}
				}
			})
			.setPositiveButton("Aceptar", null)
			.setNeutralButton("Config. insets", new DialogInterface.OnClickListener() {
				@Override public void onClick(DialogInterface d, int which) {
					showInsetConfigDialog();
				}
			})
			.show();
    }

    /**
     * Permite al usuario ver y ajustar manualmente los insets de sistema
     * (barra de estado y barra de navegación) en píxeles.
     * Útil cuando la detección automática falla en ROMs personalizadas.
     */
    private void showInsetConfigDialog() {
        final android.widget.LinearLayout layout = new android.widget.LinearLayout(this);
        layout.setOrientation(android.widget.LinearLayout.VERTICAL);
        layout.setPadding(32, 16, 32, 8);

        final android.widget.EditText etStatus = new android.widget.EditText(this);
        etStatus.setInputType(android.text.InputType.TYPE_CLASS_NUMBER);
        etStatus.setText(String.valueOf(topInset));
        android.widget.TextView lblStatus = makeTextView(12, android.graphics.Color.LTGRAY);
        lblStatus.setText("Barra de estado (px) — valor detectado: " + topInset);

        final android.widget.EditText etNav = new android.widget.EditText(this);
        etNav.setInputType(android.text.InputType.TYPE_CLASS_NUMBER);
        etNav.setText(String.valueOf(bottomInset));
        android.widget.TextView lblNav = makeTextView(12, android.graphics.Color.LTGRAY);
        lblNav.setText("Barra de navegación (px) — valor detectado: " + bottomInset);

        layout.addView(lblStatus);
        layout.addView(etStatus);
        layout.addView(lblNav);
        layout.addView(etNav);

        new AlertDialog.Builder(this)
			.setTitle("Configurar insets del sistema")
			.setMessage("Ajusta si el overlay queda cortado o tiene borde negro en pantalla completa.")
			.setView(layout)
			.setPositiveButton("Aplicar", new DialogInterface.OnClickListener() {
				@Override public void onClick(DialogInterface d, int which) {
					try {
						topInset    = Integer.parseInt(etStatus.getText().toString());
						bottomInset = Integer.parseInt(etNav.getText().toString());
						prefs.edit()
							.putInt(PREF_INSET_STATUS_BAR, topInset)
							.putInt(PREF_INSET_NAV_BAR,    bottomInset)
							.apply();
						Toast.makeText(ScreenScaler.this,
									   "Insets guardados: top=" + topInset + " bottom=" + bottomInset,
									   Toast.LENGTH_SHORT).show();
					} catch (NumberFormatException e) {
						Toast.makeText(ScreenScaler.this,
									   "Valores inválidos", Toast.LENGTH_SHORT).show();
					}
				}
			})
			.setNeutralButton("Auto-detectar", new DialogInterface.OnClickListener() {
				@Override public void onClick(DialogInterface d, int which) {
					// Forzar re-detección borrando el cache
					prefs.edit()
						.remove(PREF_INSET_STATUS_BAR)
						.remove(PREF_INSET_NAV_BAR)
						.apply();
					detectNotchInsets();
					Toast.makeText(ScreenScaler.this,
								   "Re-detectando insets...", Toast.LENGTH_SHORT).show();
				}
			})
			.setNegativeButton("Cancelar", null)
			.show();
    }

    // ════════════════════════════════════════════════════════════════════════
    //  Reenvío de toques por accesibilidad (opcional)
    // ════════════════════════════════════════════════════════════════════════

    private String getTouchForwardLabel() {
        if (!touchForwardEnabled) return "Toque: OFF";
        return isAccessibilityServiceEnabled() ? "Toque: ON \u2713" : "Toque: ON (sin servicio)";
    }

    private void updateTouchForwardButton() {
        if (btnTouchForward != null) if (tvTouchVal != null) tvTouchVal.setText(touchForwardEnabled ? "ON" : "OFF");
    }

    /**
     * Muestra un diálogo explicativo y permite activar o desactivar el reenvío de toques.
     * Si el usuario activa la opción pero el servicio de accesibilidad no está habilitado,
     * se le ofrece ir a Ajustes para habilitarlo manualmente.
     */
    private void showTouchForwardDialog() {
        String estado  = touchForwardEnabled ? "ACTIVADO" : "DESACTIVADO";
        String accion  = touchForwardEnabled ? "Desactivar" : "Activar";
        boolean svcOk  = isAccessibilityServiceEnabled();

        StringBuilder msg = new StringBuilder();
        msg.append("El reenvío de toques permite que el overlay reciba y reenvíe gestos ");
        msg.append("al sistema usando el Servicio de Accesibilidad.\n\n");
        msg.append("Estado actual: ").append(estado).append("\n");
        if (touchForwardEnabled && !svcOk) {
            msg.append("\n\u26A0 El servicio de accesibilidad no está habilitado. ");
            msg.append("El reenvío no funcionará hasta que lo actives en Ajustes.");
        }

        AlertDialog.Builder builder = new AlertDialog.Builder(this)
			.setTitle("Reenvío de Toques (Opcional)")
			.setMessage(msg.toString())
			.setPositiveButton(accion, new DialogInterface.OnClickListener() {
				@Override public void onClick(DialogInterface d, int which) {
					setTouchForward(!touchForwardEnabled);
				}
			})
			.setNegativeButton("Cerrar", null);

        // Si está activado pero el servicio no corre, ofrecer ir a Ajustes
        if (touchForwardEnabled && !svcOk) {
            builder.setNeutralButton("Ir a Ajustes", new DialogInterface.OnClickListener() {
					@Override public void onClick(DialogInterface d, int which) {
						startActivityForResult(
                            new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS),
                            REQUEST_CODE_ACCESSIBILITY);
					}
				});
        }
        builder.show();
    }

    private void setTouchForward(boolean enabled) {
        touchForwardEnabled = enabled;
        prefs.edit().putBoolean(PREF_TOUCH_FORWARD, enabled).apply();
        updateTouchForwardButton();
        if (captureService != null) captureService.setTouchForwardEnabled(enabled);
        if (enabled && !isAccessibilityServiceEnabled()) {
            Toast.makeText(this,
						   "Activa el Servicio de Accesibilidad en Ajustes para que funcione.",
						   Toast.LENGTH_LONG).show();
        }
    }

    // ════════════════════════════════════════════════════════════════════════
    //  Receptor de batería (inner class)
    // ════════════════════════════════════════════════════════════════════════

    private class BatteryReceiver extends android.content.BroadcastReceiver {
        @Override
        public void onReceive(Context context, Intent intent) {
            int level = intent.getIntExtra(BatteryManager.EXTRA_LEVEL, -1);
            int scale = intent.getIntExtra(BatteryManager.EXTRA_SCALE, -1);
            if (scale <= 0) return;
            float pct = (level / (float) scale) * 100f;
            if (pct < 15f && currentMode.get() != MODE_PERFORMANCE && isCapturing) {
                setMode(MODE_PERFORMANCE);
                Toast.makeText(context,
							   "Batería baja: Modo Rendimiento activado", Toast.LENGTH_SHORT).show();
            }
        }
    }

    // ════════════════════════════════════════════════════════════════════════
    //  TouchForwardService (inner static)
    //  Reenvío de gestos desde el overlay al sistema de accesibilidad.
    // ════════════════════════════════════════════════════════════════════════

    public static class TouchForwardService extends AccessibilityService {

        private static volatile TouchForwardService instance;

        @Override public void onAccessibilityEvent(AccessibilityEvent event) {}
        @Override public void onInterrupt() {}

        @Override
        protected void onServiceConnected() {
            super.onServiceConnected();
            instance = this;
            android.os.Process.setThreadPriority(android.os.Process.THREAD_PRIORITY_URGENT_DISPLAY);
        }

        @Override
        public void onDestroy() {
            instance = null;
            super.onDestroy();
        }

        public static boolean isRunning() {
            return instance != null;
        }

        /** Solo disponible en API 24+. El guard se aplica en el caller. */
        public static void dispatchTouch(android.view.MotionEvent event) {
            TouchForwardService svc = instance;
            if (svc != null && Build.VERSION.SDK_INT >= 24) svc.performTouch(event);
        }

        private void performTouch(android.view.MotionEvent event) {
            try {
                android.accessibilityservice.GestureDescription.Builder builder =
					new android.accessibilityservice.GestureDescription.Builder();
                int pointerCount = event.getPointerCount();
                int action       = event.getActionMasked();

                for (int i = 0; i < pointerCount; i++) {
                    android.graphics.Path path = new android.graphics.Path();
                    path.moveTo(event.getX(i), event.getY(i));

                    android.accessibilityservice.GestureDescription.StrokeDescription stroke;
                    if (action == android.view.MotionEvent.ACTION_UP
						|| action == android.view.MotionEvent.ACTION_POINTER_UP) {
                        stroke = new android.accessibilityservice.GestureDescription
							.StrokeDescription(path, 0, 1);
                    } else {
                        // ACTION_DOWN, ACTION_POINTER_DOWN, ACTION_MOVE
                        stroke = new android.accessibilityservice.GestureDescription
							.StrokeDescription(path, 0, 100, true);
                    }
                    builder.addStroke(stroke);
                }
                dispatchGesture(builder.build(), null, null);
            } catch (Exception e) {
                Log.e(TAG, "Error dispatching touch", e);
            }
        }
    }
}





