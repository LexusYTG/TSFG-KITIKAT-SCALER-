package com.TuringSoftware.FrameGenerator;

import android.app.*;
import android.content.*;
import android.graphics.*;
import android.hardware.display.*;
import android.media.*;
import android.media.projection.*;
import android.os.*;
import android.provider.*;
import android.renderscript.*;
import android.util.*;
import android.view.*;
import android.widget.*;
import java.nio.*;
import java.util.*;
import java.util.concurrent.atomic.*;

import android.os.Process;

import static com.TuringSoftware.FrameGenerator.AppConstants.*;

/**
 * Servicio en primer plano que gestiona:
 * <ul>
 *   <li>Captura de pantalla vía {@link MediaProjection} + {@link ImageReader}.</li>
 *   <li>Upscaling nearest-neighbor.</li>
 *   <li>Generación de frames intermedios (SIFg v1.0, v1.1, ASIFg).</li>
 *   <li>Renderizado sobre un overlay {@link SurfaceView}.</li>
 * </ul>
 *
 * <p><b>Arquitectura de hilos:</b>
 * <pre>
 *   captureThread   → onImageAvailable  (adquisición a ~60 FPS)
 *   processingThread→ Generator/Processor (procesamiento pesado)
 *   renderThread    → lockCanvas/drawBitmap (render dedicado)
 *   mainHandler     → cambios de UI/overlay (Handler del main looper)
 * </pre>
 *
 * <p><b>Java 7</b>: sin lambdas. Todas las clases anónimas / internas son
 * explícitas.
 */
public class ScreenCaptureService extends Service {

    // ── Constantes ────────────────────────────────────────────────────────────
    private static final int    NOTIFICATION_ID  = 1001;
    private static final String CHANNEL_ID       = "ScreenCaptureChannel";
    private static final String ACTION_STOP      = "com.TuringSoftware.FrameGenerator.STOP";

    /**
     * Intervalo mínimo entre frames capturados (nanosegundos → 60 FPS).
     * Subir a 11_111_111 para 90 FPS en dispositivos que soporten VirtualDisplay
     * a 90 Hz.
     */
    /** Nanosegundos por frame según el FPS objetivo configurado por el usuario.
     *  Mutable: se actualiza vía setTargetFps() sin reiniciar la captura. */
    private volatile long targetFrameNanos = 16_666_667L;

    // ── Claves del caché de buffers ────────────────────────────────────────────
    private static final String KEY_SOURCE_BUFFER   = "src";
    private static final String KEY_UPSCALE_A       = "ua";
    private static final String KEY_UPSCALE_B       = "ub";
    /** Buffers upscale extra para modos ordenados (SIFg v1.1, ASIFg):
     *  necesitan 2 frames target-size listos simultáneamente en la cola. */
    private static final String KEY_UPSCALE_C       = "uc";
    private static final String KEY_UPSCALE_D       = "ud";
    private static final String KEY_UPSCALE_E       = "ue";
    private static final String KEY_UPSCALE_F       = "uf";
    private static final String KEY_UPSCALE_G       = "ug";
    private static final String KEY_UPSCALE_H       = "uh";
    /** Anillo de 6 slots para modos ordenados.
     *  6 slots = 3 ciclos completos (sintético+real) en vuelo simultáneamente,
     *  suficiente para desacoplar processingBusy del render. */
    private static final String[] UPSCALE_ORDERED_POOL =
            { KEY_UPSCALE_C, KEY_UPSCALE_D, KEY_UPSCALE_E,
              KEY_UPSCALE_F, KEY_UPSCALE_G, KEY_UPSCALE_H };
    private int upscaleOrderedHead = 0;

    /**
     * Upscalea {@code source} al siguiente slot libre del anillo de 6 y lo devuelve.
     * Con 6 slots hay margen para 3 ciclos en vuelo antes de reciclar — evita
     * sobreescribir un buffer que renderHandler todavía no ha consumido.
     */
    private byte[] upscaleForOrdered(byte[] source) {
        String key = UPSCALE_ORDERED_POOL[upscaleOrderedHead];
        upscaleOrderedHead = (upscaleOrderedHead + 1) % UPSCALE_ORDERED_POOL.length;

        int[] xMap = (int[]) resourceCache.get(KEY_XMAP);
        int[] yMap = (int[]) resourceCache.get(KEY_YMAP);
        if (xMap == null || yMap == null) return null;

        byte[] dest = (byte[]) resourceCache.get(key);
        if (dest == null) return null;

        final int srcStride = sourceWidth * 4;
        final int dstStride = targetWidth * 4;
        final int dstLen    = dest.length;
        int lastSrcRow  = -1;
        int lastDstBase = -1;

        for (int y = 0; y < targetHeight; y++) {
            int srcRow     = yMap[y];
            int dstRowBase = y * dstStride;
            if (srcRow == lastSrcRow && lastDstBase >= 0
                    && dstRowBase + dstStride <= dstLen
                    && lastDstBase + dstStride <= dstLen) {
                System.arraycopy(dest, lastDstBase, dest, dstRowBase, dstStride);
                continue;
            }
            int srcRowBase = srcRow * srcStride;  // hoist fuera del bucle X
            for (int x = 0; x < targetWidth; x++) {
                int srcIdx = srcRowBase + xMap[x] * 4;
                int dstIdx = dstRowBase + x * 4;
                dest[dstIdx]     = source[srcIdx];
                dest[dstIdx + 1] = source[srcIdx + 1];
                dest[dstIdx + 2] = source[srcIdx + 2];
                dest[dstIdx + 3] = (byte) 255;
            }
            lastSrcRow  = srcRow;
            lastDstBase = dstRowBase;
        }
        return dest;
    }
    private static final String KEY_EXTRAPOLATION    = "ex";
    private static final String KEY_EXTRAPOLATION_B  = "ex2";
    private static final String KEY_ASIFG_SYNTH      = "as";
    private static final String KEY_STATIC_FRAME     = "sf";
    private static final String KEY_LAST_REAL_FRAME  = "lr";
    private static final String KEY_PREV_FRAME       = "pf";
    private static final String KEY_CACHED_STATIC    = "cs";
    private static final String KEY_DIRECT_BUFFER    = "db";
    private static final String KEY_DIRECT_BUFFER_SRC= "db_s";  // ByteBuffer de tamaño source
    /** Ping-pong para copias del blend GPU (GpuFrameProcessor / ASIFgGpuProcessor).
     *  Evita new byte[] por frame en el hot path GPU. */
    private static final String KEY_GPU_BLEND_COPY_A = "gba";
    private static final String KEY_GPU_BLEND_COPY_B = "gbb";
    private static final String KEY_RENDER_BITMAP    = "rb";
    private static final String KEY_RENDER_BITMAP_SRC= "rb_s";  // Bitmap del tamaño source
    private static final String KEY_XMAP             = "xm";
    private static final String KEY_YMAP             = "ym";
    private static final String KEY_LAST_FRAME_TIME  = "lt";
    /** Buffer target-sized para el frame predicho (SIFg v1.0 predictivo). */
    private static final String KEY_PREDICT_FRAME    = "prd";

    // ── ASIFg: parámetros del grid de bloques ─────────────────────────────────
    /**
     * Grid reducido a 4×4 (16 bloques en lugar de 36) para mejorar rendimiento.
     * Con la red reducida (H1=16, H2=8) y este grid, el coste de buildFlowField
     * baja ~4× respecto a la versión original 6×6 / H1=32 / H2=16.
     */
    private static final int ASIFG_GRID_COLS = 4;
    private static final int ASIFG_GRID_ROWS = 4;

    /**
     * Factor de suavizado EMA del campo de flujo ASIFg.
     * 0=todo nuevo (reactivo pero inestable), 1=todo historial (estable pero lento).
     * 0.50 da 50% de historia — evita que un frame ruidoso genere artefactos visibles.
     */
    private static final float FLOW_EMA = 0.20f;

    // ── Hilos y handlers ──────────────────────────────────────────────────────
    private HandlerThread processingThread;
    private Handler       processingHandler;
    private HandlerThread captureThread;
    private Handler       captureHandler;
    private HandlerThread renderThread;
    private Handler       renderHandler;
    private final Handler mainHandler = new Handler(Looper.getMainLooper());

    // ── MediaProjection / captura ─────────────────────────────────────────────
    private MediaProjection                    projection;
    private android.hardware.display.VirtualDisplay virtualDisplay;
    private ImageReader                        imageReader;
    /**
     * true mientras hay un Generator ejecutándose en processingHandler.
     * Evita acumular Generators en la cola cuando el procesador es lento.
     */
    private volatile boolean processingBusy = false;
    private volatile boolean running        = false;

    // ── Configuración (thread-safe por volatilidad de primitivos) ────────────
    private volatile int   currentMode       = MODE_PERFORMANCE;
    private volatile int   sifgVersion       = 0;
    private volatile float resolutionScale   = DEFAULT_RESOLUTION_SCALE;
    private volatile int   framesToGenerate  = DEFAULT_FRAMES_TO_GENERATE;
    private volatile int   colorQuality      = DEFAULT_COLOR_QUALITY;
    private volatile int   fisheyeCorrection = DEFAULT_FISHEYE_CORRECTION;
    private volatile boolean useSIFg         = false;
    private volatile boolean useASIFg        = false;
    /** GPU mode via RenderScript. Se inicializa en startCapture, se destruye en stopCapture. */
    private volatile boolean useGpu          = false;
    /** ASIFg con aceleración GPU: los frames sintéticos se generan en RS. */
    private volatile boolean asifgGpu        = false;
    private RenderScriptPipeline rsPipeline  = null;
    /**
     * Reenvío de toques al sistema de accesibilidad. Desactivado por defecto.
     * El overlay es FLAG_NOT_TOUCHABLE: los toques pasan al sistema sin necesidad
     * de este mecanismo. Solo se activa si el usuario lo habilita explícitamente.
     */
    private volatile boolean touchForwardEnabled = false;
    private volatile int     captureMode        = CAPTURE_MODE_FULLSCREEN;

    // ── Red neuronal ASIFg ────────────────────────────────────────────────────
    private ASIFgNetwork asifgNet = null;

    // ── Dimensiones ───────────────────────────────────────────────────────────
    private int sourceWidth, sourceHeight;
    private int targetWidth, targetHeight;
    private int topInset, bottomInset;

    // ── Estadísticas atómicas ─────────────────────────────────────────────────
    private final AtomicInteger framesProcessed  = new AtomicInteger(0);
    private final AtomicLong    lastFpsUpdate     = new AtomicLong(0);
    private final AtomicInteger droppedFrames     = new AtomicInteger(0);
    private final AtomicInteger currentFps        = new AtomicInteger(0);
    private final AtomicInteger captureErrorCount = new AtomicInteger(0);

    // ── Detección de frame estático ───────────────────────────────────────────
    private static final int HASH_HISTORY = 10;
    private final long[] hashHistory = new long[HASH_HISTORY];
    private int hashHead    = 0;
    private int hashFilled  = 0;
    private int staticCount = 0;

    // ── Caché de buffers ──────────────────────────────────────────────────────
    /**
     * Almacén de buffers reutilizables. Creados en {@link #initializeBufferPools()}
     * y liberados en {@link #releaseBuffers()}.
     * Solo se accede desde el hilo de procesamiento, excepto KEY_RENDER_BITMAP y
     * KEY_DIRECT_BUFFER (sincronizados).
     */
    private final HashMap<String, Object> resourceCache = new HashMap<String, Object>();

    // ── Upscaler ping-pong ────────────────────────────────────────────────────
    private boolean useUpscaleA       = true;
    private boolean useExtrapolationA = true;
    /** Ping-pong para el buffer de blend de SIFg v1.1 (evita race con renderHandler). */
    private boolean sifgBlendSlotA    = true;
    private boolean copySlotA         = true;  // ping-pong de copySourceBuffer

    // ── Render ────────────────────────────────────────────────────────────────
    private Paint   bitmapPaint;
    private Paint   fisheyePaint;
    private float[] fisheyeVerts;
    private int     lastFisheyeFactor = Integer.MIN_VALUE;
    private int     lastFisheyeW     = -1;
    private int     lastFisheyeH     = -1;
    /** Rect destino cacheado — siempre (0,0,targetWidth,targetHeight), no crear por frame. */
    private android.graphics.Rect cachedDstRect = null;
    /** Rect fuente cacheado para el recorte de insets — se recrea solo cuando cambian los valores. */
    private android.graphics.Rect cachedSrcRect    = null;
    private int cachedSrcRectSrcW   = -1;
    private int cachedSrcRectSrcH   = -1;
    private int cachedSrcRectTop    = Integer.MIN_VALUE;
    private int cachedSrcRectBottom = Integer.MIN_VALUE;

    // ── Overlay ───────────────────────────────────────────────────────────────
    private WindowManager windowManager;
    private SurfaceView   overlayView;
    private FrameLayout   overlayContainer;
    private android.view.Surface overlaySurface;
    private volatile boolean isSurfaceValid = false;
    private long lastRenderTime = 0;

    // ── Sesión ────────────────────────────────────────────────────────────────
    private long sessionStartTime   = 0;
    private long sessionTotalFrames = 0;
    private SharedPreferences prefs;

    // ── Deadline de frame ─────────────────────────────────────────────────────
    private long nextFrameDeadlineNs = 0;

    // ── EMA del movimiento global (SIFg) ──────────────────────────────────────
    private float sifgPrevDx = 0f;
    private float sifgPrevDy = 0f;

    /**
     * Vector de movimiento suavizado para SIFg v1.0 (predicción, espacio target).
     * Resetear a 0 en setMode / resetHashHistory.
     */
    private int sifgV10Dx = 0;
    private int sifgV10Dy = 0;

    /** Contador para saltar learnOnline en ASIFg cada cierto número de frames. */
    private int asifgLearnCounter = 0;

    // ── Campos de flujo ASIFg ─────────────────────────────────────────────────
    private final float[] asifgFlowDx   = new float[ASIFG_GRID_COLS * ASIFG_GRID_ROWS];
    private final float[] asifgFlowDy   = new float[ASIFG_GRID_COLS * ASIFG_GRID_ROWS];
    private final float[] asifgSmoothDx = new float[ASIFG_GRID_COLS * ASIFG_GRID_ROWS];
    private final float[] asifgSmoothDy = new float[ASIFG_GRID_COLS * ASIFG_GRID_ROWS];
    /** Tablas de interpolación bilineal pre-calculadas (se llenan en allocateBuffers). */
    private int[]   asifgColIdx;   // por cada x: índice de columna de bloque izquierda
    private float[] asifgColW;     // por cada x: peso hacia la columna derecha [0,1]
    private int[]   asifgRowIdx;   // por cada y: índice de fila de bloque superior
    private float[] asifgRowW;     // por cada y: peso hacia la fila inferior [0,1]
    private final int[]   asifgRefPatch  =
	new int[2 + ASIFgNetwork.PATCH * ASIFgNetwork.PATCH];

    /** Bitmap de ping-pong para FrameProcessor (evita race entre capture y render). */
    private static final String KEY_RENDER_BITMAP_SRC_B = "rb_sb";

    // ── Pool de Runnables de render (evita allocaciones por frame) ────────────
    /** Tamaño del anillo de FrameRenderRunnables. 8 > 2 renders/frame a 60fps. */
    private static final int RENDER_POOL_SIZE = 8;
    private final FrameRenderRunnable[] renderPool = new FrameRenderRunnable[RENDER_POOL_SIZE];
    private int renderPoolHead = 0;

    // Pool de 2 ReleaseRunnables (alternados, 1 en vuelo máximo por diseño)
    private final ReleaseRunnable[] releasePool = { new ReleaseRunnable(), new ReleaseRunnable() };
    private int releasePoolIdx = 0;
    /** Ticket esperado por cada ReleaseRunnable para evitar doble liberación. */
    private int lastIssuedTicket = 0;

    // Ping-pong para copias del blend en modo GPU (evita new byte[] por frame)
    private boolean gpuBlendSlotA = true;

    // ── Render: "latest-wins" ─────────────────────────────────────────────────
    private volatile byte[] pendingRenderFrame = null;
    private final Runnable renderPendingRunnable = new Runnable() {
        @Override public void run() {
            byte[] frame = pendingRenderFrame;
            if (frame != null) renderInternal(frame);
        }
    };

    /**
     * Runnable nombrado para renderBitmapDirect — permite cancelarlo con removeCallbacks.
     * pendingRenderBitmap es el Bitmap más reciente a dibujar (ping-pong garantiza
     * que nadie sobreescribe este bitmap mientras se renderiza).
     */
    private volatile Bitmap pendingRenderBitmap = null;
    /** Slot de ping-pong del Bitmap fuente: true=A (KEY_RENDER_BITMAP_SRC), false=B. */
    private boolean renderSrcSlotA = true;
    private final Runnable renderBitmapRunnable = new Runnable() {
        @Override public void run() {
            Bitmap bmp = pendingRenderBitmap;
            if (bmp == null || bmp.isRecycled() || !isSurfaceValid) {
                return;
            }
            android.graphics.Rect srcRect = null;
            if (captureMode == CAPTURE_MODE_FULLSCREEN && (topInset > 0 || bottomInset > 0)) {
                float scaleY   = (float) sourceHeight / targetHeight;
                int cropTop    = (int)(topInset    * scaleY);
                int cropBottom = sourceHeight - (int)(bottomInset * scaleY);
                cropTop    = Math.max(0, Math.min(cropTop,    sourceHeight - 1));
                cropBottom = Math.max(cropTop + 1, Math.min(cropBottom, sourceHeight));
                if (cropTop > 0 || cropBottom < sourceHeight) {
                    srcRect = new android.graphics.Rect(0, cropTop, sourceWidth, cropBottom);
                }
            }
            android.graphics.Rect dstRect = cachedDstRect != null
                ? cachedDstRect
                : new android.graphics.Rect(0, 0, targetWidth, targetHeight);

            Canvas canvas = null;
            try {
                canvas = overlayView.getHolder().lockCanvas(null);
                if (canvas == null) return;

                if (fisheyeCorrection != 0) {
                    Bitmap stretched = Bitmap.createBitmap(
                        targetWidth, targetHeight, Bitmap.Config.ARGB_8888);
                    Canvas tmp = new Canvas(stretched);
                    tmp.drawBitmap(bmp, srcRect, dstRect, bitmapPaint);
                    applyFisheyeCorrection(canvas, stretched);
                    stretched.recycle();
                } else {
                    canvas.drawBitmap(bmp, srcRect, dstRect, bitmapPaint);
                }
                lastRenderTime = System.currentTimeMillis();
            } catch (Exception e) {
                Log.e(TAG, "Error renderBitmapDirect", e);
            } finally {
                if (canvas != null) {
                    try { overlayView.getHolder().unlockCanvasAndPost(canvas); }
                    catch (Exception e) { Log.e(TAG, "Error unlock", e); }
                }
                // processingBusy ya fue liberado en FrameProcessor tras copyPixelsFromBuffer.
                // El render es completamente independiente del pipeline de captura.
            }
        }
    };

    // ── Binder ───────────────────────────────────────────────────────────────
    private final IBinder binder = new LocalBinder();

    public class LocalBinder extends Binder {
        public ScreenCaptureService getService() { return ScreenCaptureService.this; }
    }

    @Override
    public IBinder onBind(Intent intent) { return binder; }

    // ── Receptor interno STOP ─────────────────────────────────────────────────
    private final BroadcastReceiver controlReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            if (ACTION_STOP.equals(intent.getAction())) stopCapture();
        }
    };

    // ════════════════════════════════════════════════════════════════════════
    //  Ciclo de vida del servicio
    // ════════════════════════════════════════════════════════════════════════

    @Override
    public void onCreate() {
        super.onCreate();

        processingThread = new HandlerThread("ScalerThread",
											 Process.THREAD_PRIORITY_URGENT_DISPLAY);
        processingThread.start();
        processingHandler = new Handler(processingThread.getLooper());

        captureThread = new HandlerThread("CaptureThread",
										  Process.THREAD_PRIORITY_URGENT_DISPLAY);
        captureThread.start();
        captureHandler = new Handler(captureThread.getLooper());

        renderThread = new HandlerThread("RenderThread",
										 Process.THREAD_PRIORITY_URGENT_DISPLAY);
        renderThread.start();
        renderHandler = new Handler(renderThread.getLooper());

        // Elevar también la prioridad del hilo del servicio (el que llama onCreate)
        Process.setThreadPriority(Process.THREAD_PRIORITY_URGENT_DISPLAY);

        prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
        createNotificationChannel();
        registerReceiver(controlReceiver, new IntentFilter(ACTION_STOP));
        nextFrameDeadlineNs = System.nanoTime();

        // Inicializar pool de Runnables de render (cero allocaciones durante la captura)
        for (int i = 0; i < RENDER_POOL_SIZE; i++) renderPool[i] = new FrameRenderRunnable();
    }

    @Override
    public void onDestroy() {
        stopCapture();
        safeUnregisterReceiver();
        shutdownThread(processingThread); processingThread = null;
        shutdownThread(renderThread);     renderThread     = null;
        shutdownThread(captureThread);    captureThread    = null;
        releaseBuffers();
        super.onDestroy();
    }

    private void safeUnregisterReceiver() {
        try { unregisterReceiver(controlReceiver); }
        catch (Exception e) { Log.e(TAG, "Error unregistering receiver", e); }
    }

    private void shutdownThread(HandlerThread thread) {
        if (thread == null) return;
        if (Build.VERSION.SDK_INT >= 18) thread.quitSafely();
        else                             thread.quit();
        long deadline = System.currentTimeMillis() + 500;
        while (thread.isAlive() && System.currentTimeMillis() < deadline) {
            try { Thread.sleep(10); } catch (InterruptedException ignored) {}
        }
    }

    // ════════════════════════════════════════════════════════════════════════
    //  Notificación
    // ════════════════════════════════════════════════════════════════════════

    private void createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel ch = new NotificationChannel(
				CHANNEL_ID, "Screen Capture Service",
				NotificationManager.IMPORTANCE_LOW);
            ch.setDescription("Servicio de captura de pantalla activo");
            NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
            if (nm != null) nm.createNotificationChannel(ch);
        }
    }

    private Notification buildNotification() {
        int piFlags = (Build.VERSION.SDK_INT >= 31)
			? PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE
			: PendingIntent.FLAG_UPDATE_CURRENT;
        PendingIntent stopPi = PendingIntent.getBroadcast(
			this, 2, new Intent(ACTION_STOP), piFlags);

        Notification.Builder builder = (Build.VERSION.SDK_INT >= 26)
			? new Notification.Builder(this, CHANNEL_ID)
			: new Notification.Builder(this);

        builder.setContentTitle("Frame Generator Pro")
			.setContentText("Captura activa - FPS: " + currentFps.get())
			.setSmallIcon(android.R.drawable.ic_menu_camera)
			.addAction(android.R.drawable.ic_menu_close_clear_cancel, "Detener", stopPi);
        return builder.build();
    }

    private void updateNotification() {
        NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        if (nm != null) nm.notify(NOTIFICATION_ID, buildNotification());
    }

    // ════════════════════════════════════════════════════════════════════════
    //  Setters de configuración (thread-safe)
    // ════════════════════════════════════════════════════════════════════════

    public void setMode(int mode) {
        this.currentMode = mode;
        this.useSIFg     = (mode == MODE_SIFG1);
        this.useASIFg    = (mode == MODE_ASIFG || mode == MODE_ASIFG_GPU);
        this.useGpu      = (mode == MODE_GPU   || mode == MODE_ASIFG_GPU);
        this.asifgGpu    = (mode == MODE_ASIFG_GPU);
        if (this.useASIFg && asifgNet == null) {
            asifgNet = new ASIFgNetwork();
        }
        // Inicializar / destruir pipeline GPU según el modo
        if (this.useGpu) {
            if (rsPipeline == null) {
                rsPipeline = new RenderScriptPipeline(this);
            }
            if (running) {
                rsPipeline.init(sourceWidth, sourceHeight, targetWidth, targetHeight);
            }
        } else {
            if (rsPipeline != null) {
                rsPipeline.destroy();
                rsPipeline = null;
            }
        }
        resetHashHistory();
    }

    public void setSifgVersion(int version)          { this.sifgVersion      = version; }
    public void setResolutionScale(float scale)      { this.resolutionScale  = scale;   }
    public void setFramesToGenerate(int count)       { this.framesToGenerate = Math.max(0, Math.min(4, count)); }
    public void setColorQuality(int quality)         { this.colorQuality     = quality; }
    public void setFisheyeCorrection(int correction) { this.fisheyeCorrection = correction; }
    public void setTouchForwardEnabled(boolean enabled) { this.touchForwardEnabled = enabled; }
    public void setTargetFps(int fps) {
        // Clamp a rango razonable: 10–240 FPS
        fps = Math.max(10, Math.min(240, fps));
        targetFrameNanos = 1_000_000_000L / fps;
    }

    // ════════════════════════════════════════════════════════════════════════
    //  Getters de estadísticas
    // ════════════════════════════════════════════════════════════════════════

    public int  getFps()              { return currentFps.get();      }
    public int  getTotalFrames()      { return framesProcessed.get(); }
    public int  getDroppedFrames()    { return droppedFrames.get();   }
    public long getSessionFrames()    { return sessionTotalFrames;    }
    public int  getLearnCount()       { return asifgLearnCounter;     }
    /** Eficiencia: % frames no descartados sobre total intentados. */
    public int  getEfficiencyPct() {
        int processed = framesProcessed.get();
        int dropped   = droppedFrames.get();
        int total     = processed + dropped;
        return total > 0 ? (int)(processed * 100L / total) : 100;
    }

    // ════════════════════════════════════════════════════════════════════════
    //  Inicio / parada de la captura
    // ════════════════════════════════════════════════════════════════════════

    public void startCapture(int resultCode, Intent data,
                             int srcW, int srcH,
                             int tgtW, int tgtH,
                             int dpi, int top, int bottom,
                             int mode) {
        if (running) return;

        this.sourceWidth  = srcW;
        this.sourceHeight = srcH;
        this.targetWidth  = tgtW;
        this.targetHeight = tgtH;
        this.topInset     = top;
        this.bottomInset  = bottom;
        this.captureMode  = mode;

        initializeBufferPools();
        precalculateMappings();
        invalidateFisheyeCache();

        // Inicializar GPU pipeline si el modo ya es GPU
        if (useGpu) {
            if (rsPipeline == null) rsPipeline = new RenderScriptPipeline(this);
            rsPipeline.init(srcW, srcH, tgtW, tgtH);
        }

        ensureOverlayOnMainThread();

        try {
            startForeground(NOTIFICATION_ID, buildNotification());

            MediaProjectionManager mpManager =
				(MediaProjectionManager) getSystemService(Context.MEDIA_PROJECTION_SERVICE);
            if (mpManager == null) { stopCapture(); return; }

            projection = mpManager.getMediaProjection(resultCode, data);
            if (projection == null) { stopCapture(); return; }

            // Buffer de 3 imágenes: 1 en uso, 1 lista, 1 reserva
            imageReader = ImageReader.newInstance(srcW, srcH, PixelFormat.RGBA_8888, 3);
            // captureHandler para el callback: la adquisición de imágenes
            // corre en su propio thread, sin bloquear el processingHandler.
            imageReader.setOnImageAvailableListener(new ImageAvailableListener(),
                    captureHandler);
            virtualDisplay = projection.createVirtualDisplay(
				"ScreenScaler", srcW, srcH, dpi,
				DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
				imageReader.getSurface(), null, null);

            processingBusy     = false;
            running            = true;
            sessionStartTime   = System.currentTimeMillis();
            sessionTotalFrames = 0;
            lastFpsUpdate.set(System.currentTimeMillis());
            framesProcessed.set(0);
            droppedFrames.set(0);
            nextFrameDeadlineNs = System.nanoTime();

            processingHandler.post(new FpsUpdater());

        } catch (Exception e) {
            Log.e(TAG, "Error iniciando captura", e);
            stopCapture();
        }
    }

    public void stopCapture() {
        if (!running) return;
        running = false;
        saveStats();

        safeRelease(virtualDisplay); virtualDisplay = null;
        safeClose(imageReader);      imageReader    = null;
        safeStop(projection);        projection     = null;

        if (rsPipeline != null) { rsPipeline.destroy(); rsPipeline = null; }

        removeOverlayWindow();
        stopForeground(true);
        releaseBuffers();
        stopSelf();
    }

    public void updateResolution(int srcW, int srcH, int tgtW, int tgtH) {
        this.sourceWidth  = srcW;
        this.sourceHeight = srcH;
        this.targetWidth  = tgtW;
        this.targetHeight = tgtH;
        initializeBufferPools();
        precalculateMappings();
        invalidateFisheyeCache();
    }

    /**
     * Llamado cuando el dispositivo gira.
     * Redimensiona el overlay, el VirtualDisplay y los buffers sin detener la captura.
     * Esto evita el glitch visual que ocurría al recrear todo desde cero.
     */
    public void onOrientationChanged(int srcW, int srcH, int tgtW, int tgtH,
                                     int dpi, int top, int bottom) {
        this.sourceWidth  = srcW;
        this.sourceHeight = srcH;
        this.targetWidth  = tgtW;
        this.targetHeight = tgtH;
        this.topInset     = top;
        this.bottomInset  = bottom;

        // Recalcular buffers y mappings para la nueva orientación
        initializeBufferPools();
        precalculateMappings();
        invalidateFisheyeCache();

        // Redimensionar el VirtualDisplay in-place (evita recrear la MediaProjection)
        if (virtualDisplay != null) {
            try {
                virtualDisplay.resize(srcW, srcH, dpi);
            } catch (Exception e) {
                Log.e(TAG, "Error resizing VirtualDisplay", e);
            }
        }

        // Redimensionar el overlay en el main thread
        mainHandler.post(new Runnable() {
				@Override public void run() { resizeOverlayWindow(); }
			});
    }

    /**
     * Actualiza las dimensiones del LayoutParams del overlay sin recrearlo.
     * Llamar siempre desde el main thread.
     */
    private void resizeOverlayWindow() {
        if (windowManager == null || overlayContainer == null) return;
        try {
            WindowManager.LayoutParams params =
				(WindowManager.LayoutParams) overlayContainer.getLayoutParams();
            if (params == null) return;
            params.width  = targetWidth;
            params.height = targetHeight;
            windowManager.updateViewLayout(overlayContainer, params);

            // Redimensionar también el SurfaceView interior
            if (overlayView != null) {
                android.widget.FrameLayout.LayoutParams svLp =
					new android.widget.FrameLayout.LayoutParams(targetWidth, targetHeight);
                overlayView.setLayoutParams(svLp);
            }
        } catch (Exception e) {
            Log.e(TAG, "Error resizing overlay", e);
        }
    }

    // ── Helpers de release ────────────────────────────────────────────────────

    private void safeRelease(android.hardware.display.VirtualDisplay vd) {
        if (vd == null) return;
        try { vd.release(); } catch (Exception e) { Log.e(TAG, "Error releasing VirtualDisplay", e); }
    }

    private void safeClose(ImageReader ir) {
        if (ir == null) return;
        try { ir.close(); } catch (Exception e) { Log.e(TAG, "Error closing ImageReader", e); }
    }

    private void safeStop(MediaProjection mp) {
        if (mp == null) return;
        try { mp.stop(); } catch (Exception e) { Log.e(TAG, "Error stopping MediaProjection", e); }
    }

    private void recycleBitmapFromCache(String key) {
        Bitmap b = (Bitmap) resourceCache.get(key);
        if (b != null && !b.isRecycled()) b.recycle();
        resourceCache.remove(key);
    }

    /**
     * Devuelve una copia segura del buffer fuente para encolarlo en renderHandler.
     * Necesario porque {@code src} es el buffer compartido de captura y se
     * sobreescribe con el siguiente frame antes de que el renderThread lo consuma.
     *
     * <p>Usa dos slots de copia en ping-pong (KEY_PREV_FRAME / KEY_STATIC_FRAME)
     * de modo que se pueden encolar dos frames consecutivos sin sobreescribirse.
     */
    private byte[] copySourceBuffer(byte[] src) {
        String key = copySlotA ? KEY_PREV_FRAME : KEY_STATIC_FRAME;
        copySlotA = !copySlotA;
        byte[] copy = (byte[]) resourceCache.get(key);
        if (copy == null || copy.length != src.length) {
            copy = new byte[src.length];
            resourceCache.put(key, copy);
        }
        System.arraycopy(src, 0, copy, 0, src.length);
        return copy;
    }

    // ════════════════════════════════════════════════════════════════════════
    //  Listener de imágenes (hilo captureThread)
    // ════════════════════════════════════════════════════════════════════════

    private final class ImageAvailableListener implements ImageReader.OnImageAvailableListener {
        @Override
        public void onImageAvailable(ImageReader reader) {
            if (!running) return;

            // Si el procesador sigue ocupado, descartamos esta imagen
            if (processingBusy) {
                Image img = reader.acquireLatestImage();
                if (img != null) img.close();
                droppedFrames.incrementAndGet();
                return;
            }

            long nowNs = System.nanoTime();
            if (nowNs < nextFrameDeadlineNs) {
                Image img = reader.acquireLatestImage();
                if (img != null) img.close();
                droppedFrames.incrementAndGet();
                return;
            }
            nextFrameDeadlineNs = nowNs + targetFrameNanos;

            Image image = null;
            try {
                image = reader.acquireLatestImage();
                if (image == null || !running) {
                    if (image != null) image.close();
                    return;
                }
                captureErrorCount.set(0);
                processingBusy = true;

                if (useASIFg) {
                    if (asifgGpu && rsPipeline != null && rsPipeline.isReady()) {
                        processingHandler.post(new ASIFgGpuProcessor(image));
                    } else {
                        processingHandler.post(new ASIFgGenerator(image));
                    }
                } else if (useGpu) {
                    processingHandler.post(new GpuFrameProcessor(image));
                } else if (useSIFg) {
                    if (sifgVersion == 0) processingHandler.post(new SIFgV1Generator(image));
                    else                  processingHandler.post(new SIFgV1_1Generator(image));
                } else {
                    processingHandler.post(new FrameProcessor(image));
                }

            } catch (Exception e) {
                processingBusy = false;
                Log.e(TAG, "Error acquiring image", e);
                if (image != null) image.close();
                droppedFrames.incrementAndGet();

                final int errors = captureErrorCount.incrementAndGet();
                if (errors >= 3) {
                    captureErrorCount.set(0);
                    mainHandler.post(new Runnable() {
							@Override public void run() {
								Toast.makeText(ScreenCaptureService.this,
											   "Error de captura repetido: reinicia la app",
											   Toast.LENGTH_LONG).show();
							}
						});
                }
            }
        }
    }

    // ════════════════════════════════════════════════════════════════════════
    //  Gestión de buffers
    // ════════════════════════════════════════════════════════════════════════

    private synchronized void initializeBufferPools() {
        int tSize = targetWidth  * targetHeight * 4;
        int sSize = sourceWidth  * sourceHeight * 4;

        // ── Captura (baja resolución) ─────────────────────────────────────────
        resourceCache.put(KEY_SOURCE_BUFFER,    new byte[sSize]);

        // ── Generación de frames (baja resolución) ────────────────────────────
        // La generación ocurre en espacio de captura. El upscale al tamaño de
        // pantalla se hace UNA SOLA VEZ por frame de salida, justo antes del render.
        resourceCache.put(KEY_EXTRAPOLATION,    new byte[sSize]);
        resourceCache.put(KEY_EXTRAPOLATION_B,  new byte[sSize]);
        resourceCache.put(KEY_ASIFG_SYNTH,      new byte[sSize]);
        resourceCache.put(KEY_LAST_REAL_FRAME,  new byte[sSize]);
        resourceCache.put(KEY_PREV_FRAME,       new byte[sSize]);
        resourceCache.put(KEY_STATIC_FRAME,     new byte[sSize]);
        resourceCache.put(KEY_CACHED_STATIC,    new byte[sSize]);

        // ── Tablas de interpolación bilineal para ASIFg ───────────────────────
        // Pre-calcular índice de bloque y peso para cada columna y fila de píxel.
        // Esto evita divisiones float en el loop interno de buildSyntheticFrame.
        {
            int blockW = Math.max(1, sourceWidth  / ASIFG_GRID_COLS);
            int blockH = Math.max(1, sourceHeight / ASIFG_GRID_ROWS);

            asifgColIdx = new int[sourceWidth];
            asifgColW   = new float[sourceWidth];
            for (int x = 0; x < sourceWidth; x++) {
                // Posición fraccional relativa a los centros de bloque
                float fx = (float)x / blockW - 0.5f;
                int c0 = (int)fx;
                c0 = Math.max(0, Math.min(ASIFG_GRID_COLS - 2, c0));
                asifgColIdx[x] = c0;
                asifgColW[x]   = Math.max(0f, Math.min(1f, fx - c0));
            }

            asifgRowIdx = new int[sourceHeight];
            asifgRowW   = new float[sourceHeight];
            for (int y = 0; y < sourceHeight; y++) {
                float fy = (float)y / blockH - 0.5f;
                int r0 = (int)fy;
                r0 = Math.max(0, Math.min(ASIFG_GRID_ROWS - 2, r0));
                asifgRowIdx[y] = r0;
                asifgRowW[y]   = Math.max(0f, Math.min(1f, fy - r0));
            }
        }

        // ── Upscale ping-pong y render (tamaño de pantalla completa) ──────────
        resourceCache.put(KEY_UPSCALE_A,        new byte[tSize]);
        resourceCache.put(KEY_UPSCALE_B,        new byte[tSize]);
        resourceCache.put(KEY_UPSCALE_C,        new byte[tSize]);
        resourceCache.put(KEY_UPSCALE_D,        new byte[tSize]);
        resourceCache.put(KEY_UPSCALE_E,        new byte[tSize]);
        resourceCache.put(KEY_UPSCALE_F,        new byte[tSize]);
        resourceCache.put(KEY_UPSCALE_G,        new byte[tSize]);
        resourceCache.put(KEY_UPSCALE_H,        new byte[tSize]);
        // Buffer target-sized para el frame predicho de SIFg v1.0
        resourceCache.put(KEY_PREDICT_FRAME,    new byte[tSize]);

        // ByteBuffer directo para el upscale ping-pong (tamaño target)
        ByteBuffer direct = ByteBuffer.allocateDirect(tSize);
        direct.order(ByteOrder.nativeOrder());
        resourceCache.put(KEY_DIRECT_BUFFER, direct);

        // Buffers de copia del blend GPU (ping-pong — evita new byte[] por frame)
        resourceCache.put(KEY_GPU_BLEND_COPY_A, new byte[tSize]);
        resourceCache.put(KEY_GPU_BLEND_COPY_B, new byte[tSize]);

        // Los Bitmaps y ByteBuffers para renderInternal se crean/reciclan
        // dinámicamente en ese método según el tamaño del frame recibido.
        // Limpiar entradas obsoletas de sesiones anteriores.
        recycleBitmapFromCache(KEY_RENDER_BITMAP);
        recycleBitmapFromCache(KEY_RENDER_BITMAP_SRC);
        resourceCache.remove(KEY_DIRECT_BUFFER_SRC);

        // Objetos Paint reutilizables (creados UNA sola vez)
        if (bitmapPaint == null) {
            bitmapPaint = new Paint();
            bitmapPaint.setAntiAlias(false);
            bitmapPaint.setFilterBitmap(true);   // bilinear al estirar source→target
            bitmapPaint.setDither(false);
            bitmapPaint.setAlpha(255);
            bitmapPaint.setXfermode(null);
        }
        if (fisheyePaint == null) {
            fisheyePaint = new Paint();
            fisheyePaint.setAntiAlias(false);
            fisheyePaint.setFilterBitmap(true);
            fisheyePaint.setDither(false);
            fisheyePaint.setAlpha(255);
        }
    }

    private synchronized void releaseBuffers() {
        Bitmap bmp = (Bitmap) resourceCache.get(KEY_RENDER_BITMAP);
        if (bmp != null && !bmp.isRecycled()) bmp.recycle();
        Bitmap bmpB = (Bitmap) resourceCache.get(KEY_RENDER_BITMAP_SRC_B);
        if (bmpB != null && !bmpB.isRecycled()) bmpB.recycle();
        resourceCache.clear();
    }

    // ════════════════════════════════════════════════════════════════════════
    //  Precálculo de mapas de coordenadas (nearest-neighbor)
    // ════════════════════════════════════════════════════════════════════════

    /**
     * Precalcula los índices enteros de origen para cada columna y fila del destino,
     * evitando multiplicaciones float por píxel en los bucles de upscaling.
     */
    private synchronized void precalculateMappings() {
        int[] xMap = new int[targetWidth];
        int[] yMap = new int[targetHeight];

        float invX = (float) sourceWidth  / targetWidth;
        float invY = (float) sourceHeight / targetHeight;

        for (int x = 0; x < targetWidth;  x++) xMap[x] = Math.min((int)(x * invX), sourceWidth  - 1);
        for (int y = 0; y < targetHeight; y++) yMap[y] = Math.min((int)(y * invY), sourceHeight - 1);

        resourceCache.put(KEY_XMAP, xMap);
        resourceCache.put(KEY_YMAP, yMap);
    }

    // ════════════════════════════════════════════════════════════════════════
    //  Overlay de ventana
    // ════════════════════════════════════════════════════════════════════════

    private void ensureOverlayOnMainThread() {
        if (Looper.myLooper() == Looper.getMainLooper()) {
            createOverlayWindow();
        } else {
            mainHandler.post(new Runnable() {
					@Override public void run() { createOverlayWindow(); }
				});
        }
    }

    private void createOverlayWindow() {
        if (Build.VERSION.SDK_INT >= 23 && !Settings.canDrawOverlays(this)) return;

        windowManager = (WindowManager) getSystemService(WINDOW_SERVICE);

        int overlayType = (Build.VERSION.SDK_INT >= 26)
			? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
			: WindowManager.LayoutParams.TYPE_PHONE;

        WindowManager.LayoutParams params = new WindowManager.LayoutParams(
			targetWidth, targetHeight, overlayType,
			WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
			| WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
			| WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN
			| WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS
			| WindowManager.LayoutParams.FLAG_HARDWARE_ACCELERATED,
			PixelFormat.OPAQUE);
        params.alpha   = 1.0f;
        params.gravity = Gravity.TOP | Gravity.LEFT;
        params.x = 0;
        params.y = 0;

        overlayContainer = new FrameLayout(this);
        overlayContainer.setBackgroundColor(Color.BLACK);

        overlayView = new SurfaceView(this);
        overlayView.setZOrderOnTop(true);
        overlayView.setZOrderMediaOverlay(false);
        overlayView.getHolder().setFormat(PixelFormat.OPAQUE);

        overlayContainer.addView(overlayView,
								 new FrameLayout.LayoutParams(targetWidth, targetHeight));

        overlayView.getHolder().addCallback(new SurfaceHolder.Callback() {
				@Override
				public void surfaceCreated(SurfaceHolder holder) {
					if (!running) return;
					overlaySurface  = holder.getSurface();
					isSurfaceValid  = true;
					drawBlackOnSurface(holder);
				}

				@Override
				public void surfaceChanged(SurfaceHolder holder, int format, int w, int h) {
					overlaySurface = holder.getSurface();
					isSurfaceValid = true;
					drawBlackOnSurface(holder);
				}

				@Override
				public void surfaceDestroyed(SurfaceHolder holder) {
					isSurfaceValid = false;
					overlaySurface = null;
				}
			});

        overlayContainer.setOnTouchListener(new View.OnTouchListener() {
				@Override
				public boolean onTouch(View v, MotionEvent event) {
					if (running && touchForwardEnabled
                        && ScreenScaler.TouchForwardService.isRunning()) {
						ScreenScaler.TouchForwardService.dispatchTouch(event);
						return true;
					}
					// Sin reenvío: los toques pasan al sistema a través de FLAG_NOT_TOUCHABLE
					return false;
				}
			});

        try {
            windowManager.addView(overlayContainer, params);
        } catch (Exception e) {
            Log.e(TAG, "Error adding overlay window", e);
        }
    }

    private void drawBlackOnSurface(SurfaceHolder holder) {
        Canvas c = null;
        try {
            c = holder.lockCanvas(null);
            if (c != null) c.drawColor(Color.BLACK);
        } catch (Exception e) {
            Log.e(TAG, "Error drawing initial black", e);
        } finally {
            if (c != null) {
                try { holder.unlockCanvasAndPost(c); }
                catch (Exception e) { Log.e(TAG, "Error unlocking initial canvas", e); }
            }
        }
    }

    private void removeOverlayWindow() {
        if (windowManager == null || overlayContainer == null) return;

        final WindowManager wm = windowManager;
        final FrameLayout   oc = overlayContainer;
        windowManager    = null;
        overlayContainer = null;
        overlayView      = null;
        isSurfaceValid   = false;
        overlaySurface   = null;

        Runnable removeRunnable = new Runnable() {
            @Override public void run() {
                try { wm.removeView(oc); }
                catch (Exception e) { Log.e(TAG, "Error removing overlay", e); }
            }
        };

        if (Looper.myLooper() == Looper.getMainLooper()) removeRunnable.run();
        else                                              mainHandler.post(removeRunnable);
    }

    // ════════════════════════════════════════════════════════════════════════
    //  Hash para detección de frame estático
    // ════════════════════════════════════════════════════════════════════════

    /**
     * Hash djb2 que muestrea ~256 bytes distribuidos en 4 zonas del buffer.
     */
    private long calculateHash(byte[] data) {
        if (data == null || data.length == 0) return 0L;
        final long seed    = 5381L;
        long hash          = seed;
        final int  len     = data.length;
        final int  step    = len < 1024 ? 4 : (len >> 8);  // len/256 sin división
        final int  quarter = len >> 2;                       // len/4 sin división

        for (int zone = 0; zone < 4; zone++) {
            int base = zone * quarter;
            int end  = base + quarter;
            for (int i = base; i < end; i += step) {
                hash = ((hash << 5) + hash) ^ (data[i] & 0xFF);
            }
        }
        return hash;
    }

    private void resetHashHistory() {
        Arrays.fill(hashHistory, 0L);
        hashHead    = 0;
        hashFilled  = 0;
        staticCount = 0;
        sifgV10Dx   = 0;
        sifgV10Dy   = 0;
        sifgPrevDx  = 0f;
        sifgPrevDy  = 0f;
    }

    /**
     * Registra un hash en el historial circular y devuelve {@code true} si
     * todos los hashes del historial completo son iguales (frame estático).
     */
    private boolean recordHashAndCheckStatic(long hash) {
        hashHistory[hashHead] = hash;
        hashHead = (hashHead + 1) % HASH_HISTORY;
        if (hashFilled < HASH_HISTORY) hashFilled++;
        if (hashFilled < HASH_HISTORY) return false;

        for (int i = 0; i < HASH_HISTORY; i++) {
            if (hashHistory[i] != hash) return false;
        }
        return true;
    }

    // ════════════════════════════════════════════════════════════════════════
    //  Captura de imagen al buffer
    // ════════════════════════════════════════════════════════════════════════

    /**
     * Lee los datos RGBA del {@link Image} y los almacena en {@code dest}.
     * Aplica la reducción de color según {@link #colorQuality}:
     * <ul>
     *   <li>0 → Full color (24-bit)</li>
     *   <li>1 → 5-bit por canal RGB (aspecto 16-bit)</li>
     *   <li>2 → 3-3-2 bit (256 colores)</li>
     * </ul>
     */
    private void captureImageToBuffer(Image image, byte[] dest) {
        if (image == null || dest == null) return;
        Image.Plane[] planes = image.getPlanes();
        if (planes.length == 0) return;

        ByteBuffer buf       = planes[0].getBuffer();
        int        pixStride = planes[0].getPixelStride();
        int        rowStride = planes[0].getRowStride();
        int        rowPad    = rowStride - pixStride * sourceWidth;

        buf.rewind();

        try {
            // ── Fast path: sin padding ni reducción de color ─────────────────
            if (pixStride == 4 && rowPad == 0 && colorQuality == 0) {
                int needed = sourceWidth * sourceHeight * 4;
                if (dest.length >= needed && buf.capacity() >= needed) {
                    buf.get(dest, 0, needed);
                    return;
                }
            }

            // ── Fast path por filas: pixStride==4 pero hay rowPad ───────────
            if (pixStride == 4 && colorQuality == 0) {
                int rowBytes = sourceWidth * 4;
                int destPos  = 0;
                for (int y = 0; y < sourceHeight; y++) {
                    buf.get(dest, destPos, rowBytes);
                    destPos += rowBytes;
                    if (rowPad > 0) buf.position(buf.position() + rowPad);
                }
                return;
            }

            // ── Slow path: pixStride != 4 o reducción de color ───────────────
            captureSlowPath(buf, dest, pixStride, rowPad);

        } catch (Exception e) {
            Log.e(TAG, "Error capturando imagen", e);
        }
    }

    private void captureSlowPath(ByteBuffer buf, byte[] dest, int pixStride, int rowPad) {
        int h       = sourceHeight;
        int w       = sourceWidth;
        int cap     = buf.capacity();
        int dlen    = dest.length;
        int bufPos  = 0;
        int destPos = 0;

        switch (colorQuality) {
            case 1: // 5-bit por canal (bounds check hoisted al nivel de fila)
                for (int y = 0; y < h; y++) {
                    int rowBufEnd  = bufPos  + w * pixStride;
                    int rowDestEnd = destPos + w * 4;
                    if (rowBufEnd - 1 < cap && rowDestEnd - 1 < dlen) {
                        // Fast inner: sin bounds check por pixel
                        for (int x = 0; x < w; x++) {
                            dest[destPos]     = (byte)(buf.get(bufPos)     & 0xF8);
                            dest[destPos + 1] = (byte)(buf.get(bufPos + 1) & 0xF8);
                            dest[destPos + 2] = (byte)(buf.get(bufPos + 2) & 0xF8);
                            dest[destPos + 3] = buf.get(bufPos + 3);
                            bufPos  += pixStride;
                            destPos += 4;
                        }
                    } else {
                        // Slow fallback: la fila cruza límite del buffer (raro)
                        for (int x = 0; x < w; x++) {
                            if (bufPos + 3 < cap && destPos + 3 < dlen) {
                                dest[destPos]     = (byte)(buf.get(bufPos)     & 0xF8);
                                dest[destPos + 1] = (byte)(buf.get(bufPos + 1) & 0xF8);
                                dest[destPos + 2] = (byte)(buf.get(bufPos + 2) & 0xF8);
                                dest[destPos + 3] = buf.get(bufPos + 3);
                            }
                            bufPos  += pixStride;
                            destPos += 4;
                        }
                    }
                    bufPos += rowPad;
                }
                break;

            case 2: // 3-3-2 bit (256 colores, bounds hoisted)
                for (int y = 0; y < h; y++) {
                    int rowBufEnd2  = bufPos  + w * pixStride;
                    int rowDestEnd2 = destPos + w * 4;
                    if (rowBufEnd2 - 1 < cap && rowDestEnd2 - 1 < dlen) {
                        for (int x = 0; x < w; x++) {
                            int r = (buf.get(bufPos)     & 0xFF) >> 5;
                            int g = (buf.get(bufPos + 1) & 0xFF) >> 5;
                            int b = (buf.get(bufPos + 2) & 0xFF) >> 6;
                            dest[destPos]     = (byte)((r << 5) | (r << 2) | (r >> 1));
                            dest[destPos + 1] = (byte)((g << 5) | (g << 2) | (g >> 1));
                            dest[destPos + 2] = (byte)((b << 6) | (b << 4) | (b << 2) | b);
                            dest[destPos + 3] = (byte) 255;
                            bufPos  += pixStride;
                            destPos += 4;
                        }
                    } else {
                        for (int x = 0; x < w; x++) {
                            if (bufPos + 2 < cap && destPos + 3 < dlen) {
                                int r = (buf.get(bufPos)     & 0xFF) >> 5;
                                int g = (buf.get(bufPos + 1) & 0xFF) >> 5;
                                int b = (buf.get(bufPos + 2) & 0xFF) >> 6;
                                dest[destPos]     = (byte)((r << 5) | (r << 2) | (r >> 1));
                                dest[destPos + 1] = (byte)((g << 5) | (g << 2) | (g >> 1));
                                dest[destPos + 2] = (byte)((b << 6) | (b << 4) | (b << 2) | b);
                                dest[destPos + 3] = (byte) 255;
                            }
                            bufPos  += pixStride;
                            destPos += 4;
                        }
                    }
                    bufPos += rowPad;
                }
                break;

            default: // colorQuality == 0 con pixStride != 4 (bounds hoisted)
                for (int y = 0; y < h; y++) {
                    int rowBufEnd3  = bufPos  + w * pixStride;
                    int rowDestEnd3 = destPos + w * 4;
                    if (rowBufEnd3 - 1 < cap && rowDestEnd3 - 1 < dlen) {
                        for (int x = 0; x < w; x++) {
                            dest[destPos]     = buf.get(bufPos);
                            dest[destPos + 1] = buf.get(bufPos + 1);
                            dest[destPos + 2] = buf.get(bufPos + 2);
                            dest[destPos + 3] = buf.get(bufPos + 3);
                            bufPos  += pixStride;
                            destPos += 4;
                        }
                    } else {
                        for (int x = 0; x < w; x++) {
                            if (bufPos + 3 < cap && destPos + 3 < dlen) {
                                dest[destPos]     = buf.get(bufPos);
                                dest[destPos + 1] = buf.get(bufPos + 1);
                                dest[destPos + 2] = buf.get(bufPos + 2);
                                dest[destPos + 3] = buf.get(bufPos + 3);
                            }
                            bufPos  += pixStride;
                            destPos += 4;
                        }
                    }
                    bufPos += rowPad;
                }
                break;
        }
    }

    // ════════════════════════════════════════════════════════════════════════
    //  Upscaler nearest-neighbor (ping-pong)
    // ════════════════════════════════════════════════════════════════════════

    private byte[] upscaleNearestNeighbor(byte[] source) {
        if (source == null) return null;

        int[] xMap = (int[]) resourceCache.get(KEY_XMAP);
        int[] yMap = (int[]) resourceCache.get(KEY_YMAP);
        if (xMap == null || yMap == null) return null;

        byte[] dest = useUpscaleA
			? (byte[]) resourceCache.get(KEY_UPSCALE_A)
			: (byte[]) resourceCache.get(KEY_UPSCALE_B);
        useUpscaleA = !useUpscaleA;
        if (dest == null) return null;

        final int srcStride = sourceWidth * 4;
        final int dstStride = targetWidth * 4;
        final int dstLen    = dest.length;

        int lastSrcRow  = -1;
        int lastDstBase = -1;

        for (int y = 0; y < targetHeight; y++) {
            int srcRow     = yMap[y];
            int dstRowBase = y * dstStride;

            // Row-copy si mismo srcRow: System.arraycopy es ~memcpy nativo
            if (srcRow == lastSrcRow && lastDstBase >= 0
				&& dstRowBase + dstStride <= dstLen
				&& lastDstBase + dstStride <= dstLen) {
                System.arraycopy(dest, lastDstBase, dest, dstRowBase, dstStride);
                continue;
            }

            // Hoist multiplicación srcRow*srcStride fuera del bucle X
            int srcRowBase = srcRow * srcStride;
            for (int x = 0; x < targetWidth; x++) {
                int srcIdx = srcRowBase + xMap[x] * 4;  // xMap pre-calculado: sin float
                int dstIdx = dstRowBase + x * 4;
                dest[dstIdx]     = source[srcIdx];
                dest[dstIdx + 1] = source[srcIdx + 1];
                dest[dstIdx + 2] = source[srcIdx + 2];
                dest[dstIdx + 3] = (byte) 255;
            }
            lastSrcRow  = srcRow;
            lastDstBase = dstRowBase;
        }
        return dest;
    }

    // ════════════════════════════════════════════════════════════════════════
    //  Estimación de movimiento global (SIFg) — opera en baja resolución
    // ════════════════════════════════════════════════════════════════════════

    /**
     * Estima el vector de movimiento global entre dos frames en espacio de
     * <b>baja resolución</b> ({@code sourceWidth × sourceHeight}).
     * Los vectores resultantes están en píxeles de baja resolución.
     */
    /** Offsets de búsqueda para estimateGlobalMotion — static final evita allocaciones. */
    private static final int[][] GLOBAL_MOTION_OFFSETS = {
        {0,0},{4,0},{-4,0},{0,4},{0,-4},{3,3},{-3,3},{3,-3},{-3,-3}
    };

    private int[] estimateGlobalMotion(byte[] frameA, byte[] frameB) {
        if (frameA == null || frameB == null) return new int[]{0, 0};

        int stride = sourceWidth * 4;
        int lenA   = frameA.length;
        int lenB   = frameB.length;

        // 12 puntos de muestreo distribuidos uniformemente en una malla 3×4
        int[] sampleX = new int[12];
        int[] sampleY = new int[12];
        int   n = 0;
        for (int row = 1; row <= 3; row++) {
            for (int col = 1; col <= 4; col++) {
                sampleX[n] = col * sourceWidth  / 5;
                sampleY[n] = row * sourceHeight / 4;
                n++;
            }
        }

        // Offsets de búsqueda: ±4 px — static final evita allocar 9 int[2] por llamada
        final int[][] offsets = GLOBAL_MOTION_OFFSETS;

        int[] dxSamples = new int[12];
        int[] dySamples = new int[12];
        int   valid     = 0;

        for (int pt = 0; pt < 12; pt++) {
            int cx = sampleX[pt];
            int cy = sampleY[pt];
            if (cx < 4 || cy < 4 || cx >= sourceWidth - 4 || cy >= sourceHeight - 4) continue;

            int refBase = cy * stride + cx * 4;
            int bestSAD = Integer.MAX_VALUE;
            int bestDx  = 0, bestDy = 0;

            for (int[] off : offsets) {
                int nx = cx + off[0];
                int ny = cy + off[1];
                if (nx < 0 || ny < 0 || nx >= sourceWidth || ny >= sourceHeight) continue;

                int sad = 0;
                int nyStride = ny * stride;
                for (int dy = -1; dy <= 1; dy++) {
                    int aRowOff = dy * stride;
                    int bRowOff = (ny + dy) * stride;
                    for (int dx = -1; dx <= 1; dx++) {
                        int aIdx = refBase + aRowOff + dx * 4 + 1; // canal G
                        int bIdx = bRowOff + (nx + dx) * 4 + 1;
                        if (aIdx < 0 || aIdx >= lenA || bIdx < 0 || bIdx >= lenB) {
                            sad += 255;
                            continue;
                        }
                        sad += Math.abs((frameA[aIdx] & 0xFF) - (frameB[bIdx] & 0xFF));
                    }
                }
                if (sad < bestSAD) {
                    bestSAD = sad;
                    bestDx  = off[0];
                    bestDy  = off[1];
                }
            }

            if (bestSAD < 15 || bestSAD > 900) continue;
            dxSamples[valid] = bestDx;
            dySamples[valid] = bestDy;
            valid++;
        }

        if (valid == 0) return new int[]{0, 0};

        sortInPlace(dxSamples, valid);
        sortInPlace(dySamples, valid);
        return new int[]{dxSamples[valid / 2], dySamples[valid / 2]};
    }

    /** Insertion sort para arrays pequeños (n≤12): O(n²) pero ~3× más rápido que burbuja. */
    private static void sortInPlace(int[] arr, int len) {
        for (int i = 1; i < len; i++) {
            int key = arr[i], j = i - 1;
            while (j >= 0 && arr[j] > key) { arr[j + 1] = arr[j]; j--; }
            arr[j + 1] = key;
        }
    }

    // ════════════════════════════════════════════════════════════════════════
    //  M\u00e9todos auxiliares ultra-ligeros (SIFg v1.0 y v1.1)
    // ════════════════════════════════════════════════════════════════════════

    /**
     * Estima el vector de movimiento global de forma ultra-ligera pero matemáticamente refinada.
     *
     * <p>Mejoras sobre v1.0:
     * <ul>
     *   <li><b>Ponderación por gradiente:</b> los puntos con mayor contraste local tienen
     *       más peso — textura plana aporta ruido, no información.</li>
     *   <li><b>Tres canales (RGB):</b> en lugar de un solo canal G, se calcula la diferencia
     *       de los tres canales y se pondera por la varianza del patch — más robusto a
     *       iluminación uniforme.</li>
     *   <li><b>Refinamiento subpíxel parabólico:</b> dado el candidato entero ganador (dx,dy),
     *       se ajusta el mínimo de la parábola SAD(dx±1) → offset fraccionario en [-0.5, 0.5]
     *       que se suma al vector final antes de redondear.</li>
     *   <li><b>Mediana robusta:</b> el vector final es la mediana de vectores válidos
     *       (SAD no trivial), descartando outliers.</li>
     * </ul>
     *
     * <p>Coste: ~6 puntos × 9 candidatos × 3 canales = ~162 comparaciones — sigue siendo
     * negligible en 60 FPS comparado con el blending de frames.
     */
    /** Candidatos para estimateMotionUltraLight — static final evita allocaciones. */
    private static final int[][] ULTRA_LIGHT_CANDS = {
        {-3,-3},{0,-3},{3,-3},
        {-3, 0},{0, 0},{3, 0},
        {-3, 3},{0, 3},{3, 3}
    };

    private int[] estimateMotionUltraLight(byte[] prevSrc, byte[] curSrc) {
        int stride = sourceWidth * 4;
        int lenA   = prevSrc.length;
        int lenB   = curSrc.length;
        int W      = sourceWidth;
        int H      = sourceHeight;

        // 6 puntos de muestra distribuidos (2 filas × 3 columnas)
        int[] sx = { W/4,   W/2,   W*3/4,  W/4,   W/2,   W*3/4 };
        int[] sy = { H/3,   H/3,   H/3,    H*2/3, H*2/3, H*2/3 };

        // 9 candidatos: ±3 px — static final evita allocar 9 int[2] por llamada
        final int[][] cands = ULTRA_LIGHT_CANDS;

        float[] dxSamples = new float[6];
        float[] dySamples = new float[6];
        float[] weights   = new float[6];
        int validCount = 0;

        for (int pt = 0; pt < 6; pt++) {
            int cx = sx[pt], cy = sy[pt];

            // ── Gradiente local (varianza proxy) del punto A ──────────────────
            // Comparar el píxel central con sus 4 vecinos — más gradiente = más confiable
            float grad = 0f;
            int refBase = cy * stride + cx * 4;
            if (refBase + 3 < lenA) {
                for (int ch = 0; ch < 3; ch++) {
                    int ref = prevSrc[refBase + ch] & 0xFF;
                    if (cx > 0)  grad += Math.abs(ref - ((prevSrc[refBase - 4  + ch] & 0xFF)));
                    if (cx < W-1)grad += Math.abs(ref - ((prevSrc[refBase + 4  + ch] & 0xFF)));
                    if (cy > 0)  grad += Math.abs(ref - ((prevSrc[refBase - stride + ch] & 0xFF)));
                    if (cy < H-1)grad += Math.abs(ref - ((prevSrc[refBase + stride + ch] & 0xFF)));
                }
            }
            // Zona plana — poco útil, peso bajo
            if (grad < 12f) continue;

            // ── Block-matching SAD 3 canales ──────────────────────────────────
            int   bestSAD   = Integer.MAX_VALUE;
            int   bestDx    = 0, bestDy = 0;
            int   prevSAD0  = Integer.MAX_VALUE;  // SAD en (0,0) para referencia subpíxel
            int   prevSADm1 = Integer.MAX_VALUE;  // SAD en (bestDx-1, bestDy)
            int   prevSADp1 = Integer.MAX_VALUE;  // SAD en (bestDx+1, bestDy)

            for (int[] c : cands) {
                int nx = cx + c[0], ny = cy + c[1];
                if (nx < 0 || ny < 0 || nx >= W || ny >= H) continue;
                int bBase = ny * stride + nx * 4;
                if (bBase + 3 >= lenB) continue;

                // SAD 3 canales
                int sad = 0;
                for (int ch = 0; ch < 3; ch++) {
                    sad += Math.abs((prevSrc[refBase + ch] & 0xFF) - (curSrc[bBase + ch] & 0xFF));
                }

                if (c[0] == 0 && c[1] == 0) prevSAD0 = sad;
                if (sad < bestSAD) {
                    bestSAD = sad;
                    bestDx  = c[0];
                    bestDy  = c[1];
                }
            }

            // Descartar si el SAD ganador es trivial (todos iguales) o muy alto (no tracking)
            if (bestSAD > 200 || (bestSAD == prevSAD0 && bestDx == 0 && bestDy == 0
                    && bestSAD < 6)) continue;

            // ── Refinamiento subpíxel parabólico (eje X) ─────────────────────
            // Parábola: mínimo en dxSub = bestDx - (f(+1)-f(-1)) / (2*(f(+1)+f(-1)-2*f(0)))
            float dxSub = 0f;
            {
                int nxm = cx + bestDx - 1, nxp = cx + bestDx + 1;
                if (nxm >= 0 && nxp < W) {
                    int bm = cy * stride + nxm * 4;
                    int bp = cy * stride + nxp * 4;
                    if (bm + 2 < lenB && bp + 2 < lenB) {
                        int sm = 0, sp = 0;
                        for (int ch = 0; ch < 3; ch++) {
                            sm += Math.abs((prevSrc[refBase + ch] & 0xFF) - (curSrc[bm + ch] & 0xFF));
                            sp += Math.abs((prevSrc[refBase + ch] & 0xFF) - (curSrc[bp + ch] & 0xFF));
                        }
                        int denom = sm + sp - 2 * bestSAD;
                        if (denom > 0) dxSub = (float)(sm - sp) / (2f * denom);
                        dxSub = Math.max(-0.5f, Math.min(0.5f, dxSub));
                    }
                }
            }

            dxSamples[validCount] = bestDx + dxSub;
            dySamples[validCount] = bestDy;
            weights[validCount]   = grad;
            validCount++;
        }

        if (validCount == 0) return new int[]{0, 0};

        // ── Mediana ponderada (aproximada: mediana simple de los válidos) ─────
        // Ordenar por dxSamples, tomar la mediana
        sortFloatInPlace(dxSamples, validCount);
        sortFloatInPlace(dySamples, validCount);
        float medDx = dxSamples[validCount / 2];
        float medDy = dySamples[validCount / 2];

        return new int[]{Math.round(medDx), Math.round(medDy)};
    }

    /** Insertion sort para arrays pequeños (n≤6): más eficiente que burbuja. */
    private static void sortFloatInPlace(float[] arr, int len) {
        for (int i = 1; i < len; i++) {
            float key = arr[i]; int j = i - 1;
            while (j >= 0 && arr[j] > key) { arr[j + 1] = arr[j]; j--; }
            arr[j + 1] = key;
        }
    }

    /**
     * Traslada un frame RGBA en espacio de p\u00edxeles enteros (dx, dy).
     *
     * <p>Implementaci\u00f3n basada en {@code System.arraycopy} por fila: coste
     * O(w\u00d7h) pero con throughput similar a un memcpy nativo.
     * Zonas no cubiertas por la traslaci\u00f3n se rellenan con negro (0x00).
     *
     * @param src    Frame de entrada (targetWidth \u00d7 targetHeight \u00d7 4 bytes).
     * @param dst    Buffer de salida del mismo tama\u00f1o.
     * @param dx     Desplazamiento horizontal en p\u00edxeles (positivo = derecha).
     * @param dy     Desplazamiento vertical en p\u00edxeles (positivo = abajo).
     * @param w      Ancho en p\u00edxeles.
     * @param h      Alto en p\u00edxeles.
     */
    private static void translateFrame(byte[] src, byte[] dst,
                                       int dx, int dy, int w, int h) {
        final int stride = w * 4;
        Arrays.fill(dst, (byte) 0);

        // Ternarios en lugar de Math.max/min: 4 menos invocaciones de método
        int srcY0 = dy < 0 ? -dy : 0;
        int srcY1 = dy < 0 ? h   : h - dy;
        if (srcY0 >= srcY1) return;

        int srcX0 = dx < 0 ? -dx : 0;
        int srcX1 = dx < 0 ? w   : w - dx;
        if (srcX0 >= srcX1) return;

        final int copyBytes = (srcX1 - srcX0) * 4;
        final int srcXOff   = srcX0 * 4;
        final int dstXOff   = (srcX0 + dx) * 4;

        for (int sy = srcY0; sy < srcY1; sy++) {
            System.arraycopy(
                src, sy * stride + srcXOff,
                dst, (sy + dy) * stride + dstXOff,
                copyBytes
            );
        }
    }

    /**
     * Interpola dos frames RGBA al 50% sin compensaci\u00f3n de movimiento.
     *
     * <p>Por cada byte: {@code out[i] = (A[i] + B[i]) >> 1}.
     * Sin floats, sin allocaciones, extremadamente r\u00e1pido.
     * El canal alfa siempre se fuerza a 255.
     *
     * @param a   Frame anterior (source size).
     * @param b   Frame actual  (source size).
     * @param out Buffer de salida del mismo tama\u00f1o.
     */
    /**
     * Blend 50/50 de dos frames RGBA.
     * Desenrollado a 8 bytes (2 píxeles) por iteración: reduce overhead del bucle
     * y permite que el JIT vectorice o emita instrucciones SIMD en ARMv8.
     */
    private static void pureBlendFrames(byte[] a, byte[] b, byte[] out) {
        int len = Math.min(Math.min(a.length, b.length), out.length);
        int i = 0;
        // Bucle principal: 8 bytes (2 píxeles RGBA) por iteración
        for (; i + 7 < len; i += 8) {
            out[i]     = (byte)(((a[i]     & 0xFF) + (b[i]     & 0xFF)) >> 1);
            out[i + 1] = (byte)(((a[i + 1] & 0xFF) + (b[i + 1] & 0xFF)) >> 1);
            out[i + 2] = (byte)(((a[i + 2] & 0xFF) + (b[i + 2] & 0xFF)) >> 1);
            out[i + 3] = (byte) 255;
            out[i + 4] = (byte)(((a[i + 4] & 0xFF) + (b[i + 4] & 0xFF)) >> 1);
            out[i + 5] = (byte)(((a[i + 5] & 0xFF) + (b[i + 5] & 0xFF)) >> 1);
            out[i + 6] = (byte)(((a[i + 6] & 0xFF) + (b[i + 6] & 0xFF)) >> 1);
            out[i + 7] = (byte) 255;
        }
        // Tail: píxel restante (si len%8 != 0, puede haber 1 pixel extra)
        for (; i + 3 < len; i += 4) {
            out[i]     = (byte)(((a[i]     & 0xFF) + (b[i]     & 0xFF)) >> 1);
            out[i + 1] = (byte)(((a[i + 1] & 0xFF) + (b[i + 1] & 0xFF)) >> 1);
            out[i + 2] = (byte)(((a[i + 2] & 0xFF) + (b[i + 2] & 0xFF)) >> 1);
            out[i + 3] = (byte) 255;
        }
    }

    // ════════════════════════════════════════════════════════════════════════
    //  Extrapolación de movimiento rápido (SIFg v1.1) — baja resolución
    // ════════════════════════════════════════════════════════════════════════

    /**
     * Genera un frame sintético interpolado entre {@code frameA} y {@code frameB},
     * ambos en espacio de <b>baja resolución</b> (sourceWidth×sourceHeight).
     * El resultado también es de baja resolución — el upscale ocurre en renderInternal.
     */
    /** @deprecated Ya no se usa: SIFg v1.1 usa {@link #pureBlendFrames} directamente. */
    @SuppressWarnings("unused")
    private byte[] fastMotionExtrapolation(byte[] frameA, byte[] frameB) {
        if (frameA == null || frameB == null) return frameB;

        int[] motion = estimateGlobalMotion(frameA, frameB);

        float sDx = motion[0] * (1f - FLOW_EMA) + sifgPrevDx * FLOW_EMA;
        float sDy = motion[1] * (1f - FLOW_EMA) + sifgPrevDy * FLOW_EMA;
        sifgPrevDx = sDx;
        sifgPrevDy = sDy;

        if (Math.abs(sDx) < 0.5f && Math.abs(sDy) < 0.5f) return frameB;

        String extraKey = useExtrapolationA ? KEY_EXTRAPOLATION : KEY_EXTRAPOLATION_B;
        useExtrapolationA = !useExtrapolationA;

        byte[] out = (byte[]) resourceCache.get(extraKey);
        if (out == null || out.length != frameB.length) return frameB;

        int   stride = sourceWidth * 4;
        int   lenA   = frameA.length;
        int   lenB   = frameB.length;
        int   lenOut = out.length;
        float hdx    = sDx * 0.5f;
        float hdy    = sDy * 0.5f;

        for (int y = 0; y < sourceHeight; y++) {
            for (int x = 0; x < sourceWidth; x++) {
                int dstIdx = y * stride + x * 4;
                if (dstIdx + 3 >= lenOut) continue;

                int[] rgbA = bilinearSample(frameA, x - hdx, y - hdy,
                                            stride, lenA, sourceWidth, sourceHeight);
                int[] rgbB = bilinearSample(frameB, x + hdx, y + hdy,
                                            stride, lenB, sourceWidth, sourceHeight);

                int diff = Math.abs(rgbA[0]-rgbB[0])
					+ Math.abs(rgbA[1]-rgbB[1])
					+ Math.abs(rgbA[2]-rgbB[2]);

                int outR, outG, outB;
                if (diff < 30) {
                    outR = (rgbA[0] + rgbB[0]) >> 1;
                    outG = (rgbA[1] + rgbB[1]) >> 1;
                    outB = (rgbA[2] + rgbB[2]) >> 1;
                } else {
                    int origIdx = y * stride + x * 4;
                    int oaR  = (origIdx + 2 < lenA) ? (frameA[origIdx]     & 0xFF) : 128;
                    int oaG  = (origIdx + 2 < lenA) ? (frameA[origIdx + 1] & 0xFF) : 128;
                    int oaB2 = (origIdx + 2 < lenA) ? (frameA[origIdx + 2] & 0xFF) : 128;
                    int obR  = (origIdx + 2 < lenB) ? (frameB[origIdx]     & 0xFF) : 128;
                    int obG  = (origIdx + 2 < lenB) ? (frameB[origIdx + 1] & 0xFF) : 128;
                    int obB  = (origIdx + 2 < lenB) ? (frameB[origIdx + 2] & 0xFF) : 128;

                    int errA = Math.abs(rgbA[0]-oaR)+Math.abs(rgbA[1]-oaG)+Math.abs(rgbA[2]-oaB2);
                    int errB = Math.abs(rgbB[0]-obR)+Math.abs(rgbB[1]-obG)+Math.abs(rgbB[2]-obB);
                    int tot  = errA + errB;
                    int wB   = (tot < 4) ? 128 : (errA * 255) / tot;
                    int wA   = 255 - wB;
                    outR = Math.min(255, (rgbA[0]*wA + rgbB[0]*wB) >> 8);
                    outG = Math.min(255, (rgbA[1]*wA + rgbB[1]*wB) >> 8);
                    outB = Math.min(255, (rgbA[2]*wA + rgbB[2]*wB) >> 8);
                }

                out[dstIdx]     = (byte) outR;
                out[dstIdx + 1] = (byte) outG;
                out[dstIdx + 2] = (byte) outB;
                out[dstIdx + 3] = (byte) 255;
            }
        }
        return out;
    }

    /**
     * Muestreo bilineal sub-pixel en un buffer RGBA de dimensiones {@code w}×{@code h}.
     *
     * <p>Acepta cualquier tamaño de frame (source o target), lo que permite
     * usar el mismo método tanto en espacio de baja resolución como en target.
     *
     * @return Array {R, G, B} con valores [0, 255].
     */
    private static int[] bilinearSample(byte[] frame, float xF, float yF,
                                        int stride, int len, int w, int h) {
        int   x0   = (int) xF;
        int   y0   = (int) yF;
        float fxA  = xF - x0;
        float fyA  = yF - y0;
        int   r    = 0, g = 0, b = 0;
        float wSum = 0f;

        for (int ky = 0; ky <= 1; ky++) {
            float wy = (ky == 0) ? (1f - fyA) : fyA;
            int   ny = y0 + ky;
            if (ny < 0 || ny >= h) continue;
            for (int kx = 0; kx <= 1; kx++) {
                float wx = (kx == 0) ? (1f - fxA) : fxA;
                int   nx = x0 + kx;
                if (nx < 0 || nx >= w) continue;
                int   idx = ny * stride + nx * 4;
                if (idx + 2 >= len) continue;
                float ww = wy * wx;
                r    += (int)(ww * (frame[idx]     & 0xFF));
                g    += (int)(ww * (frame[idx + 1] & 0xFF));
                b    += (int)(ww * (frame[idx + 2] & 0xFF));
                wSum += ww;
            }
        }

        if (wSum < 0.001f) {
            int cx  = Math.max(0, Math.min(w - 1, x0));
            int cy  = Math.max(0, Math.min(h - 1, y0));
            int idx = cy * stride + cx * 4;
            r = (idx + 2 < len) ? (frame[idx]     & 0xFF) : 0;
            g = (idx + 2 < len) ? (frame[idx + 1] & 0xFF) : 0;
            b = (idx + 2 < len) ? (frame[idx + 2] & 0xFF) : 0;
            wSum = 1f;
        }

        return new int[]{
            Math.min(255, (int)(r / wSum)),
            Math.min(255, (int)(g / wSum)),
            Math.min(255, (int)(b / wSum))
        };
    }

    // ════════════════════════════════════════════════════════════════════════
    //  Render a Surface
    // ════════════════════════════════════════════════════════════════════════

    /** "Latest wins": descarta el post anterior si aún no se ejecutó. */
    private void renderToSurface(byte[] frameData) {
        pendingRenderFrame = frameData;
        renderHandler.removeCallbacks(renderPendingRunnable);
        renderHandler.post(renderPendingRunnable);
    }

    /**
     * Encola un frame en FIFO estricto, sin cancelar frames previos.
     * Usar cuando el orden de los frames importa (SIFg v1.1, ASIFg).
     */
    private void renderToSurfaceOrdered(byte[] frameData) {
        // Pool circular de FrameRenderRunnables: cero allocaciones por frame
        FrameRenderRunnable r = renderPool[renderPoolHead];
        renderPoolHead = (renderPoolHead + 1) % RENDER_POOL_SIZE;
        r.frameData = frameData;
        renderHandler.post(r);
    }

    /**
     * Libera el lock de procesamiento DESDE el renderHandler, de modo que el
     * siguiente frame de captura solo puede entrar DESPUÉS de que todos los
     * frames encolados anteriormente han sido renderizados.
     *
     * <p>Uso exclusivo para modos ORDERED (SIFg v1.1, ASIFg, ASIFg-GPU):
     * se encola como ÚLTIMO elemento del renderHandler al final de cada ciclo
     * de procesamiento, en lugar de hacer processingBusy = false en el finally
     * del thread de procesamiento.
     *
     * <p>Esto elimina la race condition en la que el siguiente procesador
     * sobreescribe un buffer compartido antes de que renderInternal lo consuma.
     */
    /**
     * Ticket atómico para el lock de procesamiento ordenado.
     * Cada llamada a releaseProcessingLockOrdered() captura el ticket actual.
     * Solo el Runnable con el ticket correcto libera el lock — si se encola
     * dos veces por error, el segundo no hace nada porque el ticket ya cambió.
     */
    private final java.util.concurrent.atomic.AtomicInteger lockTicket =
            new java.util.concurrent.atomic.AtomicInteger(0);

    /**
     * Libera processingBusy INMEDIATAMENTE desde el processingThread.
     * El procesamiento ya terminó y los buffers upscale están en el anillo de 6,
     * así que el siguiente frame real puede capturarse y procesarse en paralelo
     * mientras renderHandler dibuja los frames ya encolados.
     * Ya no es necesario esperar al render para proteger los buffers.
     */
    private void releaseProcessingLockOrdered() {
        processingBusy = false;
    }

    private void renderInternal(byte[] frameData) {
        if (!isSurfaceValid || frameData == null) return;

        int totalPixels = frameData.length / 4;
        int srcW, srcH;
        if (totalPixels == sourceWidth * sourceHeight) {
            srcW = sourceWidth;
            srcH = sourceHeight;
        } else if (totalPixels == targetWidth * targetHeight) {
            srcW = targetWidth;
            srcH = targetHeight;
        } else {
            return;
        }

        // cachedSrcRect: evita new Rect() por frame cuando hay insets activos
        android.graphics.Rect srcRect = null;
        if (captureMode == CAPTURE_MODE_FULLSCREEN && (topInset > 0 || bottomInset > 0)) {
            if (cachedSrcRect != null
                    && cachedSrcRectSrcW   == srcW
                    && cachedSrcRectSrcH   == srcH
                    && cachedSrcRectTop    == topInset
                    && cachedSrcRectBottom == bottomInset) {
                srcRect = cachedSrcRect;
            } else {
                float scaleY   = (float) srcH / targetHeight;
                int cropTop    = (int)(topInset    * scaleY);
                int cropBottom = srcH - (int)(bottomInset * scaleY);
                cropTop    = Math.max(0, Math.min(cropTop,    srcH - 1));
                cropBottom = Math.max(cropTop + 1, Math.min(cropBottom, srcH));
                if (cropTop > 0 || cropBottom < srcH) {
                    cachedSrcRect       = new android.graphics.Rect(0, cropTop, srcW, cropBottom);
                    cachedSrcRectSrcW   = srcW;
                    cachedSrcRectSrcH   = srcH;
                    cachedSrcRectTop    = topInset;
                    cachedSrcRectBottom = bottomInset;
                    srcRect = cachedSrcRect;
                } else {
                    cachedSrcRect = null;
                }
            }
        } else {
            cachedSrcRect = null;
        }

        String bmpKey = (srcW == sourceWidth) ? KEY_RENDER_BITMAP_SRC : KEY_RENDER_BITMAP;
        Bitmap bmp = (Bitmap) resourceCache.get(bmpKey);
        if (bmp == null || bmp.isRecycled()
                || bmp.getWidth() != srcW || bmp.getHeight() != srcH) {
            if (bmp != null && !bmp.isRecycled()) bmp.recycle();
            bmp = Bitmap.createBitmap(srcW, srcH, Bitmap.Config.ARGB_8888);
            resourceCache.put(bmpKey, bmp);
        }

        // Cero copias extra: wrap() es O(1) y apunta directamente al heap array.
        // Antes había: frameData → allocateDirect → Bitmap (2 copias de ~2MB cada una).
        // Ahora: frameData → Bitmap (1 sola copia vía copyPixelsFromBuffer).
        bmp.copyPixelsFromBuffer(ByteBuffer.wrap(frameData));

        if (cachedDstRect == null
                || cachedDstRect.right != targetWidth
                || cachedDstRect.bottom != targetHeight) {
            cachedDstRect = new android.graphics.Rect(0, 0, targetWidth, targetHeight);
        }
        android.graphics.Rect dstRect = cachedDstRect;

        Canvas canvas = null;
        try {
            canvas = overlayView.getHolder().lockCanvas(null);
            if (canvas == null) return;

            if (fisheyeCorrection != 0) {
                Bitmap stretched;
                if (srcW < targetWidth || srcRect != null) {
                    stretched = Bitmap.createBitmap(targetWidth, targetHeight, Bitmap.Config.ARGB_8888);
                    Canvas tmp = new Canvas(stretched);
                    tmp.drawBitmap(bmp, srcRect, dstRect, bitmapPaint);
                } else {
                    stretched = bmp;
                }
                applyFisheyeCorrection(canvas, stretched);
                if (stretched != bmp) stretched.recycle();
            } else {
                canvas.drawBitmap(bmp, srcRect, dstRect, bitmapPaint);
            }
            lastRenderTime = System.currentTimeMillis();
        } catch (Exception e) {
            Log.e(TAG, "Error render", e);
        } finally {
            if (canvas != null) {
                try { overlayView.getHolder().unlockCanvasAndPost(canvas); }
                catch (Exception e) { Log.e(TAG, "Error unlock canvas", e); }
            }
        }
    }

    // ════════════════════════════════════════════════════════════════════════
    //  Corrección de ojo de pez (malla precalculada)
    // ════════════════════════════════════════════════════════════════════════

    private void invalidateFisheyeCache() {
        lastFisheyeFactor   = Integer.MIN_VALUE;
        fisheyeVerts        = null;
        cachedSrcRect       = null;
        cachedSrcRectSrcW   = -1;
        cachedSrcRectSrcH   = -1;
        cachedSrcRectTop    = Integer.MIN_VALUE;
        cachedSrcRectBottom = Integer.MIN_VALUE;
    }

    /**
     * Aplica distorsión radial (corrección o exageración de efecto ojo de pez).
     * La malla se recalcula solo si cambian el factor o las dimensiones.
     */
    private void applyFisheyeCorrection(Canvas canvas, Bitmap bitmap) {
        if (bitmap == null || bitmap.isRecycled()) return;

        int gridSize = 20;

        if (fisheyeVerts == null
			|| lastFisheyeFactor != fisheyeCorrection
			|| lastFisheyeW     != targetWidth
			|| lastFisheyeH     != targetHeight) {

            int    vertices = (gridSize + 1) * (gridSize + 1);
            fisheyeVerts = new float[vertices * 2];

            float cx     = targetWidth  / 2f;
            float cy     = targetHeight / 2f;
            float maxR   = (float) Math.sqrt(cx * cx + cy * cy);
            float factor = fisheyeCorrection / 100f;

            int idx = 0;
            for (int gy = 0; gy <= gridSize; gy++) {
                for (int gx = 0; gx <= gridSize; gx++) {
                    float gridX = gx * targetWidth  / (float) gridSize;
                    float gridY = gy * targetHeight / (float) gridSize;
                    float dx    = gridX - cx;
                    float dy    = gridY - cy;
                    float dist  = (float) Math.sqrt(dx * dx + dy * dy);

                    if (dist > 0f) {
                        float norm      = dist / maxR;
                        float corrected = norm * (1f + factor * norm * norm) * maxR;
                        float angle     = (float) Math.atan2(dy, dx);
                        fisheyeVerts[idx * 2]     = cx + corrected * (float) Math.cos(angle);
                        fisheyeVerts[idx * 2 + 1] = cy + corrected * (float) Math.sin(angle);
                    } else {
                        fisheyeVerts[idx * 2]     = gridX;
                        fisheyeVerts[idx * 2 + 1] = gridY;
                    }
                    idx++;
                }
            }

            lastFisheyeFactor = fisheyeCorrection;
            lastFisheyeW      = targetWidth;
            lastFisheyeH      = targetHeight;
        }

        canvas.drawBitmapMesh(bitmap, gridSize, gridSize,
							  fisheyeVerts, 0, null, 0, fisheyePaint);
    }

    // ════════════════════════════════════════════════════════════════════════
    //  FpsUpdater
    // ════════════════════════════════════════════════════════════════════════

    // ── Inner classes del pool de render (cero allocaciones por frame) ──────────

    /** Runnable reutilizable para renderToSurfaceOrdered. */
    private final class FrameRenderRunnable implements Runnable {
        volatile byte[] frameData;
        @Override public void run() { renderInternal(frameData); }
    }

    /** Legado — ya no se usa en el camino caliente (releaseProcessingLockOrdered es inmediato).
     *  Mantenido por si algún código externo lo referencia. */
    private final class ReleaseRunnable implements Runnable {
        int expectedTicket;
        @Override public void run() {
            if (lockTicket.get() == expectedTicket) processingBusy = false;
        }
    }

        private final class FpsUpdater implements Runnable {
        @Override
        public void run() {
            if (!running) return;
            long now     = System.currentTimeMillis();
            long elapsed = now - lastFpsUpdate.get();
            if (elapsed >= 1000L) {
                int frames = framesProcessed.getAndSet(0);
                currentFps.set(elapsed > 0 ? (int)(frames * 1000L / elapsed) : 0);
                lastFpsUpdate.set(now);
                updateNotification();
            }
            processingHandler.postDelayed(this, 250);
        }
    }

    // ════════════════════════════════════════════════════════════════════════
    //  Procesadores de frames (inner classes)
    // ════════════════════════════════════════════════════════════════════════

    /**
     * Modo Rendimiento — pipeline mínimo de un solo buffer.
     *
     * <p>Sin upscale CPU. El frame se captura directamente al Bitmap source-size
     * y {@code drawBitmap(src, srcRect, dstRect)} lo escala en GPU mediante
     * hardware acceleration del SurfaceView. Cero bucles por píxel.
     */
    private final class FrameProcessor implements Runnable {
        private final Image image;
        FrameProcessor(Image img) { this.image = img; }

        @Override
        public void run() {
            if (image == null || !running) {
                if (image != null) image.close();
                processingBusy = false;
                return;
            }
            try {
                // ── Lectura zero-copy del ByteBuffer de la imagen ──────────────
                Image.Plane[] planes = image.getPlanes();
                if (planes.length == 0) return;
                ByteBuffer buf       = planes[0].getBuffer();
                int        pixStride = planes[0].getPixelStride();
                int        rowStride = planes[0].getRowStride();
                int        rowPad    = rowStride - pixStride * sourceWidth;

                // Ping-pong de bitmaps: A y B alternados en cada frame.
                // El render usa el bitmap del slot anterior mientras capturamos en el nuevo.
                // Sin esto: copyPixelsFromBuffer sobreescribe el bitmap mientras drawBitmap lo lee.
                String bmpKey = renderSrcSlotA
                    ? KEY_RENDER_BITMAP_SRC
                    : KEY_RENDER_BITMAP_SRC_B;
                renderSrcSlotA = !renderSrcSlotA;

                Bitmap srcBmp = (Bitmap) resourceCache.get(bmpKey);
                if (srcBmp == null || srcBmp.isRecycled()
					|| srcBmp.getWidth() != sourceWidth
					|| srcBmp.getHeight() != sourceHeight) {
                    if (srcBmp != null && !srcBmp.isRecycled()) srcBmp.recycle();
                    srcBmp = Bitmap.createBitmap(sourceWidth, sourceHeight,
													 Bitmap.Config.ARGB_8888);
                    resourceCache.put(bmpKey, srcBmp);
                }

                // Usar byte[] heap (KEY_SOURCE_BUFFER) en lugar de allocateDirect.
                // allocateDirect().array() lanza UnsupportedOperationException en Android
                // → todos los frames se tiraban silenciosamente en modo Rendimiento.
                int needed = sourceWidth * sourceHeight * 4;
                byte[] srcArr = (byte[]) resourceCache.get(KEY_SOURCE_BUFFER);
                if (srcArr == null || srcArr.length < needed) {
                    srcArr = new byte[needed];
                    resourceCache.put(KEY_SOURCE_BUFFER, srcArr);
                }

                buf.rewind();
                if (pixStride == 4 && rowPad == 0) {
                    // Fast path: bulk get directo al array — una sola copia del ByteBuffer
                    buf.get(srcArr, 0, needed);
                } else if (pixStride == 4) {
                    // Con padding de fila: copiar fila a fila
                    int rowBytes = sourceWidth * 4;
                    int offset   = 0;
                    for (int y = 0; y < sourceHeight; y++) {
                        buf.get(srcArr, offset, rowBytes);
                        offset += rowBytes;
                        if (rowPad > 0) buf.position(buf.position() + rowPad);
                    }
                } else {
                    // Slow path: pixStride variable
                    int srcPos = 0, dstPos = 0;
                    for (int y = 0; y < sourceHeight; y++) {
                        for (int x = 0; x < sourceWidth; x++) {
                            srcArr[dstPos]     = buf.get(srcPos);
                            srcArr[dstPos + 1] = buf.get(srcPos + 1);
                            srcArr[dstPos + 2] = buf.get(srcPos + 2);
                            srcArr[dstPos + 3] = buf.get(srcPos + 3);
                            srcPos  += pixStride;
                            dstPos  += 4;
                        }
                        srcPos += rowPad;
                    }
                }
                // wrap() es O(1): apunta al array sin copiar nada extra
                srcBmp.copyPixelsFromBuffer(ByteBuffer.wrap(srcArr, 0, needed));

                // Liberar el lock AQUÍ — el bitmap ya está listo en su slot ping-pong.
                // No necesitamos esperar al render: el siguiente frame usará el otro slot.
                // Esto desacopla captura (60fps) de render (vsync independiente).
                processingBusy = false;

                // ── Render directo: drawBitmap(source→target) = GPU scale ──────
                renderBitmapDirect(srcBmp);
                framesProcessed.incrementAndGet();
                sessionTotalFrames++;

            } catch (Exception e) {
                Log.e(TAG, "Error en FrameProcessor", e);
                droppedFrames.incrementAndGet();
                processingBusy = false;  // liberar también en error
            } finally {
                image.close();
            }
        }
    }

    /**
     * SIFg v1.0 — Predicción ultra-ligera de movimiento.
     *
     * <p>Flujo por frame N:
     * <ol>
     *   <li>Capturar frame N (espacio de captura).</li>
     *   <li>Estimar vector global (dx,dy) entre frame N-1 y N con muestreo
     *       mínimo (4 puntos × 5 candidatos = 20 comparaciones, canal G).</li>
     *   <li>Upscale de frame N al espacio del overlay.</li>
     *   <li>Traducir el frame upscaled por (dx,dy) escalado → frame predicho N+1.</li>
     *   <li>Renderizar el frame predicho (latest-wins → llega a pantalla antes
     *       que el frame real N+1 del juego).</li>
     * </ol>
     *
     * <p>La predicción debe terminar mucho antes de que el siguiente frame del
     * juego esté listo, por eso todo el algoritmo evita floats, bucles pesados
     * y asignaciones de heap por frame.
     */
    private final class SIFgV1Generator implements Runnable {
        private final Image image;
        SIFgV1Generator(Image img) { this.image = img; }

        @Override
        public void run() {
            if (image == null || !running) {
                if (image != null) image.close();
                processingBusy = false;
                return;
            }
            try {
                byte[] src = (byte[]) resourceCache.get(KEY_SOURCE_BUFFER);
                if (src == null) return;

                captureImageToBuffer(image, src);

                // ── Upscale del frame real ──────────────────────────────────
                byte[] upscaled = upscaleNearestNeighbor(src);
                if (upscaled == null) return;

                // ── Predicción ultrarápida de N+1 ───────────────────────────
                byte[] prevSrc = (byte[]) resourceCache.get(KEY_LAST_REAL_FRAME);
                if (prevSrc != null && prevSrc.length == src.length) {

                    // Estimar movimiento (4 puntos, canal G, ±3px) en espacio source
                    int[] motion = estimateMotionUltraLight(prevSrc, src);

                    // Escalar vector a espacio target y suavizar con EMA ligera
                    int rawDx = (int)((float) motion[0] * targetWidth  / sourceWidth);
                    int rawDy = (int)((float) motion[1] * targetHeight / sourceHeight);
                    // EMA: 60% nuevo, 40% historial — más suave que 70/30
                    sifgV10Dx = (rawDx * 6 + sifgV10Dx * 4) / 10;
                    sifgV10Dy = (rawDy * 6 + sifgV10Dy * 4) / 10;

                    if (sifgV10Dx != 0 || sifgV10Dy != 0) {
                        byte[] predicted = (byte[]) resourceCache.get(KEY_PREDICT_FRAME);
                        if (predicted != null && predicted.length == upscaled.length) {
                            translateFrame(upscaled, predicted,
                                           sifgV10Dx, sifgV10Dy,
                                           targetWidth, targetHeight);
                            // Renderizar la predicción — llega a pantalla antes que
                            // el frame real N+1 del juego.
                            renderToSurface(predicted);
                            framesProcessed.incrementAndGet();
                            sessionTotalFrames++;
                        } else {
                            // Fallback: sin buffer — mostrar frame real
                            renderToSurface(upscaled);
                            framesProcessed.incrementAndGet();
                            sessionTotalFrames++;
                        }
                    } else {
                        // Sin movimiento detectado: mostrar frame real directamente
                        renderToSurface(upscaled);
                        framesProcessed.incrementAndGet();
                        sessionTotalFrames++;
                    }
                } else {
                    // Primer frame — sin predicción disponible
                    renderToSurface(upscaled);
                    framesProcessed.incrementAndGet();
                    sessionTotalFrames++;
                }

                // Guardar frame actual como referencia para el siguiente ciclo
                if (prevSrc != null && prevSrc.length == src.length) {
                    System.arraycopy(src, 0, prevSrc, 0, src.length);
                }

            } catch (Exception e) {
                Log.e(TAG, "Error en SIFgV1Generator", e);
                droppedFrames.incrementAndGet();
            } finally {
                image.close();
                processingBusy = false;
            }
        }
    }

    /**
     * SIFg v1.1 — Interpolación pura y ordenada.
     *
     * <p>Principios:
     * <ul>
     *   <li>No se descarta ningún frame real de la app.</li>
     *   <li>Se inserta un frame interpolado (promedio A+B, sin compensación de movimiento)
     *       antes de cada frame real — encolados en FIFO estricto.</li>
     *   <li>Sin estimación de movimiento, sin bilineal, sin floats — solo sumas enteras
     *       (A[i]+B[i])>>1 byte a byte.</li>
     * </ul>
     *
     * <p>Orden de salida por frame N (con N-1 disponible):
     * <pre>
     *   renderToSurfaceOrdered( blend(N-1, N) )   // frame generado
     *   renderToSurfaceOrdered( real N )           // frame real
     * </pre>
     */
    private final class SIFgV1_1Generator implements Runnable {
        private final Image image;
        SIFgV1_1Generator(Image img) { this.image = img; }

        @Override
        public void run() {
            try {
                if (image == null || !running) return;

                byte[] src = (byte[]) resourceCache.get(KEY_SOURCE_BUFFER);
                if (src == null) return;

                captureImageToBuffer(image, src);

                byte[] prevSrc  = (byte[]) resourceCache.get(KEY_LAST_REAL_FRAME);
                Long   prevTime = (Long)   resourceCache.get(KEY_LAST_FRAME_TIME);
                long   now      = System.nanoTime();

                boolean generated = false;

                if (prevSrc != null && prevTime != null
					&& prevSrc.length == src.length
					&& (now - prevTime) <= 50_000_000L) {

                    // Interpolación pura (A+B)/2 — solo aritmética entera, cero floats.
                    // Ping-pong blend: evita que el próximo ciclo sobreescriba el buffer
                    // antes de que renderHandler lo consuma.
                    String blendKey = sifgBlendSlotA ? KEY_EXTRAPOLATION : KEY_EXTRAPOLATION_B;
                    sifgBlendSlotA  = !sifgBlendSlotA;
                    byte[] blend = (byte[]) resourceCache.get(blendKey);
                    if (blend != null && blend.length == src.length) {
                        pureBlendFrames(prevSrc, src, blend);

                        // Upscalear a target-size ANTES de encolar:
                        // drawBitmap 1:1 en software = ~2ms vs escalar 540p→1080p = ~80ms
                        byte[] blendUp = upscaleForOrdered(blend);
                        byte[] srcUp   = upscaleForOrdered(src);

                        if (blendUp != null) {
                            renderToSurfaceOrdered(blendUp);
                            framesProcessed.incrementAndGet();
                            sessionTotalFrames++;
                        }
                        if (srcUp != null) {
                            renderToSurfaceOrdered(srcUp);
                            framesProcessed.incrementAndGet();
                            sessionTotalFrames++;
                        }
                        generated = (blendUp != null || srcUp != null);
                    }
                }

                if (!generated) {
                    byte[] srcUp = upscaleForOrdered(src);
                    if (srcUp != null) {
                        renderToSurfaceOrdered(srcUp);
                        framesProcessed.incrementAndGet();
                        sessionTotalFrames++;
                    }
                }

                // Actualizar referencia del frame anterior para el próximo ciclo
                if (prevSrc != null && prevSrc.length == src.length) {
                    System.arraycopy(src, 0, prevSrc, 0, src.length);
                }
                resourceCache.put(KEY_LAST_FRAME_TIME, now);

            } catch (Exception e) {
                Log.e(TAG, "Error en SIFgV1_1Generator", e);
                droppedFrames.incrementAndGet();
            } finally {
                if (image != null) image.close();
                // releaseProcessingLockOrdered se encola AL FINAL del renderHandler,
                // garantizando que el próximo frame capturado sólo empiece DESPUÉS de
                // que todos los renders encolados hayan terminado.
                // processingBusy = false directo causaba que la cola de renderHandler
                // creciera sin límite (latencia de segundos a los pocos segundos de uso).
                releaseProcessingLockOrdered();
            }
        }
    }

    /**
     * ASIFg: red neuronal liviana + block-matching para estimación de flujo óptico
     * por bloques. Genera un frame sintético interpolado entre el anterior y el actual.
     *
     * <p>La generación ocurre en espacio de <b>baja resolución</b> (sourceWidth×sourceHeight).
     * El upscale al tamaño del overlay lo realiza {@code renderInternal}.
     */
    private final class ASIFgGenerator implements Runnable {
        private final Image image;
        ASIFgGenerator(Image img) { this.image = img; }

        @Override
        public void run() {
            try {
                if (image == null || !running) return;

                // src está en baja resolución
                byte[] src = (byte[]) resourceCache.get(KEY_SOURCE_BUFFER);
                if (src == null) return;

                captureImageToBuffer(image, src);

                byte[] lastReal     = (byte[]) resourceCache.get(KEY_LAST_REAL_FRAME);
                Long   lastRealTime = (Long)   resourceCache.get(KEY_LAST_FRAME_TIME);
                long   now          = System.nanoTime();

                boolean generated = false;
                if (lastReal != null && lastRealTime != null
					&& lastReal.length == src.length
					&& (now - lastRealTime) <= 60_000_000L) {

                    // Todo el flujo ocurre en baja resolución
                    buildFlowField(lastReal, src);
                    asifgLearnCounter++;
                    byte[] synth = buildSyntheticFrame(lastReal, src);

                    if (synth != null) {
                        byte[] synthUp = upscaleForOrdered(synth);
                        byte[] srcUp   = upscaleForOrdered(src);
                        if (synthUp != null) {
                            renderToSurfaceOrdered(synthUp);
                            framesProcessed.incrementAndGet();
                            sessionTotalFrames++;
                        }
                        if (srcUp != null) {
                            renderToSurfaceOrdered(srcUp);
                            framesProcessed.incrementAndGet();
                            sessionTotalFrames++;
                        }
                        generated = (synthUp != null || srcUp != null);
                    }
                }

                if (!generated) {
                    byte[] srcUp = upscaleForOrdered(src);
                    renderToSurface(srcUp != null ? srcUp : copySourceBuffer(src));
                    framesProcessed.incrementAndGet();
                    sessionTotalFrames++;
                }

                if (lastReal != null && lastReal.length == src.length) {
                    System.arraycopy(src, 0, lastReal, 0, src.length);
                }
                resourceCache.put(KEY_LAST_FRAME_TIME, now);

            } catch (Exception e) {
                Log.e(TAG, "Error en ASIFgGenerator", e);
                droppedFrames.incrementAndGet();
            } finally {
                if (image != null) image.close();
                releaseProcessingLockOrdered();
            }
        }

        // ── Campo de flujo (red neuronal + block-matching) — baja resolución ──

        /**
         * SAD rápido de 9 píxeles en la zona central del bloque (canal G).
         * Si está por debajo del umbral, el bloque es estático.
         * 9 comparaciones por bloque — coste prácticamente nulo.
         */
        public static final int STATIC_SAD_THRESHOLD = 9 * 8;   // 8 por píxel promedio

        private void buildFlowField(byte[] frameA, byte[] frameB) {
            int blockW = Math.max(1, sourceWidth  / ASIFG_GRID_COLS);
            int blockH = Math.max(1, sourceHeight / ASIFG_GRID_ROWS);
            int stride = sourceWidth * 4;
            int lenA   = frameA.length;
            int lenB   = frameB.length;

            for (int row = 0; row < ASIFG_GRID_ROWS; row++) {
                for (int col = 0; col < ASIFG_GRID_COLS; col++) {
                    int bIdx = row * ASIFG_GRID_COLS + col;

                    int cx = Math.min(col * blockW + blockW / 2, sourceWidth  - 1);
                    int cy = Math.min(row * blockH + blockH / 2, sourceHeight - 1);

                    // Pre-check rápido 3×3: hoist blockH/3, blockW/3 + ternarios
                    int quickSAD = 0;
                    int bH3 = blockH / 3, bW3 = blockW / 3;
                    int sH1q = sourceHeight - 1, sW1q = sourceWidth - 1;
                    for (int ky = -1; ky <= 1; ky++) {
                        int py = cy + ky * bH3;
                        if (py < 0) py = 0; else if (py > sH1q) py = sH1q;
                        int pyStride = py * stride;
                        for (int kx = -1; kx <= 1; kx++) {
                            int px = cx + kx * bW3;
                            if (px < 0) px = 0; else if (px > sW1q) px = sW1q;
                            int idx = pyStride + px * 4 + 1;
                            if (idx < lenA && idx < lenB) {
                                quickSAD += Math.abs((frameA[idx] & 0xFF) - (frameB[idx] & 0xFF));
                            }
                        }
                    }
                    if (quickSAD < STATIC_SAD_THRESHOLD) {
                        asifgSmoothDx[bIdx] = 0f;
                        asifgSmoothDy[bIdx] = 0f;
                        asifgFlowDx[bIdx]   = 0f;
                        asifgFlowDy[bIdx]   = 0f;
                        continue;
                    }

                    // Block-matching: step=1, range=4 → 9×9 = 81 candidatos.
                    // Con step=3 solo había 9 candidatos: movimiento de 1-2px era invisible.
                    blockMatchLocal(frameA, frameB, cx, cy);
                    float bmDx = asifgRefPatch[0];
                    float bmDy = asifgRefPatch[1];

                    // Clamp al tamaño del bloque (desplazamiento máximo razonable)
                    float maxShift = Math.min(blockW, blockH) * 0.75f;
                    bmDx = Math.max(-maxShift, Math.min(maxShift, bmDx));
                    bmDy = Math.max(-maxShift, Math.min(maxShift, bmDy));

                    // EMA temporal: FLOW_EMA=0.20 → reacciona al movimiento en 1-2 frames
                    float sDx = bmDx * (1f - FLOW_EMA) + asifgSmoothDx[bIdx] * FLOW_EMA;
                    float sDy = bmDy * (1f - FLOW_EMA) + asifgSmoothDy[bIdx] * FLOW_EMA;
                    asifgSmoothDx[bIdx] = sDx;
                    asifgSmoothDy[bIdx] = sDy;
                    asifgFlowDx[bIdx]   = sDx;
                    asifgFlowDy[bIdx]   = sDy;
                }
            }
        }

        /**
        /**
         * Block-matching SAD: step=1, range=4 → 9×9 = 81 candidatos.
         * El step=3 anterior solo probaba 9 candidatos: movimiento de 1-2px era invisible.
         */
        private void blockMatchLocal(byte[] frameA, byte[] frameB, int cx, int cy) {
            final int stride  = sourceWidth * 4;
            final int patchR  = ASIFgNetwork.PATCH / 2;  // 4
            final int searchR = 4;  // 9×9 = 81 candidatos
            final int sH1 = sourceHeight - 1, sW1 = sourceWidth - 1;

            // Patch de referencia: ternarios + fyStride hoisted, sin bounds check extra
            int pi = 2;
            for (int dy = -patchR; dy < patchR; dy++) {
                int fy      = cy + dy;
                if (fy < 0) fy = 0; else if (fy > sH1) fy = sH1;
                int fyStride = fy * stride;
                for (int dx = -patchR; dx < patchR; dx++) {
                    int fx = cx + dx;
                    if (fx < 0) fx = 0; else if (fx > sW1) fx = sW1;
                    asifgRefPatch[pi++] = frameA[fyStride + fx * 4 + 1] & 0xFF;
                }
            }

            int bestSAD = Integer.MAX_VALUE;
            int bestDx  = 0, bestDy = 0;

            outer:
            for (int sdy = -searchR; sdy <= searchR; sdy++) {
                int bcy = cy + sdy;
                for (int sdx = -searchR; sdx <= searchR; sdx++) {
                    int bcx = cx + sdx;
                    int sad = 0;
                    pi = 2;
                    for (int dy = -patchR; dy < patchR; dy++) {
                        int fy = bcy + dy;
                        if (fy < 0) fy = 0; else if (fy > sH1) fy = sH1;
                        int fyStride = fy * stride;  // hoist multiplicación fuera de dx
                        for (int dx = -patchR; dx < patchR; dx++) {
                            int fx = bcx + dx;
                            if (fx < 0) fx = 0; else if (fx > sW1) fx = sW1;
                            // idx garantizado válido por clamp: sin bounds check
                            sad += Math.abs(asifgRefPatch[pi++] - (frameB[fyStride + fx * 4 + 1] & 0xFF));
                        }
                    }
                    if (sad < bestSAD) {
                        bestSAD = sad;
                        bestDx  = sdx;
                        bestDy  = sdy;
                        if (sad == 0) break outer;
                    }
                }
            }

            asifgRefPatch[0] = bestDx;
            asifgRefPatch[1] = bestDy;
        }
        /**
         * Construye el frame sintético en espacio de baja resolución.
         *
         * <p>Optimizaciones sobre la versión original:
         * <ul>
         *   <li>Reemplaza {@code bilinearSample()} (que alojaba {@code new int[3]} POR PÍXEL)
         *       con un lookup entero nearest-neighbor — elimina ~65K allocations por frame.</li>
         *   <li>Blending siempre 50/50 (elimina la ponderación de error adaptativa).</li>
         * </ul>
         */
        /**
         * Construye el frame sintético en espacio de baja resolución.
         *
         * <p>Cambio clave: el vector de flujo se lee con asignación nearest-neighbor
        /**
         * Construye el frame sintético con interpolación bilineal del campo de flujo.
         *
         * En vez de asignar el flujo del bloque más cercano (nearest-neighbor),
         * se interpola bilinealmente entre los 4 centros de bloque vecinos.
         * Esto elimina las fronteras de bloque visibles que causaban los artefactos.
         *
         * Las tablas asifgColIdx/asifgColW y asifgRowIdx/asifgRowW se pre-calculan
         * una sola vez en allocateBuffers — sin divisiones float en el loop interno.
         */
        private byte[] buildSyntheticFrame(byte[] frameA, byte[] frameB) {
            byte[] synth = (byte[]) resourceCache.get(KEY_ASIFG_SYNTH);
            if (synth == null || synth.length != frameB.length) return null;
            if (asifgColIdx == null || asifgRowIdx == null)      return null;

            int stride = sourceWidth * 4;
            int lenA   = frameA.length;
            int lenB   = frameB.length;

            for (int y = 0; y < sourceHeight; y++) {
                // Pesos verticales pre-calculados para esta fila
                int   r0 = asifgRowIdx[y];
                int   r1 = r0 + 1;
                float ty = asifgRowW[y];
                float ity = 1f - ty;

                // Índices base en el array de flujo para las dos filas de bloque
                int baseR0 = r0 * ASIFG_GRID_COLS;
                int baseR1 = r1 * ASIFG_GRID_COLS;

                int rowBase = y * stride;

                final int sW1s = sourceWidth - 1, sH1s = sourceHeight - 1;
                for (int x = 0, dIdx = rowBase; x < sourceWidth; x++, dIdx += 4) {
                    // Pesos horizontales pre-calculados
                    int   c0  = asifgColIdx[x];
                    float tx  = asifgColW[x];
                    float itx = 1f - tx;
                    int   c1  = c0 + 1;

                    // Interpolación bilineal del flujo (4 bloques vecinos)
                    float itxity = itx * ity,  txity = tx * ity;
                    float itxty  = itx * ty,   txty  = tx * ty;
                    float fdx = asifgFlowDx[baseR0 + c0] * itxity
                              + asifgFlowDx[baseR0 + c1] *  txity
                              + asifgFlowDx[baseR1 + c0] * itxty
                              + asifgFlowDx[baseR1 + c1] *  txty;
                    float fdy = asifgFlowDy[baseR0 + c0] * itxity
                              + asifgFlowDy[baseR0 + c1] *  txity
                              + asifgFlowDy[baseR1 + c0] * itxty
                              + asifgFlowDy[baseR1 + c1] *  txty;

                    if (fdx > -0.5f && fdx < 0.5f && fdy > -0.5f && fdy < 0.5f) {
                        // Zona estática: blend 50/50 directo
                        synth[dIdx]     = (byte)(((frameA[dIdx]     & 0xFF) + (frameB[dIdx]     & 0xFF)) >> 1);
                        synth[dIdx + 1] = (byte)(((frameA[dIdx + 1] & 0xFF) + (frameB[dIdx + 1] & 0xFF)) >> 1);
                        synth[dIdx + 2] = (byte)(((frameA[dIdx + 2] & 0xFF) + (frameB[dIdx + 2] & 0xFF)) >> 1);
                        synth[dIdx + 3] = (byte) 255;
                    } else {
                        // Warp bidireccional: ternarios en clamp
                        float hfdx = fdx * 0.5f, hfdy = fdy * 0.5f;
                        int axI = (int)(x - hfdx + 0.5f);
                        int ayI = (int)(y - hfdy + 0.5f);
                        if (axI < 0) axI = 0; else if (axI > sW1s) axI = sW1s;
                        if (ayI < 0) ayI = 0; else if (ayI > sH1s) ayI = sH1s;
                        int aBase = ayI * stride + axI * 4;

                        int bxI = (int)(x + hfdx + 0.5f);
                        int byI = (int)(y + hfdy + 0.5f);
                        if (bxI < 0) bxI = 0; else if (bxI > sW1s) bxI = sW1s;
                        if (byI < 0) byI = 0; else if (byI > sH1s) byI = sH1s;
                        int bBase = byI * stride + bxI * 4;

                        synth[dIdx]     = (byte)(((frameA[aBase]     & 0xFF) + (frameB[bBase]     & 0xFF)) >> 1);
                        synth[dIdx + 1] = (byte)(((frameA[aBase + 1] & 0xFF) + (frameB[bBase + 1] & 0xFF)) >> 1);
                        synth[dIdx + 2] = (byte)(((frameA[aBase + 2] & 0xFF) + (frameB[bBase + 2] & 0xFF)) >> 1);
                        synth[dIdx + 3] = (byte) 255;
                    }
                }
            }
            return synth;
        }
    }

    // ════════════════════════════════════════════════════════════════════════
    //  Render directo de Bitmap (sin upscale CPU — modo Rendimiento)
    // ════════════════════════════════════════════════════════════════════════

    /**
     * Encola el Bitmap para renderizado GPU en el renderThread.
     * "Latest wins": si hay un render pendiente que aún no empezó, se cancela.
     * processingBusy se libera en renderBitmapRunnable (después del render),
     * evitando que el siguiente frame sobreescriba el Bitmap mientras se dibuja.
     */
    private void renderBitmapDirect(final Bitmap srcBmp) {
        if (srcBmp == null) return;
        pendingRenderBitmap = srcBmp;
        renderHandler.removeCallbacks(renderBitmapRunnable);
        renderHandler.post(renderBitmapRunnable);
    }

    // ════════════════════════════════════════════════════════════════════════
    //  Modo GPU — GpuFrameProcessor
    // ════════════════════════════════════════════════════════════════════════

    /**
     * Procesador GPU: captura → RenderScript resize → interpolación/blend RS → render.
     *
     * <p>Pipeline:
     * <ol>
     *   <li>Copiar ByteBuffer de imagen a {@code Allocation} RS source-size.</li>
     *   <li>{@link ScriptIntrinsicResize} source→target en GPU.</li>
     *   <li>Si hay frame anterior: blend 50/50 CPU → frame sintético.</li>
     *   <li>Render FIFO: blend primero, real después.</li>
     * </ol>
     *
     * <p>Toda la interpolación ocurre en el shader RS, no en la CPU Java.
     * El único trabajo CPU es la copia inicial del ByteBuffer (inevitable).
     */
    private final class GpuFrameProcessor implements Runnable {
        private final Image image;
        GpuFrameProcessor(Image img) { this.image = img; }

        @Override
        public void run() {
            if (image == null || !running || rsPipeline == null
				|| !rsPipeline.isReady()) {
                // Fallback a CPU si RS no está listo
                if (image != null) {
                    byte[] src = (byte[]) resourceCache.get(KEY_SOURCE_BUFFER);
                    if (src != null) {
                        captureImageToBuffer(image, src);
                        byte[] up = upscaleNearestNeighbor(src);
                        if (up != null) renderToSurface(up);
                    }
                    image.close();
                }
                processingBusy = false;
                return;
            }
            try {
                // ── Leer imagen al Allocation source RS ───────────────────────
                Image.Plane[] planes = image.getPlanes();
                if (planes.length == 0) return;
                ByteBuffer buf       = planes[0].getBuffer();
                int        pixStride = planes[0].getPixelStride();
                int        rowStride = planes[0].getRowStride();
                buf.rewind();

                // Copiar al buffer intermedio (source-size)
                byte[] src = (byte[]) resourceCache.get(KEY_SOURCE_BUFFER);
                if (src == null) return;
                if (pixStride == 4 && (rowStride == sourceWidth * 4)) {
                    buf.get(src, 0, src.length);
                } else {
                    captureImageToBuffer(image, src);
                }

                // ── Pipeline RS ────────────────────────────────────────────────
                // 1. Upload source → Resize GPU (source→target bilineal)
                rsPipeline.uploadSource(src);
                rsPipeline.resize();

                // 2. Descargar frame real escalado por GPU (ping-pong: cero copias extra)
                byte[] real = rsPipeline.downloadTargetPing();
                if (real == null) return;

                // 3. Blend 50/50 CPU con frame anterior (pureBlendFrames es ~2ms a 1080p)
                //    forEachDstOver de RS era incorrecto: con alpha=255 devuelve solo dst,
                //    nunca generaba un blend real — causaba el frame congelado.
                byte[] prevReal = rsPipeline.getPreviousBytes();
                if (prevReal != null) {
                    byte[] blendBuf = rsPipeline.getBlendBuffer();
                    if (blendBuf != null) {
                        pureBlendFrames(prevReal, real, blendBuf);
                        // Ping-pong de copia del blend: evita new byte[] por frame (~4 MB/s)
                        String bKey = gpuBlendSlotA ? KEY_GPU_BLEND_COPY_A : KEY_GPU_BLEND_COPY_B;
                        gpuBlendSlotA = !gpuBlendSlotA;
                        byte[] blendCopy = (byte[]) resourceCache.get(bKey);
                        if (blendCopy == null || blendCopy.length != blendBuf.length) {
                            blendCopy = new byte[blendBuf.length];
                            resourceCache.put(bKey, blendCopy);
                        }
                        System.arraycopy(blendBuf, 0, blendCopy, 0, blendBuf.length);
                        renderToSurfaceOrdered(blendCopy);
                        framesProcessed.incrementAndGet();
                        sessionTotalFrames++;
                    }
                }

                // 4. Guardar frame actual y renderizar
                rsPipeline.savePreviousBytes(real);
                renderToSurfaceOrdered(real);
                framesProcessed.incrementAndGet();
                sessionTotalFrames++;

            } catch (Exception e) {
                Log.e(TAG, "Error GpuFrameProcessor", e);
                droppedFrames.incrementAndGet();
            } finally {
                image.close();
                releaseProcessingLockOrdered();
            }
        }
    }

    // ════════════════════════════════════════════════════════════════════════
    //  ASIFg GPU — ASIFgGpuProcessor
    // ════════════════════════════════════════════════════════════════════════

    /**
     * ASIFg con aceleración GPU (MODE_ASIFG_GPU).
     *
     * <p>Pipeline híbrido:
     * <ol>
     *   <li>Captura a buffer CPU source-size (inevitable — ImageReader entrega bytes).</li>
     *   <li>Estimación de flujo por bloques en CPU (ASIFgNetwork + block-matching)
     *       — la red ya es muy pequeña; el cuello de botella real es el warp de píxeles.</li>
     *   <li><b>Síntesis del frame interpolado en GPU vía RenderScript:</b>
     *       se sube el campo de flujo como un array de deltas, y RS realiza el warp
     *       bilineal + blend 50/50 sin bucles Java por píxel.</li>
     *   <li>Frame real escalado por RS (resize bilineal GPU).</li>
     *   <li>Render FIFO: sintético → real.</li>
     * </ol>
     *
     * <p>Si RS no está listo, hace fallback automático al procesador CPU ASIFgGenerator.
     */
    private final class ASIFgGpuProcessor implements Runnable {
        private final Image image;
        ASIFgGpuProcessor(Image img) { this.image = img; }

        @Override
        public void run() {
            // Fallback a CPU si RS no disponible
            if (rsPipeline == null || !rsPipeline.isReady()) {
                new ASIFgGenerator(image).run();
                return;
            }
            try {
                if (image == null || !running) return;

                byte[] src = (byte[]) resourceCache.get(KEY_SOURCE_BUFFER);
                if (src == null) return;

                captureImageToBuffer(image, src);

                byte[] lastReal     = (byte[]) resourceCache.get(KEY_LAST_REAL_FRAME);
                Long   lastRealTime = (Long)   resourceCache.get(KEY_LAST_FRAME_TIME);
                long   now          = System.nanoTime();

                // ── 1. Subir frame actual a RS (resize source→target en GPU) ──
                rsPipeline.uploadSource(src);
                rsPipeline.resize();  // allocTarget = bilineal GPU upscale

                boolean generated = false;

                if (lastReal != null && lastRealTime != null
                    && lastReal.length == src.length
                    && (now - lastRealTime) <= 60_000_000L) {

                    // ── 2. Estimar flujo en CPU (red neuronal + BM) ───────────
                    // El campo de flujo queda en asifgFlowDx/asifgFlowDy (source-space)
                    buildAsifgFlowField(lastReal, src);
                    asifgLearnCounter++;

                    // ── 3. Blend CPU con frame anterior
                    byte[] prevReal = rsPipeline.getPreviousBytes();
                    if (prevReal != null) {
                        // downloadTarget hace copyTo(targetOut) — llamar ANTES del blend
                        // para tener los bytes del frame actual en targetOut/peekTargetBytes
                        byte[] real2 = rsPipeline.downloadTargetPing();
                        byte[] blendBuf = rsPipeline.getBlendBuffer();
                        if (real2 != null && blendBuf != null) {
                            pureBlendFrames(prevReal, real2, blendBuf);
                            // Ping-pong copia blend GPU: sin new byte[] por frame
                            String bKey = gpuBlendSlotA ? KEY_GPU_BLEND_COPY_A : KEY_GPU_BLEND_COPY_B;
                            gpuBlendSlotA = !gpuBlendSlotA;
                            byte[] blendCopy = (byte[]) resourceCache.get(bKey);
                            if (blendCopy == null || blendCopy.length != blendBuf.length) {
                                blendCopy = new byte[blendBuf.length];
                                resourceCache.put(bKey, blendCopy);
                            }
                            System.arraycopy(blendBuf, 0, blendCopy, 0, blendBuf.length);
                            renderToSurfaceOrdered(blendCopy);
                            framesProcessed.incrementAndGet();
                            sessionTotalFrames++;
                            generated = true;
                            // Frame real ya descargado — guardarlo y renderizar
                            rsPipeline.savePreviousBytes(real2);
                            renderToSurfaceOrdered(real2);
                            framesProcessed.incrementAndGet();
                            sessionTotalFrames++;
                        }
                    }
                }

                // ── 4. Frame real (solo si no fue renderizado ya arriba) ──────
                if (!generated) {
                    byte[] real = rsPipeline.downloadTargetPing();
                    if (real != null) {
                        rsPipeline.savePreviousBytes(real);
                        renderToSurfaceOrdered(real);
                        framesProcessed.incrementAndGet();
                        sessionTotalFrames++;
                    } else {
                        byte[] srcUp = upscaleForOrdered(src);
                        renderToSurface(srcUp != null ? srcUp : copySourceBuffer(src));
                        framesProcessed.incrementAndGet();
                        sessionTotalFrames++;
                    }
                }

                if (lastReal != null && lastReal.length == src.length) {
                    System.arraycopy(src, 0, lastReal, 0, src.length);
                }
                resourceCache.put(KEY_LAST_FRAME_TIME, now);

            } catch (Exception e) {
                Log.e(TAG, "Error ASIFgGpuProcessor", e);
                droppedFrames.incrementAndGet();
            } finally {
                if (image != null) image.close();
                releaseProcessingLockOrdered();
            }
        }

        /**
         * Igual que ASIFgGenerator.buildFlowField: BM puro sin NN, step=1, range=4.
         */
        private void buildAsifgFlowField(byte[] frameA, byte[] frameB) {
			int blockW = Math.max(1, sourceWidth  / ASIFG_GRID_COLS);
			int blockH = Math.max(1, sourceHeight / ASIFG_GRID_ROWS);
			int stride = sourceWidth * 4;
			int lenA   = frameA.length;
			int lenB   = frameB.length;
			int patchR = ASIFgNetwork.PATCH / 2;
			int searchR = 4;

			for (int row = 0; row < ASIFG_GRID_ROWS; row++) {
				for (int col = 0; col < ASIFG_GRID_COLS; col++) {
					int bIdx = row * ASIFG_GRID_COLS + col;
					int cx = Math.min(col * blockW + blockW / 2, sourceWidth  - 1);
					int cy = Math.min(row * blockH + blockH / 2, sourceHeight - 1);

					// quickSAD pre-check: hoist divisiones, ternarios, pyStride
					int quickSAD = 0;
					final int STATIC_SAD_THRESHOLD = 9 * 8;
					int bH3gpu = blockH / 3, bW3gpu = blockW / 3;
					int sH1gpu = sourceHeight - 1, sW1gpu = sourceWidth - 1;
					for (int kygpu = -1; kygpu <= 1; kygpu++) {
						int py = cy + kygpu * bH3gpu;
						if (py < 0) py = 0; else if (py > sH1gpu) py = sH1gpu;
						int pyStride = py * stride;
						for (int kxgpu = -1; kxgpu <= 1; kxgpu++) {
							int px = cx + kxgpu * bW3gpu;
							if (px < 0) px = 0; else if (px > sW1gpu) px = sW1gpu;
							int idx = pyStride + px * 4 + 1;
							if (idx < lenA && idx < lenB)
								quickSAD += Math.abs((frameA[idx] & 0xFF) - (frameB[idx] & 0xFF));
						}
					}
					if (quickSAD < STATIC_SAD_THRESHOLD)
					{
						asifgSmoothDx[bIdx] = 0f; asifgSmoothDy[bIdx] = 0f;
						asifgFlowDx[bIdx]   = 0f; asifgFlowDy[bIdx]   = 0f;
						continue;
					}

                    // Block-matching: hoist fy*stride + ternarios + sin idx bounds check
                    final int sH1g = sourceHeight - 1, sW1g = sourceWidth - 1;
                    int pi = 2;
                    for (int dy = -patchR; dy < patchR; dy++) {
                        int fy = cy + dy;
                        if (fy < 0) fy = 0; else if (fy > sH1g) fy = sH1g;
                        int fyStride = fy * stride;
                        for (int dx = -patchR; dx < patchR; dx++) {
                            int fx = cx + dx;
                            if (fx < 0) fx = 0; else if (fx > sW1g) fx = sW1g;
                            asifgRefPatch[pi++] = frameA[fyStride + fx * 4 + 1] & 0xFF;
                        }
                    }
                    int bestSAD = Integer.MAX_VALUE, bestDx = 0, bestDy = 0;
                    outer:
                    for (int sdy = -searchR; sdy <= searchR; sdy++) {
                        int bcy = cy + sdy;
                        for (int sdx = -searchR; sdx <= searchR; sdx++) {
                            int sad = 0; pi = 2;
                            int bcx = cx + sdx;
                            for (int dy = -patchR; dy < patchR; dy++) {
                                int fy = bcy + dy;
                                if (fy < 0) fy = 0; else if (fy > sH1g) fy = sH1g;
                                int fyStride = fy * stride;
                                for (int dx = -patchR; dx < patchR; dx++) {
                                    int fx = bcx + dx;
                                    if (fx < 0) fx = 0; else if (fx > sW1g) fx = sW1g;
                                    sad += Math.abs(asifgRefPatch[pi++] - (frameB[fyStride + fx * 4 + 1] & 0xFF));
                                }
                            }
                            if (sad < bestSAD) { bestSAD = sad; bestDx = sdx; bestDy = sdy; }
                            if (bestSAD == 0) break outer;
                        }
                    }

                    float bmDx = bestDx, bmDy = bestDy;
                    float maxSh = Math.min(blockW, blockH) * 0.75f;
                    bmDx = Math.max(-maxSh, Math.min(maxSh, bmDx));
                    bmDy = Math.max(-maxSh, Math.min(maxSh, bmDy));
                    float sDx = bmDx * (1f - FLOW_EMA) + asifgSmoothDx[bIdx] * FLOW_EMA;
                    float sDy = bmDy * (1f - FLOW_EMA) + asifgSmoothDy[bIdx] * FLOW_EMA;
                    asifgSmoothDx[bIdx] = sDx; asifgSmoothDy[bIdx] = sDy;
                    asifgFlowDx[bIdx]   = sDx; asifgFlowDy[bIdx]   = sDy;
                }
            }
        }
    }

    /**
     * Encapsula todos los objetos RenderScript del pipeline GPU.
     *
     * <p>Operaciones disponibles:
     * <ul>
     *   <li>{@link #resize()} — ScriptIntrinsicResize source(srcW×srcH)→target(tgtW×tgtH)</li>
     *   <li>{@link #downloadTarget()} — descargar target Allocation a byte[]</li>
     *   <li>{@link #getPreviousBytes()} / {@link #savePreviousBytes} — blend 50/50 CPU</li>
     * </ul>
     *
     * <p>Lifecycle: {@link #init} → usar → {@link #destroy}.
     * Thread-safe para init/destroy; las operaciones de pipeline deben llamarse
     * desde un único hilo (processingThread).
     */
    private static final class RenderScriptPipeline {
        private final Context         ctx;
        private RenderScript          rs;
        private ScriptIntrinsicResize rsResize;
        private Allocation            allocSrc;     // source: srcW×srcH RGBA
        private Allocation            allocTarget;  // target: tgtW×tgtH RGBA (resultado resize)
        private byte[]                targetOut;    // buffer de descarga (reutilizable)
        private byte[]                targetPingA;  // ping-pong A para downloadTargetInto
        private byte[]                targetPingB;  // ping-pong B
        private boolean               pingSlotA = true;
        private byte[]                prevBytes;    // frame anterior target-size para blend CPU
        private byte[]                blendBuffer;  // buffer de blend reutilizable
        private boolean               ready   = false;
        private int srcW, srcH, tgtW, tgtH;

        RenderScriptPipeline(Context ctx) { this.ctx = ctx; }

        synchronized void init(int sw, int sh, int tw, int th) {
            destroy();
            this.srcW = sw; this.srcH = sh;
            this.tgtW = tw; this.tgtH = th;
            try {
                rs = RenderScript.create(ctx);

                Type typeSrc = new Type.Builder(rs, Element.RGBA_8888(rs))
                    .setX(sw).setY(sh).create();
                Type typeTgt = new Type.Builder(rs, Element.RGBA_8888(rs))
                    .setX(tw).setY(th).create();

                allocSrc    = Allocation.createTyped(rs, typeSrc, Allocation.USAGE_SCRIPT);
                allocTarget = Allocation.createTyped(rs, typeTgt, Allocation.USAGE_SCRIPT);

                rsResize = ScriptIntrinsicResize.create(rs);
                rsResize.setInput(allocSrc);

                int tSize   = tw * th * 4;
                targetOut   = new byte[tSize];
                targetPingA = new byte[tSize];
                targetPingB = new byte[tSize];
                pingSlotA   = true;
                prevBytes   = null;   // se asigna en savePreviousBytes
                blendBuffer = new byte[tSize];
                ready       = true;
                Log.i("RenderScriptPipeline", "RS init OK " + sw + "x" + sh
                      + " -> " + tw + "x" + th);
            } catch (Exception e) {
                Log.e("RenderScriptPipeline", "RS init FAILED: " + e.getMessage());
                destroy();
            }
        }

        synchronized void destroy() {
            ready     = false;
            prevBytes   = null;
            targetPingA = null;
            targetPingB = null;
            safeDestroy(rsResize);    rsResize    = null;
            safeDestroy(allocSrc);    allocSrc    = null;
            safeDestroy(allocTarget); allocTarget = null;
            if (rs != null) { try { rs.destroy(); } catch (Exception ignored) {} rs = null; }
            targetOut   = null;
            blendBuffer = null;
        }

        boolean isReady() { return ready; }

        /** Retorna el frame anterior (target-size) para blend CPU, o null si no hay. */
        byte[] getPreviousBytes() { return prevBytes; }

        void uploadSource(byte[] src) {
            if (!ready) return;
            allocSrc.copyFrom(src);
        }

        /** Resize bilineal GPU: allocSrc(srcW×srcH) → allocTarget(tgtW×tgtH). */
        void resize() {
            if (!ready) return;
            rsResize.forEach_bicubic(allocTarget);
        }

        /**
         * Descarga allocTarget a una copia nueva de byte[].
         * Cada llamada devuelve un array independiente — seguro para encolar en renderHandler.
         */
        byte[] downloadTarget() {
            if (!ready || targetOut == null) return null;
            allocTarget.copyTo(targetOut);
            byte[] copy = new byte[targetOut.length];
            System.arraycopy(targetOut, 0, copy, 0, targetOut.length);
            return copy;
        }

        /**
         * Descarga allocTarget directamente en {@code dest} (sin copia extra).
         * El caller es responsable de que {@code dest.length == tgtW*tgtH*4}.
         * Usar cuando el caller ya gestiona el buffer con ping-pong propio.
         */
        boolean downloadTargetInto(byte[] dest) {
            if (!ready || dest == null) return false;
            try {
                allocTarget.copyTo(dest);
                return true;
            } catch (Exception e) { return false; }
        }

        /**
         * Descarga allocTarget en un slot ping-pong interno.
         * Retorna el buffer llenado; el próximo frame usará el otro slot.
         * Cero copias extra — reemplaza downloadTarget() en todos los casos.
         */
        byte[] downloadTargetPing() {
            if (!ready) return null;
            byte[] slot = pingSlotA ? targetPingA : targetPingB;
            pingSlotA = !pingSlotA;
            if (slot == null) return null;
            allocTarget.copyTo(slot);
            return slot;
        }

        /**
         * Buffer de blend reutilizable (target-size).
         * El caller llena este buffer con pureBlendFrames y lo encola en renderHandler.
         * El buffer es fijo — no asignar uno nuevo por frame.
         * IMPORTANTE: el caller debe encolar una COPIA si hay riesgo de sobreescritura.
         */
        byte[] getBlendBuffer() { return blendBuffer; }

        /**
         * Lee los bytes actuales de allocTarget SIN hacer una copia extra.
         * Usar solo dentro del mismo ciclo de procesamiento, antes de la próxima llamada a resize().
         */
        byte[] peekTargetBytes() { return targetOut; }

        /**
         * Guarda {@code real} como frame anterior para el próximo ciclo.
         * Copia los bytes para que el caller pueda reutilizar su buffer.
         */
        void savePreviousBytes(byte[] real) {
            if (real == null) return;
            if (prevBytes == null || prevBytes.length != real.length) {
                prevBytes = new byte[real.length];
            }
            System.arraycopy(real, 0, prevBytes, 0, real.length);
        }

        private static void safeDestroy(Object o) {
            if (o == null) return;
            try {
                if (o instanceof Allocation)
                    ((Allocation) o).destroy();
                else if (o instanceof ScriptIntrinsicResize)
                    ((ScriptIntrinsicResize) o).destroy();
            } catch (Exception ignored) {}
        }
    }

    // ════════════════════════════════════════════════════════════════════════
    //  Persistencia de estadísticas de sesión
    // ════════════════════════════════════════════════════════════════════════

    private void saveStats() {
        if (sessionTotalFrames == 0 || sessionStartTime == 0) return;
        long elapsed = System.currentTimeMillis() - sessionStartTime;
        if (elapsed <= 0) return;

        int avgFps = (int)(sessionTotalFrames * 1000L / elapsed);
        String key;
        if (currentMode == MODE_PERFORMANCE) key = PREF_AVG_FPS_PERFORMANCE;
        else if (currentMode == MODE_ASIFG)  key = PREF_AVG_FPS_ASIFG;
        else                                 key = PREF_AVG_FPS_SIFG1;

        int old = prefs.getInt(key, 0);
        prefs.edit().putInt(key, old == 0 ? avgFps : (old + avgFps) / 2).apply();
    }
}






