package com.TurungSoftware.FrameGenerator;

import android.accessibilityservice.*;
import android.app.*;
import android.content.*;
import android.content.res.*;
import android.graphics.*;
import android.hardware.display.*;
import android.media.*;
import android.media.projection.*;
import android.os.*;
import android.provider.*;
import android.util.*;
import android.view.*;
import android.view.accessibility.*;
import android.widget.*;
import java.nio.*;
import java.util.*;
import java.util.concurrent.atomic.*;

import android.os.Process;

public class ScreenScaler extends Activity {
    private static final int REQUESTCODECAPTURE = 1001;
    private static final int REQUESTCODEACCESSIBILITY = 1002;
    private static final int REQUESTCODEOVERLAY = 1003;
    private static final String TAG = "ScreenScaler";

    private MediaProjectionManager mpManager;
    private volatile boolean isCapturing = false;
    private LinearLayout controlPanel;
    private TextView statusText;
    private TextView fpsCounter;
    private TextView resolutionText;
    private TextView statsText;
    private TextView sifgInfoText;
    private TextView generationInfoText;
    private Button btnPerformanceMode;
    private Button btnSIFgMode;
    private Button btnResolutionConfig;
    private Button btnFrameGenerationConfig;
    private Button btnColorQualityConfig;
    private Button btnFisheyeCorrection;
    private Button btnStartStop;
    private int targetWidth, targetHeight, sourceWidth, sourceHeight, screenDensityDpi, topInset, bottomInset;
    private float resolutionScale = 0.5f;
    private int framesToGenerate = 1;
    private int colorQuality = 0;
    private int fisheyeCorrection = 0;
    private static final int MODEPERFORMANCE = 0;
    private static final int MODESIFG1 = 1;
    private AtomicInteger currentMode = new AtomicInteger(MODEPERFORMANCE);
    private int sifgVersion = 0;
    private ScreenCaptureService captureService;
    private boolean serviceBound = false;
    private Intent resultData;
    private int resultCode;
    private SharedPreferences prefs;
    private BatteryReceiver batteryReceiver;
    private final ServiceConnection serviceConnection = new ServiceConnection() {
        public void onServiceConnected(ComponentName name, IBinder service) {
            captureService = ((ScreenCaptureService.LocalBinder) service).getService();
            captureService.setMode(currentMode.get());
            captureService.setSifgVersion(sifgVersion);
            captureService.setResolutionScale(resolutionScale);
            captureService.setFramesToGenerate(framesToGenerate);
            captureService.setColorQuality(colorQuality);
            captureService.setFisheyeCorrection(fisheyeCorrection);
            serviceBound = true;
            if (resultData != null && resultCode == RESULT_OK) startCaptureInternal();
        }

        public void onServiceDisconnected(ComponentName name) {
            serviceBound = false;
            captureService = null;
        }
    };
    private final Handler fpsHandler = new Handler();
    private final Runnable fpsRunnable = new Runnable() {
        public void run() {
            if (captureService != null && isCapturing) {
                int fps = captureService.getFps();
                int frames = captureService.getTotalFrames();
                int dropped = captureService.getDroppedFrames();
                fpsCounter.setText("FPS: " + fps + " | Frames: " + frames + " | Perdidos: " + dropped);
            }
            fpsHandler.postDelayed(this, 1000);
        }
    };

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        prefs = getSharedPreferences("ScreenScalerStats", MODE_PRIVATE);

        DisplayMetrics metrics = new DisplayMetrics();
        getWindowManager().getDefaultDisplay().getRealMetrics(metrics);
        screenDensityDpi = metrics.densityDpi;

        if (Build.VERSION.SDK_INT >= 28) {
            getWindow().getDecorView().setOnApplyWindowInsetsListener(new View.OnApplyWindowInsetsListener() {
					public WindowInsets onApplyWindowInsets(View v, WindowInsets insets) {
						DisplayCutout cutout = insets.getDisplayCutout();
						if (cutout != null) {
							topInset = cutout.getSafeInsetTop();
							bottomInset = cutout.getSafeInsetBottom();
						}
						return insets;
					}
				});
        }

        resolutionScale = prefs.getFloat("resolution_scale", 0.5f);
        framesToGenerate = prefs.getInt("frames_to_generate", 1);
        colorQuality = prefs.getInt("color_quality", 0);
        fisheyeCorrection = prefs.getInt("fisheye_correction", 0);
        sifgVersion = prefs.getInt("sifg_version", 0);
        adjustResolutions(metrics);
        createUI();
        loadStats();

        mpManager = (MediaProjectionManager) getSystemService(Context.MEDIA_PROJECTION_SERVICE);

        Intent serviceIntent = new Intent(this, ScreenCaptureService.class);
        if (Build.VERSION.SDK_INT >= 26) startForegroundService(serviceIntent);
        else startService(serviceIntent);
        bindService(serviceIntent, serviceConnection, Context.BIND_AUTO_CREATE);

        batteryReceiver = new BatteryReceiver();
        registerReceiver(batteryReceiver, new IntentFilter(Intent.ACTION_BATTERY_CHANGED));
    }

    private void adjustResolutions(DisplayMetrics metrics) {
        targetWidth = (metrics.widthPixels / 8) * 8;
        targetHeight = (metrics.heightPixels / 8) * 8;
        sourceWidth = Math.max(8, (int) (targetWidth * resolutionScale) / 8 * 8);
        sourceHeight = Math.max(8, (int) (targetHeight * resolutionScale) / 8 * 8);
        Log.d(TAG, "Resoluciones: Fuente=" + sourceWidth + "x" + sourceHeight + ", Destino=" + targetWidth + "x" + targetHeight);
    }

    private void createUI() {
        LinearLayout mainLayout = new LinearLayout(this);
        mainLayout.setOrientation(LinearLayout.VERTICAL);
        mainLayout.setLayoutParams(new LinearLayout.LayoutParams(-1, -1));
        mainLayout.setPadding(16, 16, 16, 16);
        mainLayout.setBackgroundColor(Color.BLACK);

        controlPanel = new LinearLayout(this);
        controlPanel.setOrientation(LinearLayout.VERTICAL);
        controlPanel.setLayoutParams(new LinearLayout.LayoutParams(-1, -2));
        controlPanel.setBackgroundColor(Color.rgb(32, 32, 32));
        controlPanel.setPadding(12, 12, 12, 12);

        TextView title = new TextView(this);
        title.setText("Frame Generator Pro v1.0");
        title.setTextSize(22);
        title.setTextColor(Color.WHITE);
        title.setGravity(Gravity.CENTER);
        title.setPadding(0, 0, 0, 16);
        controlPanel.addView(title);

        resolutionText = new TextView(this);
        updateResolutionText();
        resolutionText.setTextSize(12);
        resolutionText.setTextColor(Color.LTGRAY);
        resolutionText.setGravity(Gravity.CENTER);
        resolutionText.setPadding(0, 0, 0, 12);
        controlPanel.addView(resolutionText);

        LinearLayout modeLayout = new LinearLayout(this);
        modeLayout.setOrientation(LinearLayout.HORIZONTAL);
        modeLayout.setLayoutParams(new LinearLayout.LayoutParams(-1, -2));

        btnPerformanceMode = createModeButton("Rendimiento", MODEPERFORMANCE);
        btnSIFgMode = createModeButton("SIFg", MODESIFG1);

        modeLayout.addView(btnPerformanceMode);
        modeLayout.addView(btnSIFgMode);
        controlPanel.addView(modeLayout);

        LinearLayout configLayout = new LinearLayout(this);
        configLayout.setOrientation(LinearLayout.HORIZONTAL);
        configLayout.setLayoutParams(new LinearLayout.LayoutParams(-1, -2));
        configLayout.setPadding(0, 8, 0, 0);

        btnFrameGenerationConfig = createConfigButton("Gen: " + framesToGenerate, new View.OnClickListener() {
				public void onClick(View v) {
					showFrameGenerationDialog();
				}
			});
        btnColorQualityConfig = createConfigButton(getColorQualityText(), new View.OnClickListener() {
				public void onClick(View v) {
					showColorQualityDialog();
				}
			});
        btnResolutionConfig = createResolutionButton();
        btnFisheyeCorrection = createFisheyeButton();

        configLayout.addView(btnFrameGenerationConfig);
        configLayout.addView(btnColorQualityConfig);
        configLayout.addView(btnResolutionConfig);
        configLayout.addView(btnFisheyeCorrection);
        controlPanel.addView(configLayout);

        btnStartStop = new Button(this);
        btnStartStop.setText("INICIAR CAPTURA");
        btnStartStop.setTextSize(16);
        btnStartStop.setBackgroundColor(Color.rgb(0, 120, 215));
        btnStartStop.setTextColor(Color.WHITE);
        btnStartStop.setLayoutParams(new LinearLayout.LayoutParams(-1, -2));
        ((LinearLayout.LayoutParams) btnStartStop.getLayoutParams()).setMargins(0, 12, 0, 0);
        btnStartStop.setOnClickListener(new View.OnClickListener() {
				public void onClick(View v) {
					if (!isCapturing) startCapture();
					else stopCapture();
				}
			});
        controlPanel.addView(btnStartStop);

        LinearLayout statsLayout = new LinearLayout(this);
        statsLayout.setOrientation(LinearLayout.VERTICAL);
        statsLayout.setLayoutParams(new LinearLayout.LayoutParams(-1, -2));
        statsLayout.setPadding(0, 12, 0, 0);

        statusText = new TextView(this);
        statusText.setText("Modo: Rendimiento");
        statusText.setTextSize(14);
        statusText.setTextColor(Color.WHITE);
        statusText.setLayoutParams(new LinearLayout.LayoutParams(-1, -2));
        statsLayout.addView(statusText);

        sifgInfoText = new TextView(this);
        sifgInfoText.setText("");
        sifgInfoText.setTextSize(11);
        sifgInfoText.setTextColor(Color.CYAN);
        sifgInfoText.setLayoutParams(new LinearLayout.LayoutParams(-1, -2));
        statsLayout.addView(sifgInfoText);

        generationInfoText = new TextView(this);
        generationInfoText.setText("Frames generados: " + framesToGenerate + " | Calidad: " + getColorQualityText());
        generationInfoText.setTextSize(10);
        generationInfoText.setTextColor(Color.LTGRAY);
        generationInfoText.setLayoutParams(new LinearLayout.LayoutParams(-1, -2));
        statsLayout.addView(generationInfoText);

        fpsCounter = new TextView(this);
        fpsCounter.setText("FPS: 0 | Frames: 0 | Perdidos: 0");
        fpsCounter.setTextSize(12);
        fpsCounter.setTextColor(Color.LTGRAY);
        fpsCounter.setLayoutParams(new LinearLayout.LayoutParams(-1, -2));
        statsLayout.addView(fpsCounter);

        statsText = new TextView(this);
        statsText.setText("");
        statsText.setTextSize(11);
        statsText.setTextColor(Color.YELLOW);
        statsText.setLayoutParams(new LinearLayout.LayoutParams(-1, -2));
        statsLayout.addView(statsText);

        controlPanel.addView(statsLayout);
        mainLayout.addView(controlPanel);
        setContentView(mainLayout);
        setMode(MODEPERFORMANCE);
    }

    private Button createResolutionButton() {
        Button btn = new Button(this);
        btn.setText("Res: " + (int) (resolutionScale * 100) + "%");
        btn.setTextSize(12);
        btn.setLayoutParams(new LinearLayout.LayoutParams(0, -2, 1));
        ((LinearLayout.LayoutParams) btn.getLayoutParams()).setMargins(4, 0, 4, 0);
        btn.setOnClickListener(new View.OnClickListener() {
				public void onClick(View v) {
					showResolutionDialog();
				}
			});
        return btn;
    }

    private Button createFisheyeButton() {
        Button btn = new Button(this);
        btn.setText("FishEye: " + fisheyeCorrection);
        btn.setTextSize(11);
        btn.setLayoutParams(new LinearLayout.LayoutParams(0, -2, 1));
        ((LinearLayout.LayoutParams) btn.getLayoutParams()).setMargins(4, 0, 4, 0);
        btn.setOnClickListener(new View.OnClickListener() {
				public void onClick(View v) {
					showFisheyeDialog();
				}
			});
        return btn;
    }

    private Button createModeButton(final String text, final int mode) {
        Button btn = new Button(this);
        btn.setText(text);
        btn.setTextSize(12);
        btn.setLayoutParams(new LinearLayout.LayoutParams(0, -2, 1));
        ((LinearLayout.LayoutParams) btn.getLayoutParams()).setMargins(4, 0, 4, 0);
        btn.setOnClickListener(new View.OnClickListener() {
				public void onClick(View v) {
					if (mode == MODESIFG1) showSIFgVersionDialog();
					else setMode(mode);
				}
			});
        return btn;
    }

    private Button createConfigButton(String text, View.OnClickListener listener) {
        Button btn = new Button(this);
        btn.setText(text);
        btn.setTextSize(11);
        btn.setLayoutParams(new LinearLayout.LayoutParams(0, -2, 1));
        ((LinearLayout.LayoutParams) btn.getLayoutParams()).setMargins(4, 0, 4, 0);
        btn.setOnClickListener(listener);
        return btn;
    }

    private void showSIFgVersionDialog() {
        new AlertDialog.Builder(this)
            .setTitle("Selecciona versión SIFg")
            .setItems(new String[]{"v1.0 (Directo)", "v1.1 (Interpolado rápido)"}, new DialogInterface.OnClickListener() {
                public void onClick(DialogInterface dialog, int which) {
                    sifgVersion = which;
                    prefs.edit().putInt("sifg_version", sifgVersion).apply();
                    setMode(MODESIFG1);
                }
            }).show();
    }

    private void showFisheyeDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Corrección Efecto Ojo de Pez");
        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);
        layout.setPadding(32, 16, 32, 16);
        final SeekBar seekBar = new SeekBar(this);
        seekBar.setMax(200);
        seekBar.setProgress(fisheyeCorrection + 100);
        final TextView valueLabel = new TextView(this);
        valueLabel.setText("Factor: " + (fisheyeCorrection > 0 ? "+" : "") + fisheyeCorrection);
        valueLabel.setGravity(Gravity.CENTER);
        valueLabel.setPadding(0, 16, 0, 0);
        seekBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
				public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
					int value = progress - 100;
					valueLabel.setText("Factor: " + (value > 0 ? "+" : "") + value);
				}

				public void onStartTrackingTouch(SeekBar seekBar) {
				}

				public void onStopTrackingTouch(SeekBar seekBar) {
				}
			});
        layout.addView(seekBar);
        layout.addView(valueLabel);
        builder.setView(layout);
        builder.setPositiveButton("Aplicar", new DialogInterface.OnClickListener() {
				public void onClick(DialogInterface dialog, int which) {
					fisheyeCorrection = seekBar.getProgress() - 100;
					prefs.edit().putInt("fisheye_correction", fisheyeCorrection).apply();
					btnFisheyeCorrection.setText("FishEye: " + (fisheyeCorrection > 0 ? "+" : "") + fisheyeCorrection);
					if (captureService != null && isCapturing) captureService.setFisheyeCorrection(fisheyeCorrection);
				}
			});
        builder.setNegativeButton("Cancelar", null);
        builder.show();
    }

    private void showResolutionDialog() {
        new AlertDialog.Builder(this)
            .setTitle("Selecciona resolución de captura")
            .setItems(new String[]{"25% (Máx velocidad)", "50% (Balance)", "75% (Más calidad)"}, new DialogInterface.OnClickListener() {
                public void onClick(DialogInterface dialog, int which) {
                    float[] scales = {0.25f, 0.5f, 0.75f};
                    resolutionScale = scales[which];
                    prefs.edit().putFloat("resolution_scale", resolutionScale).apply();
                    btnResolutionConfig.setText("Res: " + (int) (resolutionScale * 100) + "%");
                    DisplayMetrics metrics = new DisplayMetrics();
                    getWindowManager().getDefaultDisplay().getRealMetrics(metrics);
                    adjustResolutions(metrics);
                    updateResolutionText();
                    if (captureService != null && isCapturing) {
                        captureService.updateResolution(sourceWidth, sourceHeight, targetWidth, targetHeight);
                        captureService.setResolutionScale(resolutionScale);
                    }
                }
            }).show();
    }

    private void showFrameGenerationDialog() {
        new AlertDialog.Builder(this)
            .setTitle("Frames a generar entre frames reales")
            .setItems(new String[]{"1 (2x FPS)", "2 (3x FPS)", "3 (4x FPS)", "4 (5x FPS)"}, new DialogInterface.OnClickListener() {
                public void onClick(DialogInterface dialog, int which) {
                    int[] values = {1, 2, 3, 4};
                    framesToGenerate = values[which];
                    prefs.edit().putInt("frames_to_generate", framesToGenerate).apply();
                    btnFrameGenerationConfig.setText("Gen: " + framesToGenerate);
                    generationInfoText.setText("Frames generados: " + framesToGenerate + " | Calidad: " + getColorQualityText());
                    if (captureService != null && isCapturing) captureService.setFramesToGenerate(framesToGenerate);
                }
            }).show();
    }

    private void showColorQualityDialog() {
        new AlertDialog.Builder(this)
            .setTitle("Calidad de color")
            .setItems(new String[]{"Completa (24-bit)", "8-bit (Retro)", "256 colores (Paletizado)"}, new DialogInterface.OnClickListener() {
                public void onClick(DialogInterface dialog, int which) {
                    colorQuality = which;
                    prefs.edit().putInt("color_quality", colorQuality).apply();
                    btnColorQualityConfig.setText(getColorQualityText());
                    generationInfoText.setText("Frames generados: " + framesToGenerate + " | Calidad: " + getColorQualityText());
                    if (captureService != null && isCapturing) captureService.setColorQuality(colorQuality);
                }
            }).show();
    }

    private String getColorQualityText() {
        switch (colorQuality) {
            case 1:
                return "8-bit";
            case 2:
                return "256c";
            default:
                return "Full";
        }
    }

    private void updateResolutionText() {
        resolutionText.setText("Captura: " + sourceWidth + "x" + sourceHeight + " | Salida: " + targetWidth + "x" + targetHeight + " | Escala: " + (int) (resolutionScale * 100) + "%");
    }

    private void setMode(int mode) {
        currentMode.set(mode);
        String modeText;
        String sifgInfo = "";
        int highlightColor = Color.rgb(0, 150, 0);
        int normalColor = Color.rgb(64, 64, 64);

        btnPerformanceMode.setBackgroundColor(normalColor);
        btnSIFgMode.setBackgroundColor(normalColor);

        switch (mode) {
            case MODEPERFORMANCE:
                modeText = "Rendimiento (Directo)";
                btnPerformanceMode.setBackgroundColor(highlightColor);
                break;
            case MODESIFG1:
                if (sifgVersion == 0) {
                    modeText = "SIFg v1.0";
                    sifgInfo = "Generación desde un solo frame (sin ghosting)";
                } else {
                    modeText = "SIFg v1.1";
                    sifgInfo = "Generación interpolada rápida (anti-stutter)";
                }
                btnSIFgMode.setBackgroundColor(highlightColor);
                break;
            default:
                modeText = "Rendimiento";
                btnPerformanceMode.setBackgroundColor(highlightColor);
                break;
        }
        statusText.setText("Modo: " + modeText);
        sifgInfoText.setText(sifgInfo);
        if (captureService != null) {
            captureService.setMode(mode);
            captureService.setSifgVersion(sifgVersion);
        }
    }

    private void startCapture() {
        if (!isAccessibilityServiceEnabled()) {
            Toast.makeText(this, "Habilitando servicio de accesibilidad...", Toast.LENGTH_LONG).show();
            startActivityForResult(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS), REQUESTCODEACCESSIBILITY);
            return;
        }
        if (Build.VERSION.SDK_INT >= 23 && !Settings.canDrawOverlays(this)) {
            Toast.makeText(this, "Habilitando permisos de superposición...", Toast.LENGTH_LONG).show();
            startActivityForResult(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION), REQUESTCODEOVERLAY);
            return;
        }
        if (mpManager == null) {
            Toast.makeText(this, "Error: MediaProjectionManager no disponible", Toast.LENGTH_SHORT).show();
            return;
        }
        startActivityForResult(mpManager.createScreenCaptureIntent(), REQUESTCODECAPTURE);
    }

    private boolean isAccessibilityServiceEnabled() {
        try {
            int enabled = Settings.Secure.getInt(getContentResolver(), Settings.Secure.ACCESSIBILITY_ENABLED);
            if (enabled == 1) {
                String services = Settings.Secure.getString(getContentResolver(), Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES);
                if (services != null) {
                    String ourService = getPackageName() + "/" + TouchForwardService.class.getName();
                    return services.contains(ourService);
                }
            }
        } catch (Settings.SettingNotFoundException e) {
            Log.e(TAG, "Error checking accessibility service", e);
        }
        return false;
    }

    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (requestCode == REQUESTCODEACCESSIBILITY) {
            if (isAccessibilityServiceEnabled()) {
                Toast.makeText(this, "Servicio de accesibilidad habilitado. Ahora inicia la captura.", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(this, "Debes habilitar el servicio de accesibilidad para continuar", Toast.LENGTH_LONG).show();
            }
        } else if (requestCode == REQUESTCODEOVERLAY) {
            if (Build.VERSION.SDK_INT >= 23 && Settings.canDrawOverlays(this)) {
                Toast.makeText(this, "Permisos de superposición concedidos. Ahora inicia la captura.", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(this, "Debes habilitar los permisos de superposición para continuar", Toast.LENGTH_LONG).show();
            }
        } else if (requestCode == REQUESTCODECAPTURE) {
            if (resultCode == RESULT_OK && data != null) {
                this.resultCode = resultCode;
                this.resultData = data;
                startCaptureInternal();
            } else {
                Toast.makeText(this, "Permiso de captura denegado", Toast.LENGTH_SHORT).show();
            }
        }
    }

    private void startCaptureInternal() {
        if (serviceBound && captureService != null && resultData != null && !isFinishing() && !isDestroyed()) {
            captureService.startCapture(resultCode, resultData, sourceWidth, sourceHeight, targetWidth, targetHeight, screenDensityDpi, topInset, bottomInset);
            isCapturing = true;
            hideControlsAndStartOverlay();
            startFpsMonitor();
        } else {
            Toast.makeText(this, "Servicio no disponible", Toast.LENGTH_SHORT).show();
        }
    }

    private void hideControlsAndStartOverlay() {
        runOnUiThread(new Runnable() {
				public void run() {
					if (!isFinishing() && !isDestroyed()) {
						controlPanel.setVisibility(View.GONE);
						moveTaskToBack(true);
						Toast.makeText(ScreenScaler.this, "Captura iniciada - Overlay activo", Toast.LENGTH_SHORT).show();
					}
				}
			});
    }

    private void stopCapture() {
        if (captureService != null) captureService.stopCapture();
        isCapturing = false;
        fpsHandler.removeCallbacks(fpsRunnable);
        runOnUiThread(new Runnable() {
				public void run() {
					controlPanel.setVisibility(View.VISIBLE);
					fpsCounter.setText("FPS: 0 | Frames: 0 | Perdidos: 0");
				}
			});
    }

    private void startFpsMonitor() {
        fpsHandler.removeCallbacks(fpsRunnable);
        fpsHandler.post(fpsRunnable);
    }

    private void loadStats() {
        int avgPerformance = prefs.getInt("avg_fps_performance", 0);
        int avgSIFG1 = prefs.getInt("avg_fps_sifg1", 0);
        String stats = "Estadísticas del dispositivo:\n";
        if (avgPerformance > 0) stats += "Rendimiento: " + avgPerformance + " FPS | ";
        if (avgSIFG1 > 0) stats += "SIFg1: " + avgSIFG1 + " FPS";
        if (avgPerformance > 0 || avgSIFG1 > 0) statsText.setText(stats);
    }

    public void onBackPressed() {
        if (isCapturing) {
            Toast.makeText(this, "Deteniendo captura...", Toast.LENGTH_SHORT).show();
            stopCapture();
        } else {
            super.onBackPressed();
        }
    }

    public void onConfigurationChanged(Configuration newConfig) {
        super.onConfigurationChanged(newConfig);
        DisplayMetrics metrics = new DisplayMetrics();
        getWindowManager().getDefaultDisplay().getRealMetrics(metrics);
        adjustResolutions(metrics);
        if (resolutionText != null) updateResolutionText();
        if (captureService != null && isCapturing) captureService.updateResolution(sourceWidth, sourceHeight, targetWidth, targetHeight);
    }

    protected void onDestroy() {
        if (batteryReceiver != null) {
            try {
                unregisterReceiver(batteryReceiver);
            } catch (IllegalArgumentException e) {
                Log.e(TAG, "Battery receiver not registered", e);
            }
        }
        fpsHandler.removeCallbacks(fpsRunnable);
        if (serviceBound) {
            unbindService(serviceConnection);
            serviceBound = false;
        }
        super.onDestroy();
    }

    private class BatteryReceiver extends BroadcastReceiver {
        public void onReceive(Context context, Intent intent) {
            int level = intent.getIntExtra(BatteryManager.EXTRA_LEVEL, -1);
            int scale = intent.getIntExtra(BatteryManager.EXTRA_SCALE, -1);
            float batteryPct = level / (float) scale * 100;
            if (batteryPct < 15 && currentMode.get() != MODEPERFORMANCE && isCapturing) {
                setMode(MODEPERFORMANCE);
                Toast.makeText(context, "Batería baja: Modo Rendimiento activado", Toast.LENGTH_SHORT).show();
            }
        }
    }

    public static class TouchForwardService extends AccessibilityService {
        private static TouchForwardService instance;

        public void onAccessibilityEvent(AccessibilityEvent event) {
        }

        public void onInterrupt() {
        }

        protected void onServiceConnected() {
            super.onServiceConnected();
            instance = this;
            Process.setThreadPriority(Process.THREAD_PRIORITY_URGENT_DISPLAY);
        }

        public void onDestroy() {
            instance = null;
            super.onDestroy();
        }

        public static boolean isRunning() {
            return instance != null;
        }

        public static void dispatchTouch(MotionEvent event) {
            if (instance != null && Build.VERSION.SDK_INT >= 24) instance.performTouch(event);
        }

        private void performTouch(MotionEvent event) {
            if (Build.VERSION.SDK_INT < 24) return;
            try {
                int pointerCount = event.getPointerCount();
                GestureDescription.Builder builder = new GestureDescription.Builder();
                for (int i = 0; i < pointerCount; i++) {
                    Path path = new Path();
                    path.moveTo(event.getX(i), event.getY(i));
                    int action = event.getActionMasked();
                    GestureDescription.StrokeDescription stroke = null;
                    if (action == MotionEvent.ACTION_DOWN || action == MotionEvent.ACTION_POINTER_DOWN || action == MotionEvent.ACTION_MOVE) {
                        stroke = new GestureDescription.StrokeDescription(path, 0, 100, true);
                    } else if (action == MotionEvent.ACTION_UP || action == MotionEvent.ACTION_POINTER_UP) {
                        stroke = new GestureDescription.StrokeDescription(path, 0, 1);
                    }
                    if (stroke != null) builder.addStroke(stroke);
                }
                dispatchGesture(builder.build(), null, null);
            } catch (Exception e) {
                Log.e(TAG, "Error dispatching touch", e);
            }
        }
    }

    public static class ScreenCaptureService extends Service {
        private static final int NOTIFICATIONID = 1001;
        private static final String CHANNELID = "ScreenCaptureChannel";
        private static final String ACTION_STOP = "com.TurungSoftware.FrameGenerator.STOP";
        private static final long TARGET_FRAME_INTERVAL_NANOS = 33333333L; // 30 FPS exactos

        private MediaProjection projection;
        private VirtualDisplay virtualDisplay;
        private ImageReader imageReader;
        private HandlerThread processingThread;
        private Handler processingHandler;
        private volatile boolean running = false;
        private int currentMode = MODEPERFORMANCE;
        private int sifgVersion = 0;
        private float resolutionScale = 0.5f;
        private int framesToGenerate = 1;
        private int colorQuality = 0;
        private int fisheyeCorrection = 0;
        private boolean useSingleFrameGen = false;
        private int sourceWidth, sourceHeight, targetWidth, targetHeight, topInset, bottomInset;
        private AtomicInteger framesProcessed = new AtomicInteger(0);
        private AtomicLong lastFpsUpdate = new AtomicLong(0);
        private AtomicInteger droppedFrames = new AtomicInteger(0);
        private AtomicInteger currentFps = new AtomicInteger(0);
        private AtomicInteger captureErrorCount = new AtomicInteger(0);
        private long[] hashSamples = new long[10];
        private int hashSampleIndex = 0;
        private long lastFrameHash = 0;
        private int staticFrameCount = 0;
        private SharedPreferences prefs;
        private long sessionStartTime = 0;
        private int sessionTotalFrames = 0;
        private long[] motionVector = new long[2];
        private long nextFrameDeadlineNanos = 0;

        // HashMap para gestión de recursos y buffers únicos
        private final Map<String, Object> resourceCache = new HashMap<String, Object>();
        private static final String KEY_RENDER_BITMAP = "render_bitmap";
        private static final String KEY_UPSCALE_BUFFER_A = "upscale_buffer_a";
        private static final String KEY_UPSCALE_BUFFER_B = "upscale_buffer_b";
        private static final String KEY_EXTRAPOLATION_BUFFER = "extrapolation_buffer";
        private static final String KEY_STATIC_BUFFER = "static_buffer";
        private static final String KEY_SOURCE_BUFFER = "source_buffer";
        private static final String KEY_LAST_REAL_FRAME = "last_real_frame";
        private static final String KEY_PREV_FRAME_BUFFER = "prev_frame_buffer";
        private static final String KEY_CACHED_STATIC_FRAME = "cached_static_frame";
        private static final String KEY_DIRECT_FRAME_BUFFER = "direct_frame_buffer";

        private volatile byte[] pendingGeneratedFrame = null;
        private volatile long generatedFrameDeadline = 0;
        private boolean useUpscaleA = true;
        private Paint bitmapPaint;
        private Paint clearPaint;
        private WindowManager windowManager;
        private SurfaceView overlayView;
        private FrameLayout overlayContainer;
        private Surface overlaySurface;
        private long lastRenderTime = 0;
        private final Handler mainHandler = new Handler(Looper.getMainLooper());
        private volatile boolean isSurfaceValid = false;

        private final IBinder binder = new LocalBinder();
        private final BroadcastReceiver controlReceiver = new BroadcastReceiver() {
            public void onReceive(Context context, Intent intent) {
                if (ACTION_STOP.equals(intent.getAction())) stopCapture();
            }
        };

        public class LocalBinder extends Binder {
            ScreenCaptureService getService() {
                return ScreenCaptureService.this;
            }
        }

        public IBinder onBind(Intent intent) {
            return binder;
        }

        public void onCreate() {
            super.onCreate();
            processingThread = new HandlerThread("ScalerThread", Process.THREAD_PRIORITY_URGENT_DISPLAY);
            processingThread.start();
            processingHandler = new Handler(processingThread.getLooper());
            Process.setThreadPriority(Process.THREAD_PRIORITY_URGENT_DISPLAY);
            prefs = getSharedPreferences("ScreenScalerStats", MODE_PRIVATE);
            createNotificationChannel();
            registerReceiver(controlReceiver, new IntentFilter(ACTION_STOP));
            nextFrameDeadlineNanos = System.nanoTime();
        }

        private void createNotificationChannel() {
            if (Build.VERSION.SDK_INT >= 26) {
                NotificationChannel channel = new NotificationChannel(CHANNELID, "Screen Capture Service", NotificationManager.IMPORTANCE_LOW);
                channel.setDescription("Servicio de captura de pantalla activo");
                NotificationManager manager = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
                if (manager != null) manager.createNotificationChannel(channel);
            }
        }

        private Notification createNotification() {
            Intent stopIntent = new Intent(ACTION_STOP);
            PendingIntent stopPending = Build.VERSION.SDK_INT >= 31 ?
                PendingIntent.getBroadcast(this, 2, stopIntent, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE) :
                PendingIntent.getBroadcast(this, 2, stopIntent, 0);

            Notification.Builder builder = Build.VERSION.SDK_INT >= 26 ?
                new Notification.Builder(this, CHANNELID) : new Notification.Builder(this);
            builder.setContentTitle("Frame Generator Pro")
                .setContentText("Captura activa - FPS: " + currentFps.get())
                .setSmallIcon(android.R.drawable.ic_menu_camera)
                .addAction(android.R.drawable.ic_menu_close_clear_cancel, "Detener", stopPending);
            return builder.build();
        }

        private void updateNotification() {
            NotificationManager manager = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
            if (manager != null) manager.notify(NOTIFICATIONID, createNotification());
        }

        public void setMode(int mode) {
            this.currentMode = mode;
            this.useSingleFrameGen = (mode == MODESIFG1);
            Arrays.fill(hashSamples, 0);
            staticFrameCount = 0;
            lastFrameHash = 0;
        }

        public void setSifgVersion(int version) {
            this.sifgVersion = version;
        }

        public void setResolutionScale(float scale) {
            this.resolutionScale = scale;
        }

        public void setFramesToGenerate(int count) {
            this.framesToGenerate = Math.max(1, Math.min(4, count));
        }

        public void setColorQuality(int quality) {
            this.colorQuality = quality;
        }

        public void setFisheyeCorrection(int correction) {
            this.fisheyeCorrection = correction;
        }

        public int getFps() {
            return currentFps.get();
        }

        public int getTotalFrames() {
            return framesProcessed.get();
        }

        public int getDroppedFrames() {
            return droppedFrames.get();
        }

        public void updateResolution(int srcW, int srcH, int tgtW, int tgtH) {
            this.sourceWidth = srcW;
            this.sourceHeight = srcH;
            this.targetWidth = tgtW;
            this.targetHeight = tgtH;
            initializeBufferPools();
            precalculateMappings();
        }

        private synchronized void tryInjectPendingFrame() {
            if (pendingGeneratedFrame != null && System.nanoTime() < generatedFrameDeadline) {
                renderToSurface(pendingGeneratedFrame);
                framesProcessed.incrementAndGet();
                sessionTotalFrames++;
                pendingGeneratedFrame = null;
            }
        }

        public void startCapture(int resultCode, Intent data, int srcW, int srcH, int tgtW, int tgtH, int dpi, int topInset, int bottomInset) {
            if (running) return;

            this.sourceWidth = srcW;
            this.sourceHeight = srcH;
            this.targetWidth = tgtW;
            this.targetHeight = tgtH;
            this.topInset = topInset;
            this.bottomInset = bottomInset;

            initializeBufferPools();
            precalculateMappings();

            if (Looper.myLooper() == Looper.getMainLooper()) {
                createOverlayWindow();
            } else {
                mainHandler.post(new Runnable() {
						public void run() {
							createOverlayWindow();
						}
					});
            }

            try {
                startForeground(NOTIFICATIONID, createNotification());
                MediaProjectionManager mpManager = (MediaProjectionManager) getSystemService(Context.MEDIA_PROJECTION_SERVICE);
                projection = mpManager.getMediaProjection(resultCode, data);
                if (projection == null) return;

                imageReader = ImageReader.newInstance(sourceWidth, sourceHeight, PixelFormat.RGBA_8888, 3);
                virtualDisplay = projection.createVirtualDisplay("ScreenScaler", sourceWidth, sourceHeight, dpi,
                                                                 DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
                                                                 imageReader.getSurface(), null, processingHandler);

                running = true;
                sessionStartTime = System.currentTimeMillis();
                sessionTotalFrames = 0;
                lastFpsUpdate.set(System.currentTimeMillis());
                framesProcessed.set(0);
                droppedFrames.set(0);
                nextFrameDeadlineNanos = System.nanoTime();
                processingHandler.post(new FpsUpdater());

                imageReader.setOnImageAvailableListener(new ImageReader.OnImageAvailableListener() {
						public void onImageAvailable(ImageReader reader) {
							if (!running) return;
							long currentTime = System.nanoTime();
							if (currentTime < nextFrameDeadlineNanos) {
								Image image = reader.acquireLatestImage();
								if (image != null) image.close();
								droppedFrames.incrementAndGet();
								return;
							}
							nextFrameDeadlineNanos = currentTime + TARGET_FRAME_INTERVAL_NANOS;

							Image image = null;
							try {
								image = reader.acquireLatestImage();
								if (image != null && running) {
									captureErrorCount.set(0);
									if (useSingleFrameGen) {
										if (sifgVersion == 0) processingHandler.post(new SIFgV1FrameGenerator(image));
										else processingHandler.post(new SIFgV1_1FrameGenerator(image));
									} else {
										processingHandler.post(new FrameProcessor(image));
									}
								}
							} catch (Exception e) {
								Log.e(TAG, "Error acquiring image", e);
								if (image != null) image.close();
								droppedFrames.incrementAndGet();
								int errors = captureErrorCount.incrementAndGet();
								if (errors >= 3) {
									mainHandler.post(new Runnable() {
											public void run() {
												Toast.makeText(ScreenCaptureService.this, "Error de captura: reiniciar app", Toast.LENGTH_LONG).show();
											}
										});
									captureErrorCount.set(0);
								}
							}
						}
					}, processingHandler);

            } catch (Exception e) {
                Log.e(TAG, "Error starting capture", e);
                stopCapture();
            }
        }

        public void stopCapture() {
            if (!running) return;
            running = false;
            saveStats();

            if (virtualDisplay != null) {
                try {
                    virtualDisplay.release();
                } catch (Exception e) {
                    Log.e(TAG, "Error releasing virtual display", e);
                }
                virtualDisplay = null;
            }
            if (imageReader != null) {
                try {
                    imageReader.close();
                } catch (Exception e) {
                    Log.e(TAG, "Error closing image reader", e);
                }
                imageReader = null;
            }
            if (projection != null) {
                try {
                    projection.stop();
                } catch (Exception e) {
                    Log.e(TAG, "Error stopping projection", e);
                }
                projection = null;
            }

            removeOverlayWindow();
            stopForeground(true);
            releaseBuffers();
            stopSelf();
        }

        private void releaseBuffers() {
            synchronized (resourceCache) {
                Bitmap bmp = (Bitmap) resourceCache.get(KEY_RENDER_BITMAP);
                if (bmp != null && !bmp.isRecycled()) {
                    bmp.recycle();
                }
                resourceCache.clear();
            }
            pendingGeneratedFrame = null;
        }

        private void initializeBufferPools() {
            int targetSize = targetWidth * targetHeight * 4;
            int sourceSize = sourceWidth * sourceHeight * 4;

            synchronized (resourceCache) {
                resourceCache.put(KEY_SOURCE_BUFFER, new byte[sourceSize]);
                resourceCache.put(KEY_UPSCALE_BUFFER_A, new byte[targetSize]);
                resourceCache.put(KEY_UPSCALE_BUFFER_B, new byte[targetSize]);
                resourceCache.put(KEY_EXTRAPOLATION_BUFFER, new byte[targetSize]);
                resourceCache.put(KEY_STATIC_BUFFER, new byte[targetSize]);
                resourceCache.put(KEY_LAST_REAL_FRAME, new byte[targetSize]);
                resourceCache.put(KEY_PREV_FRAME_BUFFER, new byte[targetSize]);

                ByteBuffer directBuffer = ByteBuffer.allocateDirect(targetSize);
                directBuffer.order(ByteOrder.nativeOrder());
                resourceCache.put(KEY_DIRECT_FRAME_BUFFER, directBuffer);
            }

            Bitmap existingBitmap = (Bitmap) resourceCache.get(KEY_RENDER_BITMAP);
            if (existingBitmap != null && !existingBitmap.isRecycled() && 
                existingBitmap.getWidth() == targetWidth && existingBitmap.getHeight() == targetHeight) {
            } else {
                if (existingBitmap != null) existingBitmap.recycle();
                Bitmap newBitmap = Bitmap.createBitmap(targetWidth, targetHeight, Bitmap.Config.ARGB_8888);
                newBitmap.eraseColor(Color.BLACK);
                resourceCache.put(KEY_RENDER_BITMAP, newBitmap);
            }

            if (bitmapPaint == null) {
                bitmapPaint = new Paint();
                bitmapPaint.setAntiAlias(false);
                bitmapPaint.setFilterBitmap(false);
                bitmapPaint.setDither(false);
                bitmapPaint.setAlpha(255);
            }
            if (clearPaint == null) {
                clearPaint = new Paint();
                clearPaint.setXfermode(new PorterDuffXfermode(PorterDuff.Mode.CLEAR));
            }
        }

        private void precalculateMappings() {
            int[] xMapping = new int[targetWidth];
            int[] yMapping = new int[targetHeight];
            float[] xWeights = new float[targetWidth];
            float[] yWeights = new float[targetHeight];

            float invScaleX = (float) sourceWidth / targetWidth;
            float invScaleY = (float) sourceHeight / targetHeight;

            for (int x = 0; x < targetWidth; x++) {
                float srcX = x * invScaleX;
                xMapping[x] = (int) srcX;
                xWeights[x] = srcX - xMapping[x];
            }
            for (int y = 0; y < targetHeight; y++) {
                float srcY = y * invScaleY;
                yMapping[y] = (int) srcY;
                yWeights[y] = srcY - yMapping[y];
            }

            synchronized (resourceCache) {
                resourceCache.put("xMapping", xMapping);
                resourceCache.put("yMapping", yMapping);
                resourceCache.put("xWeights", xWeights);
                resourceCache.put("yWeights", yWeights);
            }
        }

        private void createOverlayWindow() {
            if (Build.VERSION.SDK_INT < 23 || !Settings.canDrawOverlays(this)) return;

            windowManager = (WindowManager) getSystemService(WINDOW_SERVICE);
            WindowManager.LayoutParams params = new WindowManager.LayoutParams(
                targetWidth, targetHeight,
                Build.VERSION.SDK_INT >= 26 ? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY : WindowManager.LayoutParams.TYPE_PHONE,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE |
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS |
                WindowManager.LayoutParams.FLAG_HARDWARE_ACCELERATED,
                PixelFormat.OPAQUE);

            params.alpha = 1.0f;
            params.gravity = Gravity.TOP | Gravity.LEFT;
            params.x = 0;
            params.y = 0;

            overlayContainer = new FrameLayout(this);
            overlayContainer.setLayoutParams(new ViewGroup.LayoutParams(
                                                 ViewGroup.LayoutParams.MATCH_PARENT,
                                                 ViewGroup.LayoutParams.MATCH_PARENT));
            overlayContainer.setBackgroundColor(Color.BLACK);

            // Usamos SurfaceView en lugar de TextureView para opacidad total
            overlayView = new SurfaceView(this);
            overlayView.setZOrderOnTop(false); // Importante: no estar encima de la ventana
            overlayView.setZOrderMediaOverlay(false);

            overlayContainer.addView(overlayView, new FrameLayout.LayoutParams(
                                         targetWidth, targetHeight));

            overlayView.getHolder().addCallback(new SurfaceHolder.Callback() {
					public void surfaceCreated(SurfaceHolder holder) {
						if (!running) return;
						overlaySurface = holder.getSurface();
						isSurfaceValid = true;
						// Forzar negro inicial
						Canvas canvas = null;
						try {
							canvas = holder.lockCanvas(null);
							if (canvas != null) {
								canvas.drawColor(Color.BLACK);
							}
						} catch (Exception e) {
							Log.e(TAG, "Error drawing initial canvas", e);
						} finally {
							if (canvas != null) {
								holder.unlockCanvasAndPost(canvas);
							}
						}
					}

					public void surfaceChanged(SurfaceHolder holder, int format, int width, int height) {
						overlaySurface = holder.getSurface();
						isSurfaceValid = true;
					}

					public void surfaceDestroyed(SurfaceHolder holder) {
						overlaySurface = null;
						isSurfaceValid = false;
					}
				});

            overlayContainer.setOnTouchListener(new View.OnTouchListener() {
					public boolean onTouch(View v, MotionEvent event) {
						if (running && TouchForwardService.isRunning()) {
							TouchForwardService.dispatchTouch(event);
							return true;
						}
						return false;
					}
				});

            try {
                windowManager.addView(overlayContainer, params);
            } catch (Exception e) {
                Log.e(TAG, "Error adding overlay window", e);
            }
        }

        private void forceOpaqueBackground() {
            if (overlaySurface == null || !overlaySurface.isValid()) return;

            Canvas canvas = null;
            try {
                canvas = overlayView.getHolder().lockCanvas(null);
                if (canvas != null) {
                    Paint blackPaint = new Paint();
                    blackPaint.setColor(Color.BLACK);
                    blackPaint.setStyle(Paint.Style.FILL);
                    blackPaint.setAlpha(255);

                    canvas.drawRect(0, 0, targetWidth, targetHeight, blackPaint);
                }
            } catch (Exception e) {
                Log.e(TAG, "Error forcing opaque background", e);
            } finally {
                if (canvas != null) {
                    try {
                        overlayView.getHolder().unlockCanvasAndPost(canvas);
                    } catch (Exception e) {
                        Log.e(TAG, "Error unlocking canvas", e);
                    }
                }
            }
        }

        private void removeOverlayWindow() {
            if (windowManager != null) {
                if (overlayContainer != null) {
                    if (Looper.myLooper() == Looper.getMainLooper()) {
                        try {
                            windowManager.removeView(overlayContainer);
                        } catch (Exception e) {
                            Log.e(TAG, "Error removing overlay", e);
                        }
                    } else {
                        mainHandler.post(new Runnable() {
								public void run() {
									try {
										if (windowManager != null && overlayContainer != null) {
											windowManager.removeView(overlayContainer);
										}
									} catch (Exception e) {
										Log.e(TAG, "Error removing overlay from handler", e);
									}
								}
							});
                    }
                }
                overlayContainer = null;
                overlayView = null;
                windowManager = null;
            }
            overlaySurface = null;
            isSurfaceValid = false;
        }

        private long calculateOptimizedHash(byte[] data) {
            long hash = 5381;
            int step = Math.max(4, data.length / 64);
            int quarter = data.length / 4;
            for (int i = 0; i < 4; i++) {
                int base = i * quarter;
                for (int j = base; j < base + quarter; j += step) {
                    hash = ((hash << 5) + hash) + (data[j] & 0xFF);
                }
            }
            return hash;
        }

        private void captureImageWithQualityReduction(Image image, byte[] destBuffer) {
            if (image == null || destBuffer == null) return;
            try {
                Image.Plane[] planes = image.getPlanes();
                if (planes.length == 0) return;
                ByteBuffer buffer = planes[0].getBuffer();
                int pixelStride = planes[0].getPixelStride();
                int rowStride = planes[0].getRowStride();
                buffer.rewind();
                int bufferPos = 0;
                int dataPos = 0;
                int rowPadding = rowStride - pixelStride * sourceWidth;

                if (colorQuality == 0) {
                    for (int y = 0; y < sourceHeight; y++) {
                        for (int x = 0; x < sourceWidth; x++) {
                            if (bufferPos + 3 < buffer.capacity() && dataPos + 3 < destBuffer.length) {
                                destBuffer[dataPos] = buffer.get(bufferPos);
                                destBuffer[dataPos + 1] = buffer.get(bufferPos + 1);
                                destBuffer[dataPos + 2] = buffer.get(bufferPos + 2);
                                destBuffer[dataPos + 3] = buffer.get(bufferPos + 3);
                            }
                            bufferPos += pixelStride;
                            dataPos += 4;
                        }
                        bufferPos += rowPadding;
                    }
                } else if (colorQuality == 1) {
                    for (int y = 0; y < sourceHeight; y++) {
                        for (int x = 0; x < sourceWidth; x++) {
                            if (bufferPos + 3 < buffer.capacity() && dataPos + 3 < destBuffer.length) {
                                int r = buffer.get(bufferPos) & 0xFF;
                                int g = buffer.get(bufferPos + 1) & 0xFF;
                                int b = buffer.get(bufferPos + 2) & 0xFF;
                                int a = buffer.get(bufferPos + 3) & 0xFF;
                                destBuffer[dataPos] = (byte) (r & 0xF8);
                                destBuffer[dataPos + 1] = (byte) (g & 0xF8);
                                destBuffer[dataPos + 2] = (byte) (b & 0xF8);
                                destBuffer[dataPos + 3] = (byte) a;
                            }
                            bufferPos += pixelStride;
                            dataPos += 4;
                        }
                        bufferPos += rowPadding;
                    }
                } else if (colorQuality == 2) {
                    for (int y = 0; y < sourceHeight; y++) {
                        for (int x = 0; x < sourceWidth; x++) {
                            if (bufferPos + 3 < buffer.capacity() && dataPos + 3 < destBuffer.length) {
                                int r = (buffer.get(bufferPos) & 0xFF) >> 5;
                                int g = (buffer.get(bufferPos + 1) & 0xFF) >> 5;
                                int b = (buffer.get(bufferPos + 2) & 0xFF) >> 6;
                                destBuffer[dataPos] = (byte) ((r << 5) | (r << 2) | (r >> 1));
                                destBuffer[dataPos + 1] = (byte) ((g << 5) | (g << 2) | (g >> 1));
                                destBuffer[dataPos + 2] = (byte) ((b << 6) | (b << 4) | (b << 2) | b);
                                destBuffer[dataPos + 3] = (byte) 255;
                            }
                            bufferPos += pixelStride;
                            dataPos += 4;
                        }
                        bufferPos += rowPadding;
                    }
                }
            } catch (Exception e) {
                Log.e(TAG, "Error capturing image with quality reduction", e);
            }
        }

        private class FrameProcessor implements Runnable {
            private final Image image;

            FrameProcessor(Image img) {
                this.image = img;
            }

            public void run() {
                tryInjectPendingFrame();

                if (image == null || !running) {
                    if (image != null) image.close();
                    return;
                }
                try {
                    byte[] sourceBuffer = (byte[]) resourceCache.get(KEY_SOURCE_BUFFER);
                    captureImageWithQualityReduction(image, sourceBuffer);
                    long frameHash = calculateOptimizedHash(sourceBuffer);
                    hashSamples[hashSampleIndex] = frameHash;
                    hashSampleIndex = (hashSampleIndex + 1) % hashSamples.length;
                    boolean isStatic = true;
                    for (int i = 1; i < hashSamples.length; i++) {
                        if (hashSamples[i] != hashSamples[0]) {
                            isStatic = false;
                            break;
                        }
                    }
                    if (isStatic && staticFrameCount >= 3) {
                        byte[] cachedStaticFrame = (byte[]) resourceCache.get(KEY_CACHED_STATIC_FRAME);
                        if (cachedStaticFrame != null) {
                            renderToSurface(cachedStaticFrame);
                            framesProcessed.incrementAndGet();
                            image.close();
                            return;
                        }
                    }
                    staticFrameCount = isStatic ? staticFrameCount + 1 : 0;
                    byte[] processedData = nearestNeighborUpscale(sourceBuffer, sourceWidth, sourceHeight);
                    if (staticFrameCount >= 3) {
                        byte[] staticBuffer = (byte[]) resourceCache.get(KEY_STATIC_BUFFER);
                        if (staticBuffer != null && processedData != null) {
                            System.arraycopy(processedData, 0, staticBuffer, 0, processedData.length);
                            resourceCache.put(KEY_CACHED_STATIC_FRAME, staticBuffer);
                        }
                    }
                    if (processedData != null) {
                        renderToSurface(processedData);
                        framesProcessed.incrementAndGet();
                        sessionTotalFrames++;
                    }
                } catch (Exception e) {
                    Log.e(TAG, "Error processing frame", e);
                    droppedFrames.incrementAndGet();
                } finally {
                    image.close();
                }
            }
        }

        private class SIFgV1FrameGenerator implements Runnable {
            private final Image image;

            SIFgV1FrameGenerator(Image img) {
                this.image = img;
            }

            public void run() {
                tryInjectPendingFrame();

                if (image == null || !running) {
                    if (image != null) image.close();
                    return;
                }
                try {
                    byte[] sourceBuffer = (byte[]) resourceCache.get(KEY_SOURCE_BUFFER);
                    captureImageWithQualityReduction(image, sourceBuffer);
                    byte[] baseFrame = nearestNeighborUpscale(sourceBuffer, sourceWidth, sourceHeight);
                    if (baseFrame != null) {
                        renderToSurface(baseFrame);
                        framesProcessed.incrementAndGet();
                        sessionTotalFrames++;
                    }
                } catch (Exception e) {
                    Log.e(TAG, "Error in SIFgV1 frame generation", e);
                    droppedFrames.incrementAndGet();
                } finally {
                    image.close();
                }
            }
        }

        private class SIFgV1_1FrameGenerator implements Runnable {
            private final Image image;

            SIFgV1_1FrameGenerator(Image img) {
                this.image = img;
            }

            public void run() {
				tryInjectPendingFrame();

				if (image == null || !running) {
					if (image != null) image.close();
					return;
				}
				try {
					byte[] sourceBuffer = (byte[]) resourceCache.get(KEY_SOURCE_BUFFER);
					captureImageWithQualityReduction(image, sourceBuffer);
					byte[] currentFrame = fastNearestNeighborUpscale(sourceBuffer);
					if (currentFrame == null) {
						image.close();
						return;
					}

					// Renderizar el frame real SIEMPRE
					renderToSurface(currentFrame);
					framesProcessed.incrementAndGet();
					sessionTotalFrames++;

					// Leer el frame ANTERIOR y su timestamp (antes de sobrescribir)
					byte[] lastRealFrame = (byte[]) resourceCache.get(KEY_LAST_REAL_FRAME);
					Long lastRealFrameTime = (Long) resourceCache.get("last_real_frame_time");
					long now = System.nanoTime();

					boolean shouldGenerate = false;
					if (lastRealFrame != null && lastRealFrameTime != null && framesToGenerate > 0) {
						if ((now - lastRealFrameTime) <= 50000000L) { // ≤ 50 ms = frame reciente
							shouldGenerate = true;
						}
					}

					if (shouldGenerate) {
						byte[] extrapolated = fastMotionExtrapolation(lastRealFrame, currentFrame);
						if (extrapolated != null) {
							generatedFrameDeadline = now + 14000000; // ~14 ms = medio frame a 70+ FPS
							pendingGeneratedFrame = extrapolated;
						}
					}

					// Actualizar el "último frame real" SOLO AL FINAL
					System.arraycopy(currentFrame, 0, resourceCache.get(KEY_LAST_REAL_FRAME), 0, currentFrame.length);
					resourceCache.put("last_real_frame_time", now);

				} catch (Exception e) {
					Log.e(TAG, "Error in SIFgV1.1 frame generation", e);
					droppedFrames.incrementAndGet();
				} finally {
					image.close();
				}
			}
        }

        private byte[] fastNearestNeighborUpscale(byte[] source) {
            if (source == null) return null;
            byte[] dest = useUpscaleA ? (byte[]) resourceCache.get(KEY_UPSCALE_BUFFER_A) : (byte[]) resourceCache.get(KEY_UPSCALE_BUFFER_B);
            useUpscaleA = !useUpscaleA;
            float invScaleX = (float) sourceWidth / targetWidth;
            float invScaleY = (float) sourceHeight / targetHeight;
            for (int y = 0; y < targetHeight; y++) {
                int srcY = (int) (y * invScaleY);
                if (srcY >= sourceHeight) srcY = sourceHeight - 1;
                int srcRowBase = srcY * sourceWidth * 4;
                int dstRowBase = y * targetWidth * 4;
                for (int x = 0; x < targetWidth; x++) {
                    int srcX = (int) (x * invScaleX);
                    if (srcX >= sourceWidth) srcX = sourceWidth - 1;
                    int srcIdx = srcRowBase + srcX * 4;
                    int dstIdx = dstRowBase + x * 4;
                    if (srcIdx + 3 < source.length && dstIdx + 3 < dest.length) {
                        dest[dstIdx] = source[srcIdx];
                        dest[dstIdx + 1] = source[srcIdx + 1];
                        dest[dstIdx + 2] = source[srcIdx + 2];
                        dest[dstIdx + 3] = (byte) 255;
                    }
                }
            }
            return dest;
        }

        private byte[] fastMotionExtrapolation(byte[] frameA, byte[] frameB) {
			if (frameA == null || frameB == null) return frameB;

			int[] motion = estimateGlobalMotion(frameA, frameB);
			int shiftX = motion[0];
			int shiftY = motion[1];

			// Si el movimiento es insignificante, NO generar frame interpolado
			if (Math.abs(shiftX) < 1 && Math.abs(shiftY) < 1) {
				return frameB; // o return null si preferís que SIFgV1_1FrameGenerator no lo renderice
			}

			byte[] extrapolated = (byte[]) resourceCache.get(KEY_EXTRAPOLATION_BUFFER);
			if (extrapolated == null) return frameB;

			for (int i = 0; i < extrapolated.length - 4; i += 4) {
				int srcY = i / (targetWidth * 4);
				int srcX = (i % (targetWidth * 4)) / 4;
				int dstX = srcX + shiftX;
				int dstY = srcY + shiftY;

				if (dstX >= 0 && dstX < targetWidth && dstY >= 0 && dstY < targetHeight) {
					int srcPos = i;
					int dstPos = (dstY * targetWidth + dstX) * 4;
					if (dstPos + 3 < extrapolated.length && srcPos + 3 < frameB.length) {
						extrapolated[dstPos]     = frameB[srcPos];
						extrapolated[dstPos + 1] = frameB[srcPos + 1];
						extrapolated[dstPos + 2] = frameB[srcPos + 2];
						extrapolated[dstPos + 3] = (byte) 255;
					}
				}
			}
			return extrapolated;
		}
		private int[] estimateGlobalMotion(byte[] frameA, byte[] frameB) {
			if (frameA == null || frameB == null) return new int[]{0, 0};
			int stride = targetWidth * 4;
			int totalDx = 0, totalDy = 0;
			int count = 0;

			// 8 puntos: esquinas + centro de bordes
			int[] xs = {targetWidth/4, 3*targetWidth/4, targetWidth/2, targetWidth/2, targetWidth/4, 3*targetWidth/4, targetWidth/8, 7*targetWidth/8};
			int[] ys = {targetHeight/4, targetHeight/4, targetHeight/4, 3*targetHeight/4, 3*targetHeight/4, 3*targetHeight/4, targetHeight/2, targetHeight/2};

			for (int i = 0; i < 8; i++) {
				int x = xs[i];
				int y = ys[i];
				if (x <= 0 || y <= 0 || x >= targetWidth - 1 || y >= targetHeight - 1) continue;

				int aIdx = y * stride + x * 4 + 1; // canal G
				if (aIdx + 0 >= frameA.length) continue;

				int ref = frameA[aIdx] & 0xFF;
				int bestSAD = Integer.MAX_VALUE;
				int bestDx = 0, bestDy = 0;

				// Solo 4 offsets: centro, derecha, abajo, diagonal
				int[][] offsets = {{0,0}, {2,0}, {0,2}, {2,2}};
				for (int[] off : offsets) {
					int nx = x + off[0];
					int ny = y + off[1];
					if (nx >= targetWidth || ny >= targetHeight) continue;
					int bIdx = ny * stride + nx * 4 + 1;
					if (bIdx >= frameB.length) continue;
					int sad = Math.abs(ref - (frameB[bIdx] & 0xFF));
					if (sad < bestSAD) {
						bestSAD = sad;
						bestDx = off[0];
						bestDy = off[1];
					}
				}

				// Solo acumular si hubo movimiento detectado (SAD > umbral)
				if (bestSAD < 30) continue; // fondo estático → ignorar
				totalDx += bestDx;
				totalDy += bestDy;
				count++;
			}

			if (count == 0) return new int[]{0, 0};
			return new int[]{ totalDx / count, totalDy / count };
		}

        private byte[] nearestNeighborUpscale(byte[] source, int srcW, int srcH) {
            if (source == null || srcW <= 0 || srcH <= 0) return null;
            byte[] dest = useUpscaleA ? (byte[]) resourceCache.get(KEY_UPSCALE_BUFFER_A) : (byte[]) resourceCache.get(KEY_UPSCALE_BUFFER_B);
            useUpscaleA = !useUpscaleA;
            float invScaleX = (float) srcW / targetWidth;
            float invScaleY = (float) srcH / targetHeight;
            try {
                for (int y = 0; y < targetHeight; y++) {
                    int srcY = (int) (y * invScaleY);
                    if (srcY >= srcH) srcY = srcH - 1;
                    int srcRowBase = srcY * srcW * 4;
                    int dstRowBase = y * targetWidth * 4;
                    for (int x = 0; x < targetWidth; x++) {
                        int srcX = (int) (x * invScaleX);
                        if (srcX >= srcW) srcX = srcW - 1;
                        int srcIdx = srcRowBase + srcX * 4;
                        int dstIdx = dstRowBase + x * 4;
                        if (srcIdx + 3 < source.length && dstIdx + 3 < dest.length) {
                            dest[dstIdx] = source[srcIdx];
                            dest[dstIdx + 1] = source[srcIdx + 1];
                            dest[dstIdx + 2] = source[srcIdx + 2];
                            dest[dstIdx + 3] = (byte) 255;
                        }
                    }
                }
            } catch (Exception e) {
                Log.e(TAG, "Error in nearest neighbor upscale", e);
                return null;
            }
            return dest;
        }

        private void renderToSurface(final byte[] frameData) {
            mainHandler.post(new Runnable() {
					public void run() {
						renderToSurfaceInternal(frameData);
					}
				});
        }

        private void renderToSurfaceInternal(byte[] frameData) {
            if (!isSurfaceValid || overlaySurface == null || !overlaySurface.isValid() || frameData == null || frameData.length != targetWidth * targetHeight * 4)
                return;

            Canvas canvas = null;
            try {
                canvas = overlayView.getHolder().lockCanvas(null);
                if (canvas == null) return;

                // **PASO CLAVE**: Limpiar completamente con negro opaco ANTES de dibujar
                canvas.drawColor(Color.BLACK, PorterDuff.Mode.SRC);

                ByteBuffer byteBuffer = (ByteBuffer) resourceCache.get(KEY_DIRECT_FRAME_BUFFER);
                if (byteBuffer != null) {
                    synchronized (byteBuffer) {
                        byteBuffer.clear();
                        byteBuffer.put(frameData);
                        byteBuffer.flip();
                    }
                }

                Bitmap renderBitmap = (Bitmap) resourceCache.get(KEY_RENDER_BITMAP);
                if (renderBitmap != null && !renderBitmap.isRecycled()) {
                    synchronized (renderBitmap) {
                        if (byteBuffer != null) {
                            renderBitmap.copyPixelsFromBuffer(byteBuffer);
                        }

                        Paint opaquePaint = new Paint();
                        opaquePaint.setAlpha(255);
                        opaquePaint.setFilterBitmap(false);
                        opaquePaint.setAntiAlias(false);
                        opaquePaint.setDither(false);
                        // Asegurar que no hay xfermode que pueda causar transparencia
                        opaquePaint.setXfermode(null);

                        if (fisheyeCorrection != 0) {
                            applyFisheyeCorrection(canvas, renderBitmap);
                        } else {
                            canvas.drawBitmap(renderBitmap, 0, 0, opaquePaint);
                        }
                    }
                }

                lastRenderTime = System.currentTimeMillis();
            } catch (Exception e) {
                Log.e(TAG, "Error rendering to surface", e);
            } finally {
                if (canvas != null) {
                    try {
                        overlayView.getHolder().unlockCanvasAndPost(canvas);
                    } catch (Exception e) {
                        Log.e(TAG, "Error unlocking canvas", e);
                    }
                }
            }
        }

        private void applyFisheyeCorrection(Canvas canvas, Bitmap bitmap) {
            if (bitmap == null || bitmap.isRecycled()) return;
            float centerX = targetWidth / 2f;
            float centerY = targetHeight / 2f;
            float maxRadius = (float) Math.sqrt(centerX * centerX + centerY * centerY);
            float correctionFactor = fisheyeCorrection / 100f;
            int gridSize = 20;
            int vertices = (gridSize + 1) * (gridSize + 1);
            float[] verts = new float[vertices * 2];
            int[] colors = new int[vertices];
            int index = 0;
            for (int y = 0; y <= gridSize; y++) {
                for (int x = 0; x <= gridSize; x++) {
                    float gridX = x * targetWidth / (float) gridSize;
                    float gridY = y * targetHeight / (float) gridSize;
                    float dx = gridX - centerX;
                    float dy = gridY - centerY;
                    float distance = (float) Math.sqrt(dx * dx + dy * dy);
                    if (distance > 0) {
                        float normalizedDist = distance / maxRadius;
                        float correctedDist = normalizedDist * (1 + correctionFactor * normalizedDist * normalizedDist) * maxRadius;
                        float angle = (float) Math.atan2(dy, dx);
                        verts[index * 2] = centerX + correctedDist * (float) Math.cos(angle);
                        verts[index * 2 + 1] = centerY + correctedDist * (float) Math.sin(angle);
                    } else {
                        verts[index * 2] = gridX;
                        verts[index * 2 + 1] = gridY;
                    }
                    colors[index] = Color.TRANSPARENT;
                    index++;
                }
            }
            canvas.drawBitmapMesh(bitmap, gridSize, gridSize, verts, 0, colors, 0, bitmapPaint);
        }

        private class FpsUpdater implements Runnable {
            public void run() {
                if (!running) return;
                long currentTime = System.currentTimeMillis();
                long elapsed = currentTime - lastFpsUpdate.get();
                if (elapsed >= 1000) {
                    currentFps.set((int) (framesProcessed.get() * 1000 / elapsed));
                    lastFpsUpdate.set(currentTime);
                    framesProcessed.set(0);
                    updateNotification();
                }
                processingHandler.postDelayed(this, 250);
            }
        }

        private void saveStats() {
            if (sessionTotalFrames == 0 || sessionStartTime == 0) return;
            long sessionDuration = System.currentTimeMillis() - sessionStartTime;
            int avgFps = (int) (sessionTotalFrames * 1000 / sessionDuration);
            String key = "avg_fps_" + (currentMode == MODEPERFORMANCE ? "performance" : "sifg1");
            int oldAvg = prefs.getInt(key, 0);
            prefs.edit().putInt(key, oldAvg == 0 ? avgFps : (oldAvg + avgFps) / 2).apply();
        }

        public void onDestroy() {
            stopCapture();
            try {
                unregisterReceiver(controlReceiver);
            } catch (Exception e) {
                Log.e(TAG, "Error unregistering receiver", e);
            }
            if (processingThread != null) {
                processingThread.quitSafely();
                try {
                    processingThread.join(500);
                } catch (InterruptedException e) {
                    Log.e(TAG, "Error joining processing thread", e);
                }
            }
            synchronized (resourceCache) {
                Bitmap bmp = (Bitmap) resourceCache.get(KEY_RENDER_BITMAP);
                if (bmp != null) {
                    bmp.recycle();
                }
                resourceCache.clear();
            }
            super.onDestroy();
        }
    }
}
