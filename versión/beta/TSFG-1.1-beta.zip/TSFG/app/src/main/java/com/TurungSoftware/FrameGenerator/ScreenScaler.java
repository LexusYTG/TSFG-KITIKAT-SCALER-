package com.TurungSoftware.FrameGenerator;

import android.accessibilityservice.*;
import android.app.*;
import android.content.*;
import android.content.res.*;
import android.graphics.*;
import android.graphics.SurfaceTexture;
import android.hardware.display.*;
import android.media.*;
import android.media.projection.*;
import android.opengl.GLES20;
import android.os.*;
import android.provider.*;
import android.util.*;
import android.view.*;
import android.view.accessibility.*;
import android.widget.*;
import java.nio.*;
import java.util.*;
import java.util.concurrent.*;
import java.util.concurrent.atomic.*;

import javax.microedition.khronos.egl.EGLConfig;
import javax.microedition.khronos.opengles.GL10;

public class ScreenScaler extends Activity {
    private static final int REQUESTCODECAPTURE = 1001;
    private static final int REQUESTCODEACCESSIBILITY = 1002;
    private static final int REQUESTCODEOVERLAY = 1003;
    private static final String TAG = "ScreenScaler";

    private MediaProjectionManager mpManager;
    private volatile boolean isCapturing = false;

    private LinearLayout controlPanel;
    private TextView statusText;
    private TextView fpsCounter;
    private TextView resolutionText;
    private TextView statsText;
    private TextView sifgInfoText;
    private TextView generationInfoText;
    private Button btnPerformanceMode;
    private Button btnSIFgMode;
    private Button btnResolutionConfig;
    private Button btnFrameGenerationConfig;
    private Button btnColorQualityConfig;
    private Button btnFisheyeCorrection;
    private Button btnStartStop;

    private int sourceWidth = 720;
    private int sourceHeight = 1280;
    private int targetWidth = 1080;
    private int targetHeight = 1920;
    private int screenDensityDpi = 160;
    private int topInset = 0;
    private int bottomInset = 0;
    private float resolutionScale = 0.5f;
    private int framesToGenerate = 1;
    private int colorQuality = 0;
    private int fisheyeCorrection = 0;

    private static final int MODEPERFORMANCE = 0;
    private static final int MODESIFG1 = 1;
    private static final int MODESIFG1_1 = 2;
    private static final int MODE_SIFG_V2 = 3;
    private static final int COLORQUALITY_FULL = 0;
    private static final int COLORQUALITY_8BIT = 1;
    private static final int COLORQUALITY_256 = 2;
    private AtomicInteger currentMode = new AtomicInteger(MODEPERFORMANCE);
    private int sifgVersion = 0;

    private ScreenCaptureService captureService;
    private boolean serviceBound = false;
    private Intent resultData;
    private int resultCode;

    private SharedPreferences prefs;
    private BatteryReceiver batteryReceiver;

    private ServiceConnection serviceConnection = new ServiceConnection() {
        public void onServiceConnected(ComponentName name, IBinder service) {
            ScreenCaptureService.LocalBinder binder = (ScreenCaptureService.LocalBinder) service;
            captureService = binder.getService();
            captureService.setMode(currentMode.get());
            captureService.setSifgVersion(sifgVersion);
            captureService.setResolutionScale(resolutionScale);
            captureService.setFramesToGenerate(framesToGenerate);
            captureService.setColorQuality(colorQuality);
            captureService.setFisheyeCorrection(fisheyeCorrection);
            serviceBound = true;
            if (resultData != null && resultCode == RESULT_OK) {
                startCaptureInternal();
            }
        }

        public void onServiceDisconnected(ComponentName name) {
            serviceBound = false;
            captureService = null;
        }
    };

    private Handler fpsHandler = new Handler();
    private Runnable fpsRunnable = new Runnable() {
        public void run() {
            if (captureService != null && isCapturing) {
                int fps = captureService.getFps();
                int frames = captureService.getTotalFrames();
                int dropped = captureService.getDroppedFrames();
                fpsCounter.setText("FPS: " + fps + " | Frames: " + frames + " | Perdidos: " + dropped);
            }
            fpsHandler.postDelayed(this, 1000);
        }
    };

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);

        prefs = getSharedPreferences("ScreenScalerStats", MODE_PRIVATE);

        DisplayMetrics metrics = new DisplayMetrics();
        getWindowManager().getDefaultDisplay().getRealMetrics(metrics);
        screenDensityDpi = metrics.densityDpi;

        if (Build.VERSION.SDK_INT >= 28) {
            View decorView = getWindow().getDecorView();
            decorView.setOnApplyWindowInsetsListener(new View.OnApplyWindowInsetsListener() {
					public WindowInsets onApplyWindowInsets(View v, WindowInsets insets) {
						if (Build.VERSION.SDK_INT >= 28) {
							android.graphics.Insets cutout = insets.getDisplayCutout() != null ? 
								android.graphics.Insets.of(
								insets.getDisplayCutout().getSafeInsetLeft(),
								insets.getDisplayCutout().getSafeInsetTop(),
								insets.getDisplayCutout().getSafeInsetRight(),
								insets.getDisplayCutout().getSafeInsetBottom()
							) : android.graphics.Insets.NONE;
							topInset = cutout.top;
							bottomInset = cutout.bottom;
						}
						return insets;
					}
				});
        }

        resolutionScale = prefs.getFloat("resolution_scale", 0.5f);
        framesToGenerate = prefs.getInt("frames_to_generate", 1);
        colorQuality = prefs.getInt("color_quality", COLORQUALITY_FULL);
        fisheyeCorrection = prefs.getInt("fisheye_correction", 0);
        sifgVersion = prefs.getInt("sifg_version", 0);
        adjustResolutions(metrics);
        createUI();
        loadStats();

        mpManager = (MediaProjectionManager) getSystemService(Context.MEDIA_PROJECTION_SERVICE);

        Intent serviceIntent = new Intent(this, ScreenCaptureService.class);
        if (Build.VERSION.SDK_INT >= 26) {
            startForegroundService(serviceIntent);
        } else {
            startService(serviceIntent);
        }
        bindService(serviceIntent, serviceConnection, Context.BIND_AUTO_CREATE);

        batteryReceiver = new BatteryReceiver();
        IntentFilter filter = new IntentFilter(Intent.ACTION_BATTERY_CHANGED);
        registerReceiver(batteryReceiver, filter);
    }

    private void adjustResolutions(DisplayMetrics metrics) {
		int screenWidth = metrics.widthPixels;
		int screenHeight = metrics.heightPixels;

		targetWidth = (screenWidth / 8) * 8;
		targetHeight = (screenHeight / 8) * 8;

		sourceWidth = (int) (targetWidth * resolutionScale);
		sourceHeight = (int) (targetHeight * resolutionScale);

		sourceWidth = (sourceWidth / 8) * 8;
		sourceHeight = (sourceHeight / 8) * 8;

		if (sourceWidth < 8) sourceWidth = 8;
		if (sourceHeight < 8) sourceHeight = 8;

		Log.d(TAG, "Resoluciones: Fuente=" + sourceWidth + "x" + sourceHeight + 
			  ", Destino=" + targetWidth + "x" + targetHeight);
	}

    private void createUI() {
        LinearLayout mainLayout = new LinearLayout(this);
        mainLayout.setOrientation(LinearLayout.VERTICAL);
        mainLayout.setLayoutParams(new LinearLayout.LayoutParams(
                                       LinearLayout.LayoutParams.MATCH_PARENT,
                                       LinearLayout.LayoutParams.MATCH_PARENT));
        mainLayout.setPadding(16, 16, 16, 16);
        mainLayout.setBackgroundColor(Color.BLACK);

        controlPanel = new LinearLayout(this);
        controlPanel.setOrientation(LinearLayout.VERTICAL);
        controlPanel.setLayoutParams(new LinearLayout.LayoutParams(
                                         LinearLayout.LayoutParams.MATCH_PARENT,
                                         LinearLayout.LayoutParams.WRAP_CONTENT));
        controlPanel.setBackgroundColor(Color.rgb(32, 32, 32));
        controlPanel.setPadding(12, 12, 12, 12);

        TextView title = new TextView(this);
        title.setText("Frame Generator Pro v1.0");
        title.setTextSize(22);
        title.setTextColor(Color.WHITE);
        title.setGravity(Gravity.CENTER);
        title.setPadding(0, 0, 0, 16);
        controlPanel.addView(title);

        resolutionText = new TextView(this);
        updateResolutionText();
        resolutionText.setTextSize(12);
        resolutionText.setTextColor(Color.LTGRAY);
        resolutionText.setGravity(Gravity.CENTER);
        resolutionText.setPadding(0, 0, 0, 12);
        controlPanel.addView(resolutionText);

        LinearLayout modeLayout = new LinearLayout(this);
        modeLayout.setOrientation(LinearLayout.HORIZONTAL);
        modeLayout.setLayoutParams(new LinearLayout.LayoutParams(
                                       LinearLayout.LayoutParams.MATCH_PARENT,
                                       LinearLayout.LayoutParams.WRAP_CONTENT));

        btnPerformanceMode = createModeButton("Rendimiento", MODEPERFORMANCE);
        btnSIFgMode = createModeButton("SIFg", MODESIFG1);

        modeLayout.addView(btnPerformanceMode);
        modeLayout.addView(btnSIFgMode);
        controlPanel.addView(modeLayout);

        LinearLayout configLayout = new LinearLayout(this);
        configLayout.setOrientation(LinearLayout.HORIZONTAL);
        configLayout.setLayoutParams(new LinearLayout.LayoutParams(
                                         LinearLayout.LayoutParams.MATCH_PARENT,
                                         LinearLayout.LayoutParams.WRAP_CONTENT));
        configLayout.setPadding(0, 8, 0, 0);

        btnFrameGenerationConfig = createConfigButton("Gen: " + framesToGenerate, new View.OnClickListener() {
				public void onClick(View v) {
					showFrameGenerationDialog();
				}
			});
        btnColorQualityConfig = createConfigButton(getColorQualityText(), new View.OnClickListener() {
				public void onClick(View v) {
					showColorQualityDialog();
				}
			});
        btnResolutionConfig = createResolutionButton();
        btnFisheyeCorrection = createFisheyeButton();

        configLayout.addView(btnFrameGenerationConfig);
        configLayout.addView(btnColorQualityConfig);
        configLayout.addView(btnResolutionConfig);
        configLayout.addView(btnFisheyeCorrection);
        controlPanel.addView(configLayout);

        btnStartStop = new Button(this);
        btnStartStop.setText("INICIAR CAPTURA");
        btnStartStop.setTextSize(16);
        btnStartStop.setBackgroundColor(Color.rgb(0, 120, 215));
        btnStartStop.setTextColor(Color.WHITE);
        btnStartStop.setLayoutParams(new LinearLayout.LayoutParams(
                                         LinearLayout.LayoutParams.MATCH_PARENT,
                                         LinearLayout.LayoutParams.WRAP_CONTENT));
        LinearLayout.LayoutParams btnParams = (LinearLayout.LayoutParams) btnStartStop.getLayoutParams();
        btnParams.setMargins(0, 12, 0, 0);
        btnStartStop.setLayoutParams(btnParams);
        btnStartStop.setOnClickListener(new View.OnClickListener() {
				public void onClick(View v) {
					if (!isCapturing) {
						startCapture();
					} else {
						stopCapture();
					}
				}
			});
        controlPanel.addView(btnStartStop);

        LinearLayout statsLayout = new LinearLayout(this);
        statsLayout.setOrientation(LinearLayout.VERTICAL);
        statsLayout.setLayoutParams(new LinearLayout.LayoutParams(
                                        LinearLayout.LayoutParams.MATCH_PARENT,
                                        LinearLayout.LayoutParams.WRAP_CONTENT));
        statsLayout.setPadding(0, 12, 0, 0);

        statusText = new TextView(this);
        statusText.setText("Modo: Rendimiento");
        statusText.setTextSize(14);
        statusText.setTextColor(Color.WHITE);
        statusText.setLayoutParams(new LinearLayout.LayoutParams(
                                       LinearLayout.LayoutParams.MATCH_PARENT,
                                       LinearLayout.LayoutParams.WRAP_CONTENT));
        statsLayout.addView(statusText);

        sifgInfoText = new TextView(this);
        sifgInfoText.setText("");
        sifgInfoText.setTextSize(11);
        sifgInfoText.setTextColor(Color.CYAN);
        sifgInfoText.setLayoutParams(new LinearLayout.LayoutParams(
                                         LinearLayout.LayoutParams.MATCH_PARENT,
                                         LinearLayout.LayoutParams.WRAP_CONTENT));
        statsLayout.addView(sifgInfoText);

        generationInfoText = new TextView(this);
        generationInfoText.setText("Frames generados: " + framesToGenerate + " | Calidad: " + getColorQualityText());
        generationInfoText.setTextSize(10);
        generationInfoText.setTextColor(Color.LTGRAY);
        generationInfoText.setLayoutParams(new LinearLayout.LayoutParams(
                                               LinearLayout.LayoutParams.MATCH_PARENT,
                                               LinearLayout.LayoutParams.WRAP_CONTENT));
        statsLayout.addView(generationInfoText);

        fpsCounter = new TextView(this);
        fpsCounter.setText("FPS: 0 | Frames: 0 | Perdidos: 0");
        fpsCounter.setTextSize(12);
        fpsCounter.setTextColor(Color.LTGRAY);
        fpsCounter.setLayoutParams(new LinearLayout.LayoutParams(
                                       LinearLayout.LayoutParams.MATCH_PARENT,
                                       LinearLayout.LayoutParams.WRAP_CONTENT));
        statsLayout.addView(fpsCounter);

        statsText = new TextView(this);
        statsText.setText("");
        statsText.setTextSize(11);
        statsText.setTextColor(Color.YELLOW);
        statsText.setLayoutParams(new LinearLayout.LayoutParams(
                                      LinearLayout.LayoutParams.MATCH_PARENT,
                                      LinearLayout.LayoutParams.WRAP_CONTENT));
        statsLayout.addView(statsText);

        controlPanel.addView(statsLayout);

        mainLayout.addView(controlPanel);
        setContentView(mainLayout);
        setMode(MODEPERFORMANCE);
    }

    private Button createResolutionButton() {
        Button btn = new Button(this);
        btn.setText("Res: " + (int)(resolutionScale * 100) + "%");
        btn.setTextSize(12);
        btn.setLayoutParams(new LinearLayout.LayoutParams(0,
                                                          LinearLayout.LayoutParams.WRAP_CONTENT, 1));
        LinearLayout.LayoutParams params = (LinearLayout.LayoutParams) btn.getLayoutParams();
        params.setMargins(4, 0, 4, 0);
        btn.setLayoutParams(params);
        btn.setOnClickListener(new View.OnClickListener() {
				public void onClick(View v) {
					showResolutionDialog();
				}
			});
        return btn;
    }

    private Button createFisheyeButton() {
        Button btn = new Button(this);
        btn.setText("FishEye: " + fisheyeCorrection);
        btn.setTextSize(11);
        btn.setLayoutParams(new LinearLayout.LayoutParams(0,
                                                          LinearLayout.LayoutParams.WRAP_CONTENT, 1));
        LinearLayout.LayoutParams params = (LinearLayout.LayoutParams) btn.getLayoutParams();
        params.setMargins(4, 0, 4, 0);
        btn.setLayoutParams(params);
        btn.setOnClickListener(new View.OnClickListener() {
				public void onClick(View v) {
					showFisheyeDialog();
				}
			});
        return btn;
    }

    private Button createModeButton(final String text, final int mode) {
        Button btn = new Button(this);
        btn.setText(text);
        btn.setTextSize(12);
        btn.setLayoutParams(new LinearLayout.LayoutParams(0,
                                                          LinearLayout.LayoutParams.WRAP_CONTENT, 1));
        LinearLayout.LayoutParams params = (LinearLayout.LayoutParams) btn.getLayoutParams();
        params.setMargins(4, 0, 4, 0);
        btn.setLayoutParams(params);
        btn.setOnClickListener(new View.OnClickListener() {
				public void onClick(View v) {
					if (mode == MODESIFG1) {
						showSIFgVersionDialog();
					} else {
						setMode(mode);
					}
				}
			});
        return btn;
    }

    private Button createConfigButton(String text, View.OnClickListener listener) {
        Button btn = new Button(this);
        btn.setText(text);
        btn.setTextSize(11);
        btn.setLayoutParams(new LinearLayout.LayoutParams(0,
                                                          LinearLayout.LayoutParams.WRAP_CONTENT, 1));
        LinearLayout.LayoutParams params = (LinearLayout.LayoutParams) btn.getLayoutParams();
        params.setMargins(4, 0, 4, 0);
        btn.setLayoutParams(params);
        btn.setOnClickListener(listener);
        return btn;
    }

    private void showSIFgVersionDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Selecciona versión SIFg");
        final String[] options = {"v1.0 (Directo)", "v1.1 (Interpolado rápido)", "v2.0 (GPU Accelerated)"};
        final int[] versions = {0, 1, 2};
        builder.setItems(options, new android.content.DialogInterface.OnClickListener() {
				public void onClick(android.content.DialogInterface dialog, int which) {
					sifgVersion = versions[which];
					prefs.edit().putInt("sifg_version", sifgVersion).apply();
					setMode(MODESIFG1);
				}
			});
        builder.show();
    }

    private void showFisheyeDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Corrección Efecto Ojo de Pez");

        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);
        layout.setPadding(32, 16, 32, 16);

        final SeekBar seekBar = new SeekBar(this);
        seekBar.setMax(200);
        seekBar.setProgress(fisheyeCorrection + 100);

        final TextView valueLabel = new TextView(this);
        valueLabel.setText("Factor: " + (fisheyeCorrection > 0 ? "+" : "") + fisheyeCorrection);
        valueLabel.setGravity(Gravity.CENTER);
        valueLabel.setPadding(0, 16, 0, 0);

        seekBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
				public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
					int value = progress - 100;
					valueLabel.setText("Factor: " + (value > 0 ? "+" : "") + value);
				}

				public void onStartTrackingTouch(SeekBar seekBar) {}
				public void onStopTrackingTouch(SeekBar seekBar) {}
			});

        layout.addView(seekBar);
        layout.addView(valueLabel);
        builder.setView(layout);

        builder.setPositiveButton("Aplicar", new android.content.DialogInterface.OnClickListener() {
				public void onClick(android.content.DialogInterface dialog, int which) {
					fisheyeCorrection = seekBar.getProgress() - 100;
					prefs.edit().putInt("fisheye_correction", fisheyeCorrection).apply();
					btnFisheyeCorrection.setText("FishEye: " + (fisheyeCorrection > 0 ? "+" : "") + fisheyeCorrection);
					if (captureService != null && isCapturing) {
						captureService.setFisheyeCorrection(fisheyeCorrection);
					}
				}
			});

        builder.setNegativeButton("Cancelar", null);
        builder.show();
    }

    private void showResolutionDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Selecciona resolución de captura");
        final String[] options = {"25% (Máx velocidad)", "50% (Balance)", "75% (Más calidad)"};
        final float[] scales = {0.25f, 0.5f, 0.75f};
        builder.setItems(options, new android.content.DialogInterface.OnClickListener() {
				public void onClick(android.content.DialogInterface dialog, int which) {
					resolutionScale = scales[which];
					prefs.edit().putFloat("resolution_scale", resolutionScale).apply();
					btnResolutionConfig.setText("Res: " + (int)(resolutionScale * 100) + "%");
					DisplayMetrics metrics = new DisplayMetrics();
					getWindowManager().getDefaultDisplay().getRealMetrics(metrics);
					adjustResolutions(metrics);
					updateResolutionText();
					if (captureService != null && isCapturing) {
						captureService.updateResolution(sourceWidth, sourceHeight, targetWidth, targetHeight);
						captureService.setResolutionScale(resolutionScale);
					}
				}
			});
        builder.show();
    }

    private void showFrameGenerationDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Frames a generar entre frames reales");
        final String[] options = {"1 (2x FPS)", "2 (3x FPS)", "3 (4x FPS)", "4 (5x FPS)"};
        final int[] values = {1, 2, 3, 4};
        builder.setItems(options, new android.content.DialogInterface.OnClickListener() {
				public void onClick(android.content.DialogInterface dialog, int which) {
					framesToGenerate = values[which];
					prefs.edit().putInt("frames_to_generate", framesToGenerate).apply();
					btnFrameGenerationConfig.setText("Gen: " + framesToGenerate);
					generationInfoText.setText("Frames generados: " + framesToGenerate + " | Calidad: " + getColorQualityText());
					if (captureService != null && isCapturing) {
						captureService.setFramesToGenerate(framesToGenerate);
					}
				}
			});
        builder.show();
    }

    private void showColorQualityDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Calidad de color");
        final String[] options = {"Completa (24-bit)", "8-bit (Retro)", "256 colores (Paletizado)"};
        builder.setItems(options, new android.content.DialogInterface.OnClickListener() {
				public void onClick(android.content.DialogInterface dialog, int which) {
					colorQuality = which;
					prefs.edit().putInt("color_quality", colorQuality).apply();
					btnColorQualityConfig.setText(getColorQualityText());
					generationInfoText.setText("Frames generados: " + framesToGenerate + " | Calidad: " + getColorQualityText());
					if (captureService != null && isCapturing) {
						captureService.setColorQuality(colorQuality);
					}
				}
			});
        builder.show();
    }

    private String getColorQualityText() {
        switch (colorQuality) {
            case COLORQUALITY_FULL: return "Full";
            case COLORQUALITY_8BIT: return "8-bit";
            case COLORQUALITY_256: return "256c";
            default: return "Full";
        }
    }

    private void updateResolutionText() {
        resolutionText.setText("Captura: " + sourceWidth + "x" + sourceHeight +
                               " | Salida: " + targetWidth + "x" + targetHeight +
                               " | Escala: " + (int)(resolutionScale * 100) + "%");
    }

    private void setMode(int mode) {
        currentMode.set(mode);
        String modeText;
        String sifgInfo = "";
        int highlightColor = Color.rgb(0, 150, 0);
        int normalColor = Color.rgb(64, 64, 64);

        btnPerformanceMode.setBackgroundColor(normalColor);
        btnSIFgMode.setBackgroundColor(normalColor);

        switch (mode) {
            case MODEPERFORMANCE:
                modeText = "Rendimiento (Directo)";
                btnPerformanceMode.setBackgroundColor(highlightColor);
                break;
            case MODESIFG1:
                if (sifgVersion == 0) {
                    modeText = "SIFg v1.0";
                    sifgInfo = "Generación desde un solo frame (sin ghosting)";
                } else if (sifgVersion == 1) {
                    modeText = "SIFg v1.1";
                    sifgInfo = "Generación interpolada rápida (anti-stutter)";
                } else {
                    modeText = "SIFg v2.0";
                    sifgInfo = "GPU Accelerated (OpenGL ES)";
                }
                btnSIFgMode.setBackgroundColor(highlightColor);
                break;
            default:
                modeText = "Rendimiento";
                btnPerformanceMode.setBackgroundColor(highlightColor);
                break;
        }
        statusText.setText("Modo: " + modeText);
        sifgInfoText.setText(sifgInfo);
        if (captureService != null) {
            captureService.setMode(mode);
            captureService.setSifgVersion(sifgVersion);
        }
    }

    private void startCapture() {
        if (!isAccessibilityServiceEnabled()) {
            Toast.makeText(this, "Habilitando servicio de accesibilidad...", Toast.LENGTH_LONG).show();
            Intent intent = new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS);
            startActivityForResult(intent, REQUESTCODEACCESSIBILITY);
            return;
        }

        if (Build.VERSION.SDK_INT >= 23 && !Settings.canDrawOverlays(this)) {
            Toast.makeText(this, "Habilitando permisos de superposición...", Toast.LENGTH_LONG).show();
            Intent intent = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION);
            startActivityForResult(intent, REQUESTCODEOVERLAY);
            return;
        }

        if (mpManager == null) {
            Toast.makeText(this, "Error: MediaProjectionManager no disponible", Toast.LENGTH_SHORT).show();
            return;
        }

        Intent captureIntent = mpManager.createScreenCaptureIntent();
        startActivityForResult(captureIntent, REQUESTCODECAPTURE);
    }

    private boolean isAccessibilityServiceEnabled() {
        int enabled = 0;
        try {
            enabled = Settings.Secure.getInt(getContentResolver(),
                                             Settings.Secure.ACCESSIBILITY_ENABLED);
        } catch (Settings.SettingNotFoundException e) {
            return false;
        }
        if (enabled == 1) {
            String services = Settings.Secure.getString(getContentResolver(),
                                                        Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES);
            if (services != null) {
                String ourService = getPackageName() + "/" + TouchForwardService.class.getName();
                return services.contains(ourService);
            }
        }
        return false;
    }

    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (requestCode == REQUESTCODEACCESSIBILITY) {
            if (isAccessibilityServiceEnabled()) {
                Toast.makeText(this, "Servicio de accesibilidad habilitado. Ahora inicia la captura.",
                               Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(this, "Debes habilitar el servicio de accesibilidad para continuar",
                               Toast.LENGTH_LONG).show();
            }
        } else if (requestCode == REQUESTCODEOVERLAY) {
            if (Build.VERSION.SDK_INT >= 23 && Settings.canDrawOverlays(this)) {
                Toast.makeText(this, "Permisos de superposición concedidos. Ahora inicia la captura.",
                               Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(this, "Debes habilitar los permisos de superposición para continuar",
                               Toast.LENGTH_LONG).show();
            }
        } else if (requestCode == REQUESTCODECAPTURE) {
            if (resultCode == RESULT_OK && data != null) {
                this.resultCode = resultCode;
                this.resultData = data;
                startCaptureInternal();
            } else {
                Toast.makeText(this, "Permiso de captura denegado", Toast.LENGTH_SHORT).show();
            }
        }
    }

    private void startCaptureInternal() {
        if (serviceBound && captureService != null && resultData != null) {
            captureService.startCapture(resultCode, resultData, sourceWidth, sourceHeight,
                                        targetWidth, targetHeight, screenDensityDpi, topInset, bottomInset);
            isCapturing = true;
            hideControlsAndStartOverlay();
            startFpsMonitor();
        }
    }

    private void hideControlsAndStartOverlay() {
        runOnUiThread(new Runnable() {
				public void run() {
					controlPanel.setVisibility(View.GONE);
					moveTaskToBack(true);
					Toast.makeText(ScreenScaler.this,
								   "Captura iniciada - Overlay activo",
								   Toast.LENGTH_SHORT).show();
				}
			});
    }

    private void stopCapture() {
        if (captureService != null) {
            captureService.stopCapture();
        }
        isCapturing = false;
        fpsHandler.removeCallbacks(fpsRunnable);
        runOnUiThread(new Runnable() {
				public void run() {
					controlPanel.setVisibility(View.VISIBLE);
					fpsCounter.setText("FPS: 0 | Frames: 0 | Perdidos: 0");
				}
			});
    }

    private void startFpsMonitor() {
        fpsHandler.removeCallbacks(fpsRunnable);
        fpsHandler.post(fpsRunnable);
    }

    private void loadStats() {
        int avgPerformance = prefs.getInt("avg_fps_performance", 0);
        int avgSIFG1 = prefs.getInt("avg_fps_sifg1", 0);

        String stats = "Estadísticas del dispositivo:\n";
        if (avgPerformance > 0) stats += "Rendimiento: " + avgPerformance + " FPS | ";
        if (avgSIFG1 > 0) stats += "SIFg1: " + avgSIFG1 + " FPS";

        if (avgPerformance > 0 || avgSIFG1 > 0) {
            statsText.setText(stats);
        }
    }

    public void onBackPressed() {
        if (isCapturing) {
            Toast.makeText(this, "Deteniendo captura...", Toast.LENGTH_SHORT).show();
            stopCapture();
        } else {
            super.onBackPressed();
        }
    }

    public void onConfigurationChanged(Configuration newConfig) {
        super.onConfigurationChanged(newConfig);
        DisplayMetrics metrics = new DisplayMetrics();
        getWindowManager().getDefaultDisplay().getRealMetrics(metrics);
        adjustResolutions(metrics);
        if (resolutionText != null) {
            updateResolutionText();
        }
        if (captureService != null && isCapturing) {
            captureService.updateResolution(sourceWidth, sourceHeight, targetWidth, targetHeight);
        }
    }

    protected void onDestroy() {
        if (batteryReceiver != null) {
            unregisterReceiver(batteryReceiver);
        }
        fpsHandler.removeCallbacks(fpsRunnable);

        if (serviceBound) {
            unbindService(serviceConnection);
            serviceBound = false;
        }

        super.onDestroy();
    }

    private class BatteryReceiver extends BroadcastReceiver {
        public void onReceive(Context context, Intent intent) {
            int level = intent.getIntExtra(BatteryManager.EXTRA_LEVEL, -1);
            int scale = intent.getIntExtra(BatteryManager.EXTRA_SCALE, -1);
            float batteryPct = level / (float)scale * 100;

            if (batteryPct < 15 && currentMode.get() != MODEPERFORMANCE && isCapturing) {
                setMode(MODEPERFORMANCE);
                Toast.makeText(context, "Batería baja: Modo Rendimiento activado", Toast.LENGTH_SHORT).show();
            }
        }
    }

    public static class TouchForwardService extends AccessibilityService {
        private static TouchForwardService instance;
        private static List<MotionEvent> eventQueue = new ArrayList<MotionEvent>();

        public void onAccessibilityEvent(AccessibilityEvent event) {
        }

        public void onInterrupt() {
        }

        protected void onServiceConnected() {
            super.onServiceConnected();
            instance = this;
            android.os.Process.setThreadPriority(android.os.Process.THREAD_PRIORITY_URGENT_DISPLAY);
        }

        public void onDestroy() {
            instance = null;
            super.onDestroy();
        }

        public static boolean isRunning() {
            return instance != null;
        }

        public static void dispatchTouch(MotionEvent event) {
            if (instance != null && Build.VERSION.SDK_INT >= 24) {
                instance.performTouch(event);
            }
        }

        private void performTouch(MotionEvent event) {
            if (Build.VERSION.SDK_INT < 24) return;

            try {
                int pointerCount = event.getPointerCount();
                GestureDescription.Builder builder = new GestureDescription.Builder();

                for (int i = 0; i < pointerCount; i++) {
                    int pointerId = event.getPointerId(i);
                    float x = event.getX(i);
                    float y = event.getY(i);

                    Path path = new Path();
                    path.moveTo(x, y);

                    GestureDescription.StrokeDescription stroke = null;

                    switch (event.getActionMasked()) {
                        case MotionEvent.ACTION_DOWN:
                        case MotionEvent.ACTION_POINTER_DOWN:
                        case MotionEvent.ACTION_MOVE:
                            stroke = new GestureDescription.StrokeDescription(path, 0, 100, true);
                            break;
                        case MotionEvent.ACTION_UP:
                        case MotionEvent.ACTION_POINTER_UP:
                            stroke = new GestureDescription.StrokeDescription(path, 0, 1);
                            break;
                    }

                    if (stroke != null) {
                        builder.addStroke(stroke);
                    }
                }

                GestureDescription gesture = builder.build();
                dispatchGesture(gesture, null, null);

            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }

    public static class ScreenCaptureService extends Service {
        private static final int NOTIFICATIONID = 1001;
        private static final String CHANNELID = "ScreenCaptureChannel";
        private static final String ACTION_STOP = "com.TurungSoftware.FrameGenerator.STOP";

        private MediaProjection projection;
        private VirtualDisplay virtualDisplay;
        private ImageReader imageReader;
        private HandlerThread processingThread;
        private Handler processingHandler;
        private volatile boolean running = false;
        private int currentMode = MODEPERFORMANCE;
        private int sifgVersion = 0;
        private float resolutionScale = 0.5f;
        private int framesToGenerate = 1;
        private int colorQuality = COLORQUALITY_FULL;
        private int fisheyeCorrection = 0;
        private boolean useSingleFrameGen = false;
        private boolean useGpuAcceleration = false;
        private int sourceWidth, sourceHeight, targetWidth, targetHeight;
        private int topInset = 0;
        private int bottomInset = 0;

        private AtomicInteger framesProcessed = new AtomicInteger(0);
        private AtomicLong lastFpsUpdate = new AtomicLong(0);
        private AtomicInteger droppedFrames = new AtomicInteger(0);
        private AtomicInteger currentFps = new AtomicInteger(0);
        private AtomicInteger captureErrorCount = new AtomicInteger(0);

        private byte[] bufferPool1, bufferPool2;
        private byte[] prevFrameBuffer, currentFrameBuffer;

        private android.graphics.Paint bitmapPaint;
        private Paint clearPaint;

        private long[] hashSamples = new long[10];
        private int hashSampleIndex = 0;

        private Bitmap renderBitmap;
        private int[] xMapping, yMapping;
        private float[] xWeights, yWeights;

        private WindowManager windowManager;
        private SurfaceView overlayView;
        private Surface overlaySurface;
        private GLFrameProcessor glProcessor;

        private long lastFrameHash = 0;
        private int staticFrameCount = 0;
        private byte[] cachedStaticFrame = null;

        private SharedPreferences prefs;
        private long sessionStartTime = 0;
        private int sessionTotalFrames = 0;
		private byte[] lastRealFrame = null;
		private long[] motionVector = new long[2];

		private byte[] fastFramePrediction() {
			if (lastRealFrame == null) return null;

			byte[] predicted = bufferPool1;

			System.arraycopy(lastRealFrame, 0, predicted, 0, lastRealFrame.length);

			fastBlur(predicted, targetWidth, targetHeight, 1);

			return predicted;
		}

		private void fastBlur(byte[] pixels, int width, int height, int radius) {
			for (int i = width * 4 + 4; i < pixels.length - width * 4 - 4; i += 4) {
				int r = ((pixels[i] & 0xFF) + (pixels[i-4] & 0xFF) + 
					(pixels[i+4] & 0xFF) + (pixels[i+width*4] & 0xFF)) >> 2;
				int g = ((pixels[i+1] & 0xFF) + (pixels[i-3] & 0xFF) + 
					(pixels[i+5] & 0xFF) + (pixels[i+width*4+1] & 0xFF)) >> 2;
				int b = ((pixels[i+2] & 0xFF) + (pixels[i-2] & 0xFF) + 
					(pixels[i+6] & 0xFF) + (pixels[i+width*4+2] & 0xFF)) >> 2;

				pixels[i] = (byte)r;
				pixels[i+1] = (byte)g;
				pixels[i+2] = (byte)b;
			}
		}

        private final IBinder binder = new LocalBinder();

        private BroadcastReceiver controlReceiver = new BroadcastReceiver() {
            public void onReceive(Context context, Intent intent) {
                String action = intent.getAction();
                if (ACTION_STOP.equals(action)) {
                    stopCapture();
                }
            }
        };

        public class LocalBinder extends Binder {
            ScreenCaptureService getService() {
                return ScreenCaptureService.this;
            }
        }

        public IBinder onBind(Intent intent) {
            return binder;
        }

        public void onCreate() {
            super.onCreate();
            processingThread = new HandlerThread("ScalerThread", android.os.Process.THREAD_PRIORITY_URGENT_DISPLAY);
            processingThread.start();
            processingHandler = new Handler(processingThread.getLooper());

            android.os.Process.setThreadPriority(android.os.Process.THREAD_PRIORITY_URGENT_DISPLAY);

            prefs = getSharedPreferences("ScreenScalerStats", MODE_PRIVATE);

            createNotificationChannel();

            IntentFilter filter = new IntentFilter();
            filter.addAction(ACTION_STOP);
            registerReceiver(controlReceiver, filter);
        }

        private void createNotificationChannel() {
            if (Build.VERSION.SDK_INT >= 26) {
                NotificationChannel channel = new NotificationChannel(CHANNELID, "Screen Capture Service", NotificationManager.IMPORTANCE_LOW);
                channel.setDescription("Servicio de captura de pantalla activo");
                NotificationManager manager = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
                if (manager != null) {
                    manager.createNotificationChannel(channel);
                }
            }
        }

        private Notification createNotification() {
            Intent stopIntent = new Intent(ACTION_STOP);

            PendingIntent stopPending;

            if (Build.VERSION.SDK_INT >= 31) {
                stopPending = PendingIntent.getBroadcast(this, 2, stopIntent, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
            } else {
                stopPending = PendingIntent.getBroadcast(this, 2, stopIntent, 0);
            }

            Notification notification;
            if (Build.VERSION.SDK_INT >= 26) {
                Notification.Builder builder = new Notification.Builder(this, CHANNELID)
                    .setContentTitle("Frame Generator Pro")
                    .setContentText("Captura activa - FPS: " + currentFps.get())
                    .setSmallIcon(android.R.drawable.ic_menu_camera)
                    .addAction(android.R.drawable.ic_menu_close_clear_cancel, "Detener", stopPending);
                notification = builder.build();
            } else {
                Notification.Builder builder = new Notification.Builder(this)
                    .setContentTitle("Frame Generator Pro")
                    .setContentText("Captura activa - FPS: " + currentFps.get())
                    .setSmallIcon(android.R.drawable.ic_menu_camera)
                    .addAction(android.R.drawable.ic_menu_close_clear_cancel, "Detener", stopPending);
                notification = builder.build();
            }
            return notification;
        }

        private void updateNotification() {
            NotificationManager manager = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
            if (manager != null) {
                manager.notify(NOTIFICATIONID, createNotification());
            }
        }

        public void setMode(int mode) {
            this.currentMode = mode;
            this.useSingleFrameGen = (mode == MODESIFG1);
            this.useGpuAcceleration = (mode == MODESIFG1 && sifgVersion == 2);

            Arrays.fill(hashSamples, 0);
            staticFrameCount = 0;
            lastFrameHash = 0;
        }

        public void setSifgVersion(int version) {
            this.sifgVersion = version;
            this.useGpuAcceleration = (version == 2);
        }

        public void setResolutionScale(float scale) {
            this.resolutionScale = scale;
        }

        public void setFramesToGenerate(int count) {
            this.framesToGenerate = Math.max(1, Math.min(4, count));
        }

        public void setColorQuality(int quality) {
            this.colorQuality = quality;
        }

        public void setFisheyeCorrection(int correction) {
            this.fisheyeCorrection = correction;
        }

        public int getFps() { return currentFps.get(); }
        public int getTotalFrames() { return framesProcessed.get(); }
        public int getDroppedFrames() { return droppedFrames.get(); }

        public void updateResolution(int srcW, int srcH, int tgtW, int tgtH) {
            this.sourceWidth = srcW;
            this.sourceHeight = srcH;
            this.targetWidth = tgtW;
            this.targetHeight = tgtH;
            initializeBufferPools();
            precalculateMappings();
        }

        public void startCapture(int resultCode, Intent data, int srcW, int srcH, int tgtW, int tgtH, int dpi, int topInset, int bottomInset) {
            if (running) return;

            this.sourceWidth = srcW;
            this.sourceHeight = srcH;
            this.targetWidth = tgtW;
            this.targetHeight = tgtH;
            this.topInset = topInset;
            this.bottomInset = bottomInset;

            initializeBufferPools();
            precalculateMappings();

            if (useGpuAcceleration) {
                glProcessor = new GLFrameProcessor(targetWidth, targetHeight, fisheyeCorrection);
            }

            createOverlayWindow();

            try {
                startForeground(NOTIFICATIONID, createNotification());

                MediaProjectionManager mpManager = (MediaProjectionManager)
                    getSystemService(Context.MEDIA_PROJECTION_SERVICE);
                projection = mpManager.getMediaProjection(resultCode, data);
                if (projection == null) return;

                imageReader = ImageReader.newInstance(sourceWidth, sourceHeight, PixelFormat.RGBA_8888, 3);
                virtualDisplay = projection.createVirtualDisplay("ScreenScaler", sourceWidth, sourceHeight, dpi,
                                                                 DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
                                                                 imageReader.getSurface(), null, processingHandler);

                running = true;
                sessionStartTime = System.currentTimeMillis();
                sessionTotalFrames = 0;
                lastFpsUpdate.set(System.currentTimeMillis());
                framesProcessed.set(0);
                droppedFrames.set(0);
                processingHandler.post(new FpsUpdater());

                imageReader.setOnImageAvailableListener(new ImageReader.OnImageAvailableListener() {
						public void onImageAvailable(ImageReader reader) {
							if (!running) return;

							Image image = null;
							try {
								image = reader.acquireLatestImage();
								if (image != null && running) {
									captureErrorCount.set(0);
									if (useSingleFrameGen) {
										if (sifgVersion == 0) {
											processingHandler.post(new SIFgV1FrameGenerator(image));
										} else if (sifgVersion == 1) {
											processingHandler.post(new SIFgV1_1FrameGenerator(image));
										} else if (sifgVersion == 2) {
											processingHandler.post(new SIFgV2FrameGenerator(image));
										}
									} else {
										processingHandler.post(new FrameProcessor(image));
									}
								}
							} catch (Exception e) {
								if (image != null) image.close();
								droppedFrames.incrementAndGet();

								int errors = captureErrorCount.incrementAndGet();
								if (errors >= 3) {
									Handler mainHandler = new Handler(getMainLooper());
									mainHandler.post(new Runnable() {
											public void run() {
												Toast.makeText(ScreenCaptureService.this, 
															   "Error de captura: reiniciar app", 
															   Toast.LENGTH_LONG).show();
											}
										});
									captureErrorCount.set(0);
								}
							}
						}
					}, processingHandler);

            } catch (Exception e) {
                e.printStackTrace();
                stopCapture();
            }
        }

        public void stopCapture() {
            if (!running) return;

            running = false;

            saveStats();

            if (glProcessor != null) {
                glProcessor.release();
                glProcessor = null;
            }

            if (virtualDisplay != null) {
                virtualDisplay.release();
                virtualDisplay = null;
            }
            if (imageReader != null) {
                imageReader.close();
                imageReader = null;
            }
            if (projection != null) {
                projection.stop();
                projection = null;
            }

            removeOverlayWindow();

            stopForeground(true);
            stopSelf();
        }

        private void initializeBufferPools() {
            int targetSize = targetWidth * targetHeight * 4;

            if (bufferPool1 == null || bufferPool1.length != targetSize) {
                bufferPool1 = new byte[targetSize];
                bufferPool2 = new byte[targetSize];
            }

            Arrays.fill(bufferPool1, (byte)0);
            Arrays.fill(bufferPool2, (byte)0);

            if (prevFrameBuffer == null || prevFrameBuffer.length != targetSize) {
                prevFrameBuffer = new byte[targetSize];
            }
            if (currentFrameBuffer == null || currentFrameBuffer.length != targetSize) {
                currentFrameBuffer = new byte[targetSize];
            }

            Arrays.fill(prevFrameBuffer, (byte)0);
            Arrays.fill(currentFrameBuffer, (byte)0);

            if (renderBitmap != null && !renderBitmap.isRecycled()) {
                if (renderBitmap.getWidth() != targetWidth || renderBitmap.getHeight() != targetHeight) {
                    renderBitmap.recycle();
                    renderBitmap = Bitmap.createBitmap(targetWidth, targetHeight, Bitmap.Config.ARGB_8888);
                }
            } else {
                renderBitmap = Bitmap.createBitmap(targetWidth, targetHeight, Bitmap.Config.ARGB_8888);
            }
            renderBitmap.eraseColor(Color.TRANSPARENT);

            if (bitmapPaint == null) {
                bitmapPaint = new android.graphics.Paint();
                bitmapPaint.setAntiAlias(false);
                bitmapPaint.setFilterBitmap(false);
                bitmapPaint.setDither(false);
            }

            if (clearPaint == null) {
                clearPaint = new Paint();
                clearPaint.setXfermode(new PorterDuffXfermode(PorterDuff.Mode.CLEAR));
            }
        }

        private void precalculateMappings() {
            xMapping = new int[targetWidth];
            yMapping = new int[targetHeight];
            xWeights = new float[targetWidth];
            yWeights = new float[targetHeight];

            for (int x = 0; x < targetWidth; x++) {
                float srcX = x * (float) sourceWidth / targetWidth;
                xMapping[x] = (int) Math.floor(srcX);
                xWeights[x] = srcX - xMapping[x];
            }
            for (int y = 0; y < targetHeight; y++) {
                float srcY = y * (float) sourceHeight / targetHeight;
                yMapping[y] = (int) Math.floor(srcY);
                yWeights[y] = srcY - yMapping[y];
            }
        }

        private void createOverlayWindow() {
            if (Build.VERSION.SDK_INT < 23 || !Settings.canDrawOverlays(this)) {
                return;
            }

            windowManager = (WindowManager) getSystemService(WINDOW_SERVICE);

            WindowManager.LayoutParams params = new WindowManager.LayoutParams(
                targetWidth,
                targetHeight,
                Build.VERSION.SDK_INT >= 26 ? 
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY :
                WindowManager.LayoutParams.TYPE_PHONE,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE |
                WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE |
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN |
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS |
                WindowManager.LayoutParams.FLAG_HARDWARE_ACCELERATED,
                PixelFormat.RGBA_8888);

            params.gravity = Gravity.TOP | Gravity.LEFT;
            params.x = 0;
            params.y = 0;

            overlayView = new SurfaceView(this);
            overlayView.setZOrderOnTop(true);
            overlayView.getHolder().setFormat(PixelFormat.OPAQUE);

            overlayView.getHolder().addCallback(new SurfaceHolder.Callback() {
					public void surfaceCreated(SurfaceHolder holder) {
						overlaySurface = holder.getSurface();
						Canvas canvas = null;
						try {
							canvas = overlaySurface.lockCanvas(null);
							if (canvas != null) {
								canvas.drawColor(Color.BLACK, PorterDuff.Mode.SRC);
							}
						} catch (Exception e) {
							e.printStackTrace();
						} finally {
							if (canvas != null) {
								overlaySurface.unlockCanvasAndPost(canvas);
							}
						}
					}

					public void surfaceChanged(SurfaceHolder holder, int format, int width, int height) {
						overlaySurface = holder.getSurface();
					}

					public void surfaceDestroyed(SurfaceHolder holder) {
						overlaySurface = null;
					}
				});

            overlayView.setOnTouchListener(new View.OnTouchListener() {
					public boolean onTouch(View v, MotionEvent event) {
						if (running && TouchForwardService.isRunning()) {
							TouchForwardService.dispatchTouch(event);
							return true;
						}
						return false;
					}
				});

            windowManager.addView(overlayView, params);
        }

        private void removeOverlayWindow() {
            if (overlayView != null && windowManager != null) {
                try {
                    windowManager.removeView(overlayView);
                } catch (Exception e) {
                    e.printStackTrace();
                }
                overlayView = null;
                windowManager = null;
            }
            overlaySurface = null;
        }

        private long calculateOptimizedHash(byte[] data) {
            long hash = 5381;
            int step = data.length / 64;
            if (step < 4) step = 4;

            int quarter = data.length / 4;
            for (int i = 0; i < 4; i++) {
                int start = i * quarter;
                int end = Math.min(start + quarter, data.length);
                for (int j = start; j < end; j += step) {
                    hash = ((hash << 5) + hash) + (data[j] & 0xFF);
                }
            }
            return hash;
        }

        private class FrameProcessor implements Runnable {
            private final Image image;

            FrameProcessor(Image img) {
                this.image = img;
            }

            public void run() {
                if (image == null || !running) {
                    if (image != null) image.close();
                    return;
                }

                try {
                    Image.Plane[] planes = image.getPlanes();
                    if (planes.length == 0) {
                        image.close();
                        return;
                    }

                    ByteBuffer buffer = planes[0].getBuffer();
                    int pixelStride = planes[0].getPixelStride();
                    int rowStride = planes[0].getRowStride();

                    if (!buffer.isDirect() || buffer.capacity() == 0) {
                        image.close();
                        return;
                    }

                    int expectedSize = sourceWidth * sourceHeight * 4;

                    if (currentFrameBuffer == null || currentFrameBuffer.length != expectedSize) {
                        currentFrameBuffer = new byte[expectedSize];
                    }

                    byte[] sourceData = currentFrameBuffer;

                    buffer.rewind();
                    int bufferPos = 0;
                    int dataPos = 0;
                    int rowPadding = rowStride - pixelStride * sourceWidth;

                    for (int y = 0; y < sourceHeight; y++) {
                        for (int x = 0; x < sourceWidth; x++) {
                            if (bufferPos + 3 < buffer.capacity() && dataPos + 3 < sourceData.length) {
                                sourceData[dataPos] = buffer.get(bufferPos);
                                sourceData[dataPos + 1] = buffer.get(bufferPos + 1);
                                sourceData[dataPos + 2] = buffer.get(bufferPos + 2);
                                sourceData[dataPos + 3] = buffer.get(bufferPos + 3);
                            }
                            bufferPos += pixelStride;
                            dataPos += 4;
                        }
                        bufferPos += rowPadding;
                    }

                    if (colorQuality != COLORQUALITY_FULL) {
                        reduceColorQuality(sourceData, colorQuality);
                    }

                    long frameHash = calculateOptimizedHash(sourceData);
                    hashSamples[hashSampleIndex] = frameHash;
                    hashSampleIndex = (hashSampleIndex + 1) % hashSamples.length;

                    boolean isStatic = true;
                    for (int i = 1; i < hashSamples.length; i++) {
                        if (hashSamples[i] != hashSamples[0]) {
                            isStatic = false;
                            break;
                        }
                    }

                    if (isStatic && staticFrameCount >= 3) {
                        if (cachedStaticFrame != null) {
                            renderToSurface(cachedStaticFrame);
                            framesProcessed.incrementAndGet();
                            image.close();
                            return;
                        }
                    }

                    staticFrameCount = isStatic ? staticFrameCount + 1 : 0;

                    byte[] processedData = nearestNeighborUpscale(sourceData, sourceWidth, sourceHeight);

                    if (staticFrameCount >= 3 && cachedStaticFrame == null) {
                        cachedStaticFrame = Arrays.copyOf(processedData, processedData.length);
                    }

                    renderToSurface(processedData);
                    framesProcessed.incrementAndGet();
                    sessionTotalFrames++;

                } catch (Exception e) {
                    droppedFrames.incrementAndGet();
                } finally {
                    image.close();
                }
            }
        }

        private class SIFgV1FrameGenerator implements Runnable {
            private final Image image;
            private byte[] tempFrameBuffer;

            SIFgV1FrameGenerator(Image img) {
                this.image = img;
                this.tempFrameBuffer = new byte[sourceWidth * sourceHeight * 4];
            }

            public void run() {
                if (image == null || !running) {
                    if (image != null) image.close();
                    return;
                }

                try {
                    Image.Plane[] planes = image.getPlanes();
                    if (planes.length == 0) {
                        image.close();
                        return;
                    }

                    ByteBuffer buffer = planes[0].getBuffer();
                    int pixelStride = planes[0].getPixelStride();
                    int rowStride = planes[0].getRowStride();

                    buffer.rewind();
                    int bufferPos = 0;
                    int dataPos = 0;
                    int rowPadding = rowStride - pixelStride * sourceWidth;
                    for (int y = 0; y < sourceHeight; y++) {
                        for (int x = 0; x < sourceWidth; x++) {
                            if (bufferPos + 3 < buffer.capacity() && dataPos + 3 < tempFrameBuffer.length) {
                                tempFrameBuffer[dataPos] = buffer.get(bufferPos);
                                tempFrameBuffer[dataPos + 1] = buffer.get(bufferPos + 1);
                                tempFrameBuffer[dataPos + 2] = buffer.get(bufferPos + 2);
                                tempFrameBuffer[dataPos + 3] = buffer.get(bufferPos + 3);
                            }
                            bufferPos += pixelStride;
                            dataPos += 4;
                        }
                        bufferPos += rowPadding;
                    }

                    if (colorQuality != COLORQUALITY_FULL) {
                        reduceColorQuality(tempFrameBuffer, colorQuality);
                    }

                    byte[] baseFrame = nearestNeighborUpscale(tempFrameBuffer, sourceWidth, sourceHeight);
                    if (baseFrame != null) {
                        renderToSurface(baseFrame);
                        framesProcessed.incrementAndGet();
                        sessionTotalFrames++;
                    }

                } catch (Exception e) {
                    droppedFrames.incrementAndGet();
                } finally {
                    image.close();
                }
            }
        }

        private class SIFgV1_1FrameGenerator implements Runnable {
			private final Image image;
			private byte[] tempFrameBuffer;

			SIFgV1_1FrameGenerator(Image img) {
				this.image = img;
				this.tempFrameBuffer = new byte[sourceWidth * sourceHeight * 4];
			}

			public void run() {
				if (image == null || !running) {
					if (image != null) image.close();
					return;
				}

				try {
					Image.Plane[] planes = image.getPlanes();
					if (planes.length == 0) {
						image.close();
						return;
					}

					ByteBuffer buffer = planes[0].getBuffer();
					int pixelStride = planes[0].getPixelStride();
					int rowStride = planes[0].getRowStride();

					buffer.rewind();
					int bufferPos = 0;
					int dataPos = 0;
					int rowPadding = rowStride - pixelStride * sourceWidth;

					if (pixelStride == 4) {
						buffer.get(tempFrameBuffer, 0, Math.min(buffer.remaining(), tempFrameBuffer.length));
					} else {
						for (int y = 0; y < sourceHeight; y++) {
							int rowBytes = sourceWidth * 4;
							buffer.get(tempFrameBuffer, dataPos, rowBytes);
							dataPos += rowBytes;
							bufferPos += rowBytes + rowPadding;
							buffer.position(bufferPos);
						}
					}

					byte[] currentFrame = fastNearestNeighborUpscale(tempFrameBuffer);

					if (currentFrame != null) {
						renderToSurface(currentFrame);
						framesProcessed.incrementAndGet();
						sessionTotalFrames++;

						if (lastRealFrame != null && framesToGenerate > 0) {
							byte[] extrapolatedFrame = fastMotionExtrapolation(lastRealFrame, currentFrame);
							if (extrapolatedFrame != null) {
								renderToSurface(extrapolatedFrame);
								framesProcessed.incrementAndGet();
								sessionTotalFrames++;
							}
						}

						lastRealFrame = currentFrame;
					}

				} catch (Exception e) {
					droppedFrames.incrementAndGet();
				} finally {
					image.close();
				}
			}
		}

        private class SIFgV2FrameGenerator implements Runnable {
			private final Image image;
			private byte[] tempFrameBuffer;

			SIFgV2FrameGenerator(Image img) {
				this.image = img;
				this.tempFrameBuffer = new byte[sourceWidth * sourceHeight * 4];
			}

			public void run() {
				if (image == null || !running) {
					if (image != null) image.close();
					return;
				}

				try {
					Image.Plane[] planes = image.getPlanes();
					if (planes.length == 0) {
						image.close();
						return;
					}

					ByteBuffer buffer = planes[0].getBuffer();
					int pixelStride = planes[0].getPixelStride();
					int rowStride = planes[0].getRowStride();

					buffer.rewind();
					int bufferPos = 0;
					int dataPos = 0;
					int rowPadding = rowStride - pixelStride * sourceWidth;

					if (pixelStride == 4) {
						buffer.get(tempFrameBuffer, 0, Math.min(buffer.remaining(), tempFrameBuffer.length));
					} else {
						for (int y = 0; y < sourceHeight; y++) {
							int rowBytes = sourceWidth * 4;
							buffer.get(tempFrameBuffer, dataPos, rowBytes);
							dataPos += rowBytes;
							bufferPos += rowBytes + rowPadding;
							buffer.position(bufferPos);
						}
					}

					if (lastRealFrame == null) {
						lastRealFrame = new byte[targetWidth * targetHeight * 4];
						Arrays.fill(lastRealFrame, (byte)0);
					}

					if (glProcessor != null) {
						byte[] renderedFrame = glProcessor.renderFrame(tempFrameBuffer, sourceWidth, sourceHeight, lastRealFrame, targetWidth, targetHeight, fisheyeCorrection);

						if (renderedFrame != null) {
							renderToSurface(renderedFrame);
							framesProcessed.incrementAndGet();
							sessionTotalFrames++;
						}
					}

					System.arraycopy(lastRealFrame, 0, prevFrameBuffer, 0, lastRealFrame.length);
					byte[] upscaledCurrent = fastNearestNeighborUpscale(tempFrameBuffer);
					if (upscaledCurrent != null) {
						System.arraycopy(upscaledCurrent, 0, lastRealFrame, 0, upscaledCurrent.length);
					}

				} catch (Exception e) {
					droppedFrames.incrementAndGet();
				} finally {
					image.close();
				}
			}
		}

		private byte[] fastNearestNeighborUpscale(byte[] source) {
			if (source == null) return null;

			byte[] dest = bufferPool1;
			bufferPool1 = bufferPool2;
			bufferPool2 = dest;

			float invScaleX = (float) sourceWidth / targetWidth;
			float invScaleY = (float) sourceHeight / targetHeight;

			for (int y = 0; y < targetHeight; y++) {
				int srcY = (int) (y * invScaleY);
				if (srcY >= sourceHeight) srcY = sourceHeight - 1;

				int srcRowBase = srcY * sourceWidth * 4;
				int dstRowBase = y * targetWidth * 4;

				for (int x = 0; x < targetWidth; x++) {
					int srcX = (int) (x * invScaleX);
					if (srcX >= sourceWidth) srcX = sourceWidth - 1;

					int srcIdx = srcRowBase + srcX * 4;
					int dstIdx = dstRowBase + x * 4;

					if (srcIdx + 3 < source.length && dstIdx + 3 < dest.length) {
						dest[dstIdx] = source[srcIdx];
						dest[dstIdx + 1] = source[srcIdx + 1];
						dest[dstIdx + 2] = source[srcIdx + 2];
						dest[dstIdx + 3] = (byte) 255;
					}
				}
			}

			return dest;
		}

		private byte[] fastMotionExtrapolation(byte[] frameA, byte[] frameB) {
			if (frameA == null || frameB == null) return frameB;

			byte[] extrapolated = bufferPool2;

			int shiftX = 0;
			int shiftY = 0;

			for (int i = 0; i < extrapolated.length - 4; i += 4) {
				int dstPos = i;
				int srcPos = i + shiftY * targetWidth * 4 + shiftX * 4;

				if (srcPos >= 0 && srcPos + 3 < frameB.length && dstPos + 3 < extrapolated.length) {
					extrapolated[dstPos] = frameB[srcPos];
					extrapolated[dstPos + 1] = frameB[srcPos + 1];
					extrapolated[dstPos + 2] = frameB[srcPos + 2];
					extrapolated[dstPos + 3] = (byte) 255;
				}
			}

			return extrapolated;
		}

		private byte[] generateInterpolatedFrameSIFgV1_1(byte[] prevFrame, byte[] currentFrame, float factor) {
			if (prevFrame == null || currentFrame == null || prevFrame.length != currentFrame.length) {
				return currentFrame;
			}

			byte[] interpolated = bufferPool1;
			bufferPool1 = bufferPool2;
			bufferPool2 = interpolated;

			Arrays.fill(interpolated, (byte)0);

			try {
				for (int i = 0; i < interpolated.length - 3; i += 4) {
					int prevR = prevFrame[i] & 0xFF;
					int prevG = prevFrame[i + 1] & 0xFF;
					int prevB = prevFrame[i + 2] & 0xFF;
					int currR = currentFrame[i] & 0xFF;
					int currG = currentFrame[i + 1] & 0xFF;
					int currB = currentFrame[i + 2] & 0xFF;

					int interpR = clamp(prevR + (int)((currR - prevR) * factor), 0, 255);
					int interpG = clamp(prevG + (int)((currG - prevG) * factor), 0, 255);
					int interpB = clamp(prevB + (int)((currB - prevB) * factor), 0, 255);

					interpolated[i] = (byte)interpR;
					interpolated[i + 1] = (byte)interpG;
					interpolated[i + 2] = (byte)interpB;
					interpolated[i + 3] = (byte)255;
				}

				if (colorQuality != COLORQUALITY_FULL) {
					reduceColorQuality(interpolated, colorQuality);
				}
			} catch (Exception e) {
				e.printStackTrace();
				return currentFrame;
			}

			return interpolated;
		}

		private int clamp(int value, int min, int max) {
			return Math.max(min, Math.min(max, value));
		}

        private byte[] nearestNeighborUpscale(byte[] source, int srcW, int srcH) {
			if (source == null || srcW <= 0 || srcH <= 0) return null;

			byte[] dest = bufferPool1;
			bufferPool1 = bufferPool2;
			bufferPool2 = dest;

			Arrays.fill(dest, (byte)0);

			float invScaleX = (float) srcW / targetWidth;
			float invScaleY = (float) srcH / targetHeight;

			try {
				for (int y = 0; y < targetHeight; y++) {
					int srcY = (int) (y * invScaleY);
					if (srcY >= srcH) srcY = srcH - 1;

					int srcRowBase = srcY * srcW * 4;
					int dstRowBase = y * targetWidth * 4;

					for (int x = 0; x < targetWidth; x++) {
						int srcX = (int) (x * invScaleX);
						if (srcX >= srcW) srcX = srcW - 1;

						int srcIdx = srcRowBase + srcX * 4;
						int dstIdx = dstRowBase + x * 4;

						if (srcIdx + 3 < source.length && dstIdx + 3 < dest.length) {
							dest[dstIdx] = source[srcIdx];
							dest[dstIdx + 1] = source[srcIdx + 1];
							dest[dstIdx + 2] = source[srcIdx + 2];
							dest[dstIdx + 3] = (byte) 255;
						}
					}
				}
			} catch (Exception e) {
				e.printStackTrace();
				return null;
			}

			if (colorQuality != COLORQUALITY_FULL) {
				reduceColorQuality(dest, colorQuality);
			}

			return dest;
		}
        private void reduceColorQuality(byte[] data, int quality) {
            if (data == null || quality == COLORQUALITY_FULL) return;

            try {
                if (quality == COLORQUALITY_8BIT) {
                    for (int i = 0; i < data.length - 3; i += 4) {
                        data[i] = (byte)((data[i] & 0xFF) & 0xF8);
                        data[i + 1] = (byte)((data[i + 1] & 0xFF) & 0xF8);
                        data[i + 2] = (byte)((data[i + 2] & 0xFF) & 0xF8);
                    }
                } else if (quality == COLORQUALITY_256) {
                    for (int i = 0; i < data.length - 3; i += 4) {
                        int r = (data[i] & 0xFF) >> 5;
                        int g = (data[i + 1] & 0xFF) >> 5;
                        int b = (data[i + 2] & 0xFF) >> 6;

                        data[i] = (byte)((r << 5) | (r << 2) | (r >> 1));
                        data[i + 1] = (byte)((g << 5) | (g << 2) | (g >> 1));
                        data[i + 2] = (byte)((b << 6) | (b << 4) | (b << 2) | b);
                    }
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        }

        private void renderToSurface(byte[] frameData) {
            if (overlaySurface == null || !overlaySurface.isValid() || frameData == null) return;

            Canvas canvas = null;
            try {
                canvas = overlaySurface.lockCanvas(null);
                if (canvas == null) return;

                canvas.drawColor(Color.TRANSPARENT, PorterDuff.Mode.CLEAR);

                if (frameData.length != targetWidth * targetHeight * 4) {
                    return;
                }

                ByteBuffer byteBuffer = ByteBuffer.wrap(frameData);
                byteBuffer.rewind();

                synchronized (renderBitmap) {
                    if (!renderBitmap.isRecycled()) {
                        renderBitmap.copyPixelsFromBuffer(byteBuffer);

                        if (fisheyeCorrection != 0) {
                            applyFisheyeCorrection(canvas, renderBitmap);
                        } else {
                            canvas.drawBitmap(renderBitmap, 0, 0, bitmapPaint);
                        }
                    }
                }

            } catch (Exception e) {
                e.printStackTrace();
            } finally {
                if (canvas != null) {
                    try {
                        overlaySurface.unlockCanvasAndPost(canvas);
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }
            }
        }

        private void applyFisheyeCorrection(Canvas canvas, Bitmap bitmap) {
            if (bitmap == null || bitmap.isRecycled()) return;

            float centerX = targetWidth / 2f;
            float centerY = targetHeight / 2f;
            float maxRadius = (float) Math.sqrt(centerX * centerX + centerY * centerY);

            float correctionFactor = fisheyeCorrection / 100f;

            int gridSize = 20;
            int vertices = (gridSize + 1) * (gridSize + 1);

            float[] verts = new float[vertices * 2];
            int[] colors = new int[vertices];

            int index = 0;
            for (int y = 0; y <= gridSize; y++) {
                for (int x = 0; x <= gridSize; x++) {
                    float gridX = x * targetWidth / (float) gridSize;
                    float gridY = y * targetHeight / (float) gridSize;

                    float dx = gridX - centerX;
                    float dy = gridY - centerY;
                    float distance = (float) Math.sqrt(dx * dx + dy * dy);

                    if (distance > 0) {
                        float normalizedDist = distance / maxRadius;
                        float correctedDist = normalizedDist * (1 + correctionFactor * normalizedDist * normalizedDist);
                        correctedDist *= maxRadius;

                        float angle = (float) Math.atan2(dy, dx);
                        verts[index * 2] = centerX + correctedDist * (float) Math.cos(angle);
                        verts[index * 2 + 1] = centerY + correctedDist * (float) Math.sin(angle);
                    } else {
                        verts[index * 2] = gridX;
                        verts[index * 2 + 1] = gridY;
                    }

                    colors[index] = Color.TRANSPARENT;
                    index++;
                }
            }

            canvas.drawBitmapMesh(bitmap, gridSize, gridSize, verts, 0, colors, 0, bitmapPaint);
        }

        private class FpsUpdater implements Runnable {
            public void run() {
                if (!running) return;
                long currentTime = System.currentTimeMillis();
                long elapsed = currentTime - lastFpsUpdate.get();
                if (elapsed >= 1000) {
                    int fps = (int) (framesProcessed.get() * 1000 / elapsed);
                    currentFps.set(fps);
                    lastFpsUpdate.set(currentTime);
                    framesProcessed.set(0);
                    updateNotification();
                }
                processingHandler.postDelayed(this, 250);
            }
        }

        private void saveStats() {
            if (sessionTotalFrames == 0 || sessionStartTime == 0) return;

            long sessionDuration = System.currentTimeMillis() - sessionStartTime;
            int avgFps = (int) (sessionTotalFrames * 1000 / sessionDuration);

            String key = "avg_fps_";
            switch (currentMode) {
                case MODEPERFORMANCE:
                    key += "performance";
                    break;
                case MODESIFG1:
                    key += "sifg1";
                    break;
                default:
                    return;
            }

            int oldAvg = prefs.getInt(key, 0);
            int newAvg = oldAvg == 0 ? avgFps : (oldAvg + avgFps) / 2;

            prefs.edit().putInt(key, newAvg).apply();
        }

        public void onDestroy() {
            stopCapture();

            if (controlReceiver != null) {
                try {
                    unregisterReceiver(controlReceiver);
                } catch (Exception e) {
                }
            }

            if (processingThread != null) {
                processingThread.quitSafely();
                try {
                    processingThread.join(500);
                } catch (InterruptedException e) {
                }
            }

            synchronized (renderBitmap) {
                if (renderBitmap != null && !renderBitmap.isRecycled()) {
                    renderBitmap.recycle();
                    renderBitmap = null;
                }
            }

            bufferPool1 = null;
            bufferPool2 = null;
            prevFrameBuffer = null;
            currentFrameBuffer = null;
            xMapping = null;
            yMapping = null;
            xWeights = null;
            yWeights = null;
            hashSamples = null;
            bitmapPaint = null;
            clearPaint = null;

            super.onDestroy();
        }
    }

    private static class GLFrameProcessor {
        private static final String VERTEX_SHADER_CODE =
		"uniform mat4 uMVPMatrix;" +
		"attribute vec4 aPosition;" +
		"attribute vec2 aTexCoord;" +
		"varying vec2 vTexCoord;" +
		"void main() {" +
		"  gl_Position = uMVPMatrix * aPosition;" +
		"  vTexCoord = aTexCoord;" +
		"}";

        private static final String FRAGMENT_SHADER_CODE =
		"#extension GL_OES_EGL_image_external : require\n" +
		"precision mediump float;" +
		"uniform sampler2D uTexture;" +
		"uniform float uInterpolation;" +
		"uniform vec2 uResolution;" +
		"uniform int uFisheyeCorrection;" +
		"varying vec2 vTexCoord;" +
		"void main() {" +
		"  vec2 texCoord = vTexCoord;" +
		"  if (uFisheyeCorrection != 0) {" +
		"    vec2 center = vec2(0.5, 0.5);" +
		"    vec2 uv = texCoord - center;" +
		"    float distance = length(uv);" +
		"    float correctedDist = distance * (1.0 + float(uFisheyeCorrection) / 100.0 * distance * distance);" +
		"    texCoord = center + uv * (correctedDist / distance);" +
		"  }" +
		"  vec4 current = texture2D(uTexture, texCoord);" +
		"  vec4 previous = texture2D(uTexture, texCoord);" +
		"  vec4 interpolated = previous * (1.0 - uInterpolation) + current * uInterpolation;" +
		"  gl_FragColor = interpolated;" +
		"}";

        private int program;
        private int textureId;
        private int[] frameBuffer;
        private int[] renderTexture;
        private int width, height;
        private int fisheyeCorrection;

        public GLFrameProcessor(int width, int height, int fisheyeCorrection) {
            this.width = width;
            this.height = height;
            this.fisheyeCorrection = fisheyeCorrection;
            initializeGL();
        }

        private void initializeGL() {
            int vertexShader = loadShader(GLES20.GL_VERTEX_SHADER, VERTEX_SHADER_CODE);
            int fragmentShader = loadShader(GLES20.GL_FRAGMENT_SHADER, FRAGMENT_SHADER_CODE);

            program = GLES20.glCreateProgram();
            GLES20.glAttachShader(program, vertexShader);
            GLES20.glAttachShader(program, fragmentShader);
            GLES20.glLinkProgram(program);

            int[] textures = new int[1];
            GLES20.glGenTextures(1, textures, 0);
            textureId = textures[0];
            GLES20.glBindTexture(GLES20.GL_TEXTURE_2D, textureId);
            GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_MIN_FILTER, GLES20.GL_LINEAR);
            GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_MAG_FILTER, GLES20.GL_LINEAR);

            frameBuffer = new int[1];
            renderTexture = new int[1];
            GLES20.glGenFramebuffers(1, frameBuffer, 0);
            GLES20.glGenTextures(1, renderTexture, 0);
            GLES20.glBindTexture(GLES20.GL_TEXTURE_2D, renderTexture[0]);
            GLES20.glTexImage2D(GLES20.GL_TEXTURE_2D, 0, GLES20.GL_RGBA, width, height, 0, GLES20.GL_RGBA, GLES20.GL_UNSIGNED_BYTE, null);
            GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_MIN_FILTER, GLES20.GL_LINEAR);
            GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_MAG_FILTER, GLES20.GL_LINEAR);
        }

        private int loadShader(int type, String code) {
            int shader = GLES20.glCreateShader(type);
            GLES20.glShaderSource(shader, code);
            GLES20.glCompileShader(shader);
            return shader;
        }

        public byte[] renderFrame(byte[] currentFrame, int srcW, int srcH, byte[] previousFrame, int dstW, int dstH, int fisheyeCorrection) {
            FloatBuffer vertexBuffer = ByteBuffer.allocateDirect(4 * 4).order(ByteOrder.nativeOrder()).asFloatBuffer();
            FloatBuffer texCoordBuffer = ByteBuffer.allocateDirect(4 * 2).order(ByteOrder.nativeOrder()).asFloatBuffer();

            float[] vertices = {
                -1.0f, 1.0f, 0.0f, 1.0f,
                -1.0f, -1.0f, 0.0f, 1.0f,
                1.0f, -1.0f, 0.0f, 1.0f,
                1.0f, 1.0f, 0.0f, 1.0f
            };

            float[] texCoords = {
                0.0f, 0.0f,
                0.0f, 1.0f,
                1.0f, 1.0f,
                1.0f, 0.0f
            };

            vertexBuffer.put(vertices);
            texCoordBuffer.put(texCoords);
            vertexBuffer.position(0);
            texCoordBuffer.position(0);

            GLES20.glBindFramebuffer(GLES20.GL_FRAMEBUFFER, frameBuffer[0]);
            GLES20.glFramebufferTexture2D(GLES20.GL_FRAMEBUFFER, GLES20.GL_COLOR_ATTACHMENT0, GLES20.GL_TEXTURE_2D, renderTexture[0], 0);
            GLES20.glViewport(0, 0, dstW, dstH);

            GLES20.glUseProgram(program);

            int positionHandle = GLES20.glGetAttribLocation(program, "aPosition");
            int texCoordHandle = GLES20.glGetAttribLocation(program, "aTexCoord");
            int textureHandle = GLES20.glGetUniformLocation(program, "uTexture");
            int interpolationHandle = GLES20.glGetUniformLocation(program, "uInterpolation");
            int resolutionHandle = GLES20.glGetUniformLocation(program, "uResolution");
            int fisheyeHandle = GLES20.glGetUniformLocation(program, "uFisheyeCorrection");

            GLES20.glVertexAttribPointer(positionHandle, 4, GLES20.GL_FLOAT, false, 0, vertexBuffer);
            GLES20.glVertexAttribPointer(texCoordHandle, 2, GLES20.GL_FLOAT, false, 0, texCoordBuffer);

            GLES20.glEnableVertexAttribArray(positionHandle);
            GLES20.glEnableVertexAttribArray(texCoordHandle);

            GLES20.glActiveTexture(GLES20.GL_TEXTURE0);
            GLES20.glBindTexture(GLES20.GL_TEXTURE_2D, textureId);
            GLES20.glTexImage2D(GLES20.GL_TEXTURE_2D, 0, GLES20.GL_RGBA, srcW, srcH, 0, GLES20.GL_RGBA, GLES20.GL_UNSIGNED_BYTE, ByteBuffer.wrap(currentFrame));
            GLES20.glUniform1i(textureHandle, 0);
            GLES20.glUniform1f(interpolationHandle, 0.5f);
            GLES20.glUniform2f(resolutionHandle, dstW, dstH);
            GLES20.glUniform1i(fisheyeHandle, fisheyeCorrection);

            GLES20.glDrawArrays(GLES20.GL_TRIANGLE_FAN, 0, 4);

            GLES20.glDisableVertexAttribArray(positionHandle);
            GLES20.glDisableVertexAttribArray(texCoordHandle);

            ByteBuffer resultBuffer = ByteBuffer.allocate(dstW * dstH * 4);
            GLES20.glReadPixels(0, 0, dstW, dstH, GLES20.GL_RGBA, GLES20.GL_UNSIGNED_BYTE, resultBuffer);

            byte[] result = resultBuffer.array();
            flipY(result, dstW, dstH);

            return result;
        }

        private void flipY(byte[] data, int width, int height) {
            int rowSize = width * 4;
            byte[] tempRow = new byte[rowSize];

            for (int y = 0; y < height / 2; y++) {
                int topOffset = y * rowSize;
                int bottomOffset = (height - 1 - y) * rowSize;

                System.arraycopy(data, topOffset, tempRow, 0, rowSize);
                System.arraycopy(data, bottomOffset, data, topOffset, rowSize);
                System.arraycopy(tempRow, 0, data, bottomOffset, rowSize);
            }
        }

        public void release() {
            GLES20.glDeleteTextures(1, new int[]{textureId}, 0);
            GLES20.glDeleteFramebuffers(1, frameBuffer, 0);
            GLES20.glDeleteTextures(1, renderTexture, 0);
            GLES20.glDeleteProgram(program);
        }
    }
}
